# -*- coding: utf-8 -*-
#
# PipaRouter — roteirização de caminhões-pipa no QGIS
# Copyright (C) 2025  Antonio A. Coelho Neto
#
# Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
# sob os termos da GNU General Public License versão 2 ou posterior.
# Veja o arquivo LICENSE, ou <https://www.gnu.org/licenses/gpl-2.0.html>.
#
"""
Adaptador entre as fontes de distancia/tempo e o solver.

O solver so precisa de duas coisas: dist(i,j) e tempo(i,j). Quem responde
pode ser:

  FonteEstrada  -> roteia pela malha viaria. Tempo por classe de via.
                   Guarda a geometria real do caminho.
  FonteEstimada -> linha reta x sinuosidade, velocidade unica.

A diferenca aparece no cronograma. Uma media de 40 km/h num percurso que e
metade asfalto e metade carrocavel erra o horario de chegada em dezenas de
minutos, e o erro ACUMULA ao longo do dia: a ultima entrega da manha pode
sair 1h deslocada. Quem espera agua nao sabe se o caminhao vem as 10h ou as 11h.
"""

from typing import Dict, List, Optional, Sequence, Tuple


class FonteEstimada:
    """Envolve MatrizDistancia. Tempo = distancia / velocidade media."""

    def __init__(self, matriz, params):
        self._m = matriz
        self._p = params
        self.exata = False

    def dist(self, i: int, j: int) -> float:
        return self._m.dist(i, j)

    # Sem metodo `tempo`: o solver detecta e usa velocidade media.

    def geometria(self, i: int, j: int) -> List[Tuple[float, float]]:
        """Linha reta — nao sabemos por onde a estrada vai."""
        return [self._m.pontos[i], self._m.pontos[j]]

    def resumo(self) -> Dict:
        r = self._m.resumo()
        r["fonte"] = "estimada"
        return r


class FonteEstrada:
    """
    Envolve Roteador. Tempo real por classe de via, geometria real.

    Pre-calcula as matrizes na construcao: o Dijkstra por origem e caro,
    e o solver consulta os mesmos pares milhares de vezes na busca local.
    """

    def __init__(self, roteador, callback=None):
        self._r = roteador
        self.exata = True
        self._geo: Dict[Tuple[int, int], List] = {}
        n = len(roteador.pontos)
        self._md = [[0.0] * n for _ in range(n)]
        self._mt = [[0.0] * n for _ in range(n)]
        self._aprox = [[False] * n for _ in range(n)]
        self._kpav = [[0.0] * n for _ in range(n)]
        self._kterra = [[0.0] * n for _ in range(n)]

        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                t = roteador.trecho(i, j)
                self._md[i][j] = t.dist_km
                self._mt[i][j] = t.tempo_min
                self._aprox[i][j] = t.aproximado
                self._geo[(i, j)] = t.geometria
                self._kpav[i][j] = t.km_pav
                self._kterra[i][j] = t.km_terra
            if callback:
                callback(int(100 * (i + 1) / n))

    def dist(self, i: int, j: int) -> float:
        return self._md[i][j]

    def tempo(self, i: int, j: int) -> float:
        """Minutos, pela estrada, com velocidade por classe de via."""
        return self._mt[i][j]

    def geometria(self, i: int, j: int) -> List[Tuple[float, float]]:
        return self._geo.get((i, j), [self._r.pontos[i], self._r.pontos[j]])

    def aproximado(self, i: int, j: int) -> bool:
        return self._aprox[i][j]

    def km_pav(self, i: int, j: int) -> float:
        return self._kpav[i][j]

    def km_terra(self, i: int, j: int) -> float:
        return self._kterra[i][j]

    @property
    def n_aproximados(self) -> int:
        n = len(self._r.pontos)
        return sum(1 for i in range(n) for j in range(n)
                   if i != j and self._aprox[i][j])

    def resumo(self) -> Dict:
        r = self._r.resumo()
        r["fonte"] = "estrada"
        n = len(self._r.pontos)
        tot = n * (n - 1)
        r["trechos_aproximados"] = self.n_aproximados
        r["trechos_totais"] = tot
        if tot:
            r["pct_exato"] = round(
                100 * (tot - self.n_aproximados) / tot, 1)
        return r

    def diagnostico(self) -> str:
        return self._r.diagnostico()

    @property
    def roteador(self):
        return self._r
