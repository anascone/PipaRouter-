# -*- coding: utf-8 -*-
#
# PipaRouter — roteirização de caminhões-pipa no QGIS
# Copyright (C) 2025  Antonio A. Coelho Neto
#
# Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
# sob os termos da GNU General Public License versão 2 ou posterior.
# Veja o arquivo LICENSE, ou <https://www.gnu.org/licenses/gpl-2.0.html>.
#
"""
Baixa as estradas sozinho, da API Overpass.

POR QUE ISTO EXISTE
-------------------
Baixar OSM pelo QuickOSM exige: saber que o QuickOSM existe, instalar,
escolher a chave certa, enquadrar o mapa cobrindo todos os pontos, e salvar.
Cada passo e um lugar onde quebra — e quebrou. O plugin sabe onde ficam os
pontos; ele mesmo pode buscar a area certa.

POR QUE NAO VEM EMBUTIDO NO PLUGIN
----------------------------------
O PBF do Piaui tem ~80 MB; processado para OSRM, ~300 MB. O Nordeste, ~1.8 GB.
O repositorio de plugins do QGIS limita o pacote a ~25 MB. Nao cabe. Baixar
sob demanda so a area dos pontos resolve: um municipio da ~2-3 MB.

CACHE
-----
O download vai para um GeoPackage no perfil do QGIS. Da segunda vez em diante
o plugin le do disco — offline, instantaneo. E o que permite operar em campo
sem sinal: baixa no escritorio, usa no campo.

LICENCA
-------
Dados © OpenStreetMap contributors, ODbL. Uso comercial liberado, exige
atribuicao. A camada criada leva a atribuicao nos metadados.
"""

import hashlib
import json
import os
import time
from typing import Dict, List, Optional, Sequence, Tuple

try:
    from qgis.core import (
        QgsCoordinateReferenceSystem, QgsFeature, QgsField, QgsGeometry,
        QgsPointXY, QgsProject, QgsVectorFileWriter, QgsVectorLayer,
        QgsWkbTypes,
    )
    from qgis.PyQt.QtCore import QVariant
    QGIS_OK = True
except ImportError:
    QGIS_OK = False


# Espelhos da Overpass. Se um cai ou esta congestionado, tenta o proximo.
SERVIDORES_OVERPASS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://overpass.osm.ch/api/interpreter",
]

# Classes de via que interessam a um caminhao-pipa. Deixamos de fora
# footway/cycleway/steps — o pipa nao passa, e trazem volume a toa.
CLASSES = ("motorway|trunk|primary|secondary|tertiary|unclassified|"
           "residential|living_street|service|track|road|"
           "motorway_link|trunk_link|primary_link|secondary_link|tertiary_link")

TIMEOUT_PADRAO = 180
UA = "PipaRouter-QGIS/2.3 (abastecimento de agua por caminhao-pipa)"


class ErroOverpass(Exception):
    pass


def _bbox(pontos: Sequence[Tuple[float, float]],
          margem_km: float = 5.0) -> Tuple[float, float, float, float]:
    """
    (sul, oeste, norte, leste) cobrindo os pontos, com margem.

    A margem existe porque a estrada que liga dois pontos costuma sair da
    caixa que os contem: um desvio, um contorno de serra. Sem margem, a rede
    chega picada na borda e o roteamento falha justamente nas pontas.
    """
    lons = [p[0] for p in pontos]
    lats = [p[1] for p in pontos]
    # 1 grau de latitude ~ 111 km; longitude encolhe com o cosseno da lat
    import math
    lat_m = margem_km / 111.0
    lat_med = sum(lats) / len(lats)
    lon_m = margem_km / (111.0 * max(math.cos(math.radians(lat_med)), 0.1))
    return (min(lats) - lat_m, min(lons) - lon_m,
            max(lats) + lat_m, max(lons) + lon_m)


def _chave_cache(bbox) -> str:
    s = "|".join(f"{v:.4f}" for v in bbox)
    return hashlib.md5(s.encode()).hexdigest()[:12]


def pasta_cache() -> str:
    """Pasta de cache, dentro do perfil do QGIS."""
    if QGIS_OK:
        try:
            from qgis.core import QgsApplication
            base = QgsApplication.qgisSettingsDirPath()
        except Exception:
            base = os.path.expanduser("~")
    else:
        base = os.path.expanduser("~")
    p = os.path.join(base, "piparouter_estradas")
    os.makedirs(p, exist_ok=True)
    return p


def _query(bbox) -> str:
    s, w, n, e = bbox
    return f"""[out:json][timeout:{TIMEOUT_PADRAO}];
(way["highway"~"^({CLASSES})$"]({s:.5f},{w:.5f},{n:.5f},{e:.5f}););
out body geom;"""


def _http_post(url: str, dados: str, timeout: int):
    try:
        import urllib3
        http = urllib3.PoolManager(
            timeout=urllib3.Timeout(connect=15.0, read=timeout))
        r = http.request("POST", url, body=dados.encode("utf-8"),
                         headers={"User-Agent": UA,
                                  "Content-Type": "text/plain; charset=utf-8"})
        return r.status, r.data
    except ImportError:
        import urllib.request
        import urllib.error
        req = urllib.request.Request(
            url, data=dados.encode("utf-8"),
            headers={"User-Agent": UA,
                     "Content-Type": "text/plain; charset=utf-8"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as e:
            return e.code, b""


def _contem(maior, menor, folga: float = 0.001) -> bool:
    """A bbox `maior` contem `menor`? (S, W, N, E)"""
    return (maior[0] <= menor[0] + folga and maior[1] <= menor[1] + folga
            and maior[2] >= menor[2] - folga and maior[3] >= menor[3] - folga)


def buscar_no_cache(bbox) -> Optional[Tuple[str, Dict]]:
    """
    Procura um download anterior que ja cubra esta area.

    Exigir bbox identica torna o cache inutil no uso real: basta marcar um
    ponto a mais e a caixa muda, forcando novo download de uma area que ja
    esta no disco. Aqui aceitamos qualquer area maior que contenha a pedida —
    que e o caso comum quando o usuario vai acrescentando localidades.
    """
    for info in listar_cache():
        b = info.get("bbox")
        if not b or len(b) != 4:
            continue
        if _contem(tuple(b), tuple(bbox)):
            cam = info["arquivo"]
            if os.path.exists(cam):
                return cam, info
    return None


def baixar_estradas(pontos: Sequence[Tuple[float, float]],
                    margem_km: float = 5.0,
                    usar_cache: bool = True,
                    callback=None) -> Tuple[str, Dict]:
    """
    Baixa as estradas ao redor dos pontos. Devolve (caminho_gpkg, info).

    pontos: [(lon, lat), ...] em EPSG:4326
    """
    if not QGIS_OK:
        raise ErroOverpass("precisa do QGIS")

    bbox = _bbox(pontos, margem_km)

    if usar_cache:
        achado = buscar_no_cache(bbox)
        if achado:
            cam, info = achado
            info = dict(info)
            info["do_cache"] = True
            return cam, info

    chave = _chave_cache(bbox)
    gpkg = os.path.join(pasta_cache(), f"estradas_{chave}.gpkg")
    meta = gpkg + ".json"

    def prog(p, msg=""):
        if callback:
            callback(p, msg)

    prog(5, "Preparando a busca...")
    q = _query(bbox)

    dados = None
    ultimo_erro = ""
    for i, srv in enumerate(SERVIDORES_OVERPASS):
        prog(10 + i * 5, f"Baixando de {srv.split('/')[2]}...")
        try:
            status, corpo = _http_post(srv, q, TIMEOUT_PADRAO)
            if status == 200 and corpo:
                dados = corpo
                servidor_ok = srv
                break
            if status == 429:
                ultimo_erro = "servidor ocupado (muitos pedidos)"
            elif status == 504:
                ultimo_erro = "a área pedida é grande demais"
            else:
                ultimo_erro = f"erro {status}"
        except Exception as e:
            ultimo_erro = f"{type(e).__name__}"

    if dados is None:
        raise ErroOverpass(
            f"não consegui baixar as estradas ({ultimo_erro}).\n\n"
            f"Tentei {len(SERVIDORES_OVERPASS)} servidores.\n\n"
            f"O que costuma resolver:\n"
            f"  • conferir se há internet\n"
            f"  • esperar 1-2 minutos (o serviço é gratuito e às vezes "
            f"fica ocupado)\n"
            f"  • se estiver atrás de firewall corporativo, ele pode estar "
            f"bloqueando\n\n"
            f"Alternativa: baixe pelo QuickOSM "
            f"(Vetor > QuickOSM > chave 'highway') e selecione a camada "
            f"aqui na lista.")

    prog(60, "Lendo a resposta...")
    try:
        j = json.loads(dados)
    except Exception as e:
        raise ErroOverpass(f"a resposta do servidor veio corrompida: {e}")

    elems = j.get("elements") or []
    if not elems:
        raise ErroOverpass(
            "não há nenhuma estrada mapeada nessa área do OpenStreetMap.\n"
            "Confira se os pontos estão no lugar certo.")

    prog(70, f"Montando {len(elems)} trechos...")
    caminho = _gravar_gpkg(elems, gpkg)

    info = {
        "trechos": len(elems),
        "bbox": bbox,
        "baixado_em": time.strftime("%Y-%m-%d %H:%M"),
        "servidor": servidor_ok,
        "margem_km": margem_km,
        "atribuicao": "© OpenStreetMap contributors (ODbL)",
        "do_cache": False,
    }
    try:
        with open(meta, "w", encoding="utf-8") as f:
            json.dump(info, f, ensure_ascii=False, indent=1)
    except Exception:
        pass

    prog(100, "Pronto.")
    return caminho, info


def _gravar_gpkg(elems: List[dict], caminho: str) -> str:
    """Converte a resposta da Overpass num GeoPackage de linhas."""
    lyr = QgsVectorLayer("LineString?crs=EPSG:4326", "estradas", "memory")
    dp = lyr.dataProvider()
    dp.addAttributes([
        QgsField("osm_id", QVariant.String),
        QgsField("highway", QVariant.String),
        QgsField("surface", QVariant.String),
        QgsField("name", QVariant.String),
        QgsField("ref", QVariant.String),
        QgsField("maxspeed", QVariant.String),
        QgsField("oneway", QVariant.String),
    ])
    lyr.updateFields()

    feats = []
    for el in elems:
        geom = el.get("geometry")
        if not geom or len(geom) < 2:
            continue
        pts = [QgsPointXY(g["lon"], g["lat"]) for g in geom]
        tags = el.get("tags") or {}
        f = QgsFeature(lyr.fields())
        f.setGeometry(QgsGeometry.fromPolylineXY(pts))
        f.setAttributes([
            str(el.get("id", "")),
            tags.get("highway", ""),
            tags.get("surface", ""),
            tags.get("name", ""),
            tags.get("ref", ""),
            tags.get("maxspeed", ""),
            tags.get("oneway", ""),
        ])
        feats.append(f)
    dp.addFeatures(feats)
    lyr.updateExtents()

    if os.path.exists(caminho):
        try:
            os.remove(caminho)
        except OSError:
            pass

    opts = QgsVectorFileWriter.SaveVectorOptions()
    opts.driverName = "GPKG"
    opts.layerName = "estradas"
    opts.fileEncoding = "UTF-8"
    try:
        err = QgsVectorFileWriter.writeAsVectorFormatV3(
            lyr, caminho, QgsProject.instance().transformContext(), opts)
        falhou = err[0] != QgsVectorFileWriter.NoError
    except AttributeError:
        # QGIS mais antigo
        err = QgsVectorFileWriter.writeAsVectorFormat(
            lyr, caminho, "UTF-8", lyr.crs(), "GPKG")
        falhou = err != QgsVectorFileWriter.NoError

    if falhou:
        raise ErroOverpass(f"não consegui salvar as estradas em {caminho}")
    return caminho


def carregar_camada(gpkg: str, nome: str = "Estradas (OSM)"):
    """Abre o GeoPackage como camada."""
    lyr = QgsVectorLayer(f"{gpkg}|layername=estradas", nome, "ogr")
    if not lyr.isValid():
        raise ErroOverpass(f"o arquivo de estradas não abriu: {gpkg}")
    return lyr


def listar_cache() -> List[Dict]:
    """O que ja esta baixado."""
    out = []
    p = pasta_cache()
    for f in sorted(os.listdir(p)):
        if not f.endswith(".gpkg"):
            continue
        cam = os.path.join(p, f)
        meta = cam + ".json"
        info = {"arquivo": cam, "mb": os.path.getsize(cam) / 1e6}
        if os.path.exists(meta):
            try:
                with open(meta, encoding="utf-8") as fh:
                    info.update(json.load(fh))
            except Exception:
                pass
        out.append(info)
    return out


def limpar_cache() -> int:
    """Apaga tudo. Devolve quantos MB liberou."""
    p = pasta_cache()
    total = 0
    for f in os.listdir(p):
        cam = os.path.join(p, f)
        try:
            total += os.path.getsize(cam)
            os.remove(cam)
        except OSError:
            pass
    return int(total / 1e6)


# ----------------------------------------------------------------------
# Download de area grande — por quadriculas
# ----------------------------------------------------------------------

# Tamanho da quadricula: o compromisso entre numero de consultas e risco de
# timeout. O custo de uma consulta e ~12 s de setup + ~1 s por 130 km2.
#
#    2.000 km2 -> 278 consultas de 28 s  = 142 min  (seguro, lento)
#    8.100 km2 ->  69 consultas de 74 s  =  89 min  (bom equilibrio)
#   25.000 km2 ->  23 consultas de 204 s = 504 certo
#
# 8.100 (90x90 km) e o ponto onde o tempo para de cair sem estourar o timeout
# de 180 s da Overpass. Se ainda assim der 504, _baixar_quad subdivide.
AREA_QUADRICULA_KM2 = 8100.0

# Pausa entre consultas. A Overpass e mantida por doacao; a politica de uso
# pede consultas moderadas. Sem pausa, o servidor devolve 429 e trava tudo.
PAUSA_ENTRE_S = 3.0


def _quadricular(bbox, area_km2: float = AREA_QUADRICULA_KM2) -> List[Tuple]:
    """
    Quebra uma bbox grande em pedacos que a Overpass aguenta.

    Devolve [(s, w, n, e), ...] cobrindo a bbox inteira, com sobreposicao
    minima. A sobreposicao existe de proposito: sem ela, uma estrada que
    cruza a divisa entre duas quadriculas chega cortada nas duas, e o
    roteamento falha exatamente ali.
    """
    import math
    s, w, n, e = bbox
    lat_med = (s + n) / 2
    km_por_grau_lat = 110.6
    km_por_grau_lon = 111.3 * max(math.cos(math.radians(lat_med)), 0.1)

    alt_km = (n - s) * km_por_grau_lat
    larg_km = (e - w) * km_por_grau_lon
    total = alt_km * larg_km

    if total <= area_km2:
        return [bbox]

    # Quadriculas aproximadamente quadradas
    lado_km = math.sqrt(area_km2)
    n_lin = max(1, math.ceil(alt_km / lado_km))
    n_col = max(1, math.ceil(larg_km / lado_km))

    d_lat = (n - s) / n_lin
    d_lon = (e - w) / n_col

    # ~300 m de costura, para nao cortar estrada na divisa
    ov_lat = 0.003
    ov_lon = 0.003

    out = []
    for i in range(n_lin):
        for j in range(n_col):
            out.append((
                s + i * d_lat - (ov_lat if i > 0 else 0),
                w + j * d_lon - (ov_lon if j > 0 else 0),
                s + (i + 1) * d_lat + (ov_lat if i < n_lin - 1 else 0),
                w + (j + 1) * d_lon + (ov_lon if j < n_col - 1 else 0),
            ))
    return out


def estimar(bbox, area_km2: float = AREA_QUADRICULA_KM2) -> Dict:
    """Quantas consultas, quanto tempo, quanto disco — antes de começar."""
    import math
    s, w, n, e = bbox
    lat_med = (s + n) / 2
    alt = (n - s) * 110.6
    larg = (e - w) * 111.3 * max(math.cos(math.radians(lat_med)), 0.1)
    km2 = alt * larg
    quads = _quadricular(bbox, area_km2)
    # ~1.550 trechos por 1.000 km2 em area rural do semiarido; ~800 B cada
    trechos = km2 * 1.55
    # Custo real de uma consulta: ~12 s de setup + ~1 s por 130 km2 de area
    # rural. Usar um valor fixo de 25 s subestimava quadricula grande e
    # prometia tempo que nao se cumpre.
    area_por_quad = km2 / max(len(quads), 1)
    seg_por_quad = 12 + area_por_quad / 130.0
    return {
        "km2": km2,
        "largura_km": larg,
        "altura_km": alt,
        "quadriculas": len(quads),
        "trechos_estimados": int(trechos),
        "mb_estimados": trechos * 0.0008,
        "minutos_estimados": len(quads) * (seg_por_quad + PAUSA_ENTRE_S) / 60.0,
    }


def _baixar_quad(q, prog=None, pc=0, k=0, total=1, nivel=0):
    """
    Baixa uma quadricula. Se der 504 (grande demais), subdivide em 4 e
    tenta de novo.

    Desistir no 504 seria burro: o servidor esta dizendo exatamente o que
    fazer. Area de malha densa (uma cidade no meio da quadricula) estoura o
    timeout mesmo com quadricula de tamanho normal.
    """
    for srv in SERVIDORES_OVERPASS:
        try:
            st, corpo = _http_post(srv, _query(q), TIMEOUT_PADRAO)
            if st == 200 and corpo:
                try:
                    return (json.loads(corpo).get("elements") or []), ""
                except Exception:
                    return None, "resposta corrompida"
            if st == 504 and nivel < 2:
                # Grande demais: quebra em 4 e tenta cada pedaco
                if prog:
                    prog(pc, f"Pedaço {k+1} denso — dividindo em 4")
                s_, w_, n_, e_ = q
                mlat = (s_ + n_) / 2
                mlon = (w_ + e_) / 2
                filhos = [(s_, w_, mlat, mlon), (s_, mlon, mlat, e_),
                          (mlat, w_, n_, mlon), (mlat, mlon, n_, e_)]
                juntos = []
                for fq in filhos:
                    time.sleep(PAUSA_ENTRE_S)
                    els, _ = _baixar_quad(fq, prog, pc, k, total, nivel + 1)
                    if els:
                        juntos.extend(els)
                return (juntos, "") if juntos else (None, "504 mesmo dividido")
            if st == 429:
                # Ocupado: espera e tenta o proximo espelho
                time.sleep(8)
                continue
        except Exception as ex:
            ultimo = type(ex).__name__
    return None, "servidor não respondeu"


def baixar_area_grande(bbox, callback=None, cancelado=None,
                       area_km2: float = AREA_QUADRICULA_KM2,
                       usar_cache: bool = True) -> Tuple[str, Dict]:
    """
    Baixa uma area grande em quadriculas e junta tudo num GeoPackage.

    callback(pct, msg) -> progresso
    cancelado() -> True para abortar

    Retomavel: cada quadricula bem-sucedida e gravada em disco. Se cair na
    quadricula 80 de 126, a proxima tentativa aproveita as 79 anteriores.
    Uma hora de download nao pode ser perdida por uma queda de rede.
    """
    if not QGIS_OK:
        raise ErroOverpass("precisa do QGIS")

    if usar_cache:
        achado = buscar_no_cache(bbox)
        if achado:
            cam, info = achado
            info = dict(info)
            info["do_cache"] = True
            return cam, info

    quads = _quadricular(bbox, area_km2)
    chave = _chave_cache(bbox)
    gpkg = os.path.join(pasta_cache(), f"estradas_{chave}.gpkg")
    meta = gpkg + ".json"
    parciais = os.path.join(pasta_cache(), f"_parcial_{chave}")
    os.makedirs(parciais, exist_ok=True)

    def prog(p, msg=""):
        if callback:
            callback(p, msg)

    elems_todos = []
    vistos = set()          # osm_id: a costura entre quadriculas duplica ways
    n_ok = n_pulou = 0

    for k, q in enumerate(quads):
        if cancelado and cancelado():
            raise ErroOverpass("cancelado pelo usuário")

        pc = int(5 + 85 * k / len(quads))
        cache_q = os.path.join(parciais, f"q{k:04d}.json")

        # Ja baixado numa tentativa anterior?
        if os.path.exists(cache_q):
            try:
                with open(cache_q, encoding="utf-8") as f:
                    els = json.load(f)
                for el in els:
                    if el.get("id") not in vistos:
                        vistos.add(el.get("id"))
                        elems_todos.append(el)
                n_pulou += 1
                prog(pc, f"Pedaço {k+1}/{len(quads)} (já tinha)")
                continue
            except Exception:
                pass

        prog(pc, f"Baixando pedaço {k+1} de {len(quads)}...")

        els, erro = _baixar_quad(q, prog, pc, k, len(quads))

        if els is None:
            # Nao aborta tudo por um pedaco: registra e segue. Melhor 90%
            # das estradas que nenhuma.
            prog(pc, f"Pedaço {k+1} falhou ({erro}) — continuando")
            time.sleep(PAUSA_ENTRE_S)
            continue

        try:
            with open(cache_q, "w", encoding="utf-8") as f:
                json.dump(els, f)
        except Exception:
            pass

        for el in els:
            if el.get("id") not in vistos:
                vistos.add(el.get("id"))
                elems_todos.append(el)
        n_ok += 1

        if k < len(quads) - 1:
            time.sleep(PAUSA_ENTRE_S)

    if not elems_todos:
        raise ErroOverpass(
            "nenhuma estrada baixada. Verifique a internet e tente de novo — "
            "o que já veio fica guardado.")

    prog(92, f"Montando {len(elems_todos)} trechos...")
    caminho = _gravar_gpkg(elems_todos, gpkg)

    info = {
        "trechos": len(elems_todos),
        "bbox": list(bbox),
        "baixado_em": time.strftime("%Y-%m-%d %H:%M"),
        "quadriculas": len(quads),
        "quadriculas_ok": n_ok + n_pulou,
        "quadriculas_falharam": len(quads) - n_ok - n_pulou,
        "margem_km": 0,
        "atribuicao": "© OpenStreetMap contributors (ODbL)",
        "do_cache": False,
    }
    try:
        with open(meta, "w", encoding="utf-8") as f:
            json.dump(info, f, ensure_ascii=False, indent=1)
    except Exception:
        pass

    # Limpa os parciais so quando deu tudo certo
    if info["quadriculas_falharam"] == 0:
        try:
            for f in os.listdir(parciais):
                os.remove(os.path.join(parciais, f))
            os.rmdir(parciais)
        except OSError:
            pass

    prog(100, "Pronto.")
    return caminho, info


# Bbox aproximada dos estados. ATENCAO: e um RETANGULO, e estado nao e
# retangulo. O Piaui tem 251.500 km2, mas sua bbox tem 562.000 — mais da
# metade cai no Maranhao, Ceara e Bahia. Baixar "o estado" pela bbox e
# baixar o dobro do necessario. A interface avisa isso.
#
# Fonte: limites do IBGE, arredondados para fora.
ESTADOS = {
    "Piauí":        (-10.93, -45.99, -2.74, -40.37),
    "Maranhão":     (-10.27, -48.76, -1.04, -41.79),
    "Pernambuco":   (-9.48, -41.36, -7.15, -34.79),
    "Ceará":        (-7.86, -41.42, -2.78, -37.25),
    "Bahia":        (-18.35, -46.62, -8.53, -37.34),
    "Alagoas":      (-10.50, -38.24, -8.81, -35.15),
    "Sergipe":      (-11.57, -38.24, -9.51, -36.39),
    "Paraíba":      (-8.30, -38.77, -6.02, -34.79),
    "Rio Grande do Norte": (-6.99, -38.58, -4.83, -34.97),
}
