# -*- coding: utf-8 -*-
#
# PipaRouter — roteirização de caminhões-pipa no QGIS
# Copyright (C) 2025  Antonio A. Coelho Neto
#
# Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
# sob os termos da GNU General Public License versão 2 ou posterior.
# Veja o arquivo LICENSE, ou <https://www.gnu.org/licenses/gpl-2.0.html>.
#
"""
Solver de roteirizacao de caminhoes-pipa.

Problema: CVRP com capacidade, janelas de tempo, entrega fracionada (split
delivery), multiplas viagens por veiculo e frota heterogenea.

Isto e NP-dificil. Nao buscamos o otimo global — buscamos uma solucao boa em
tempo aceitavel dentro do QGIS, sem dependencias externas (OR-Tools nao vem
empacotado com o QGIS e quebraria o requisito de operacao offline).

Algoritmo:
  1. Construcao: Clarke-Wright savings paralelo, adaptado para frota
     heterogenea e demanda fracionavel.
  2. Melhoria: busca local com 2-opt (intra-rota) e Or-opt (realocacao de
     1-3 paradas, intra e inter-rota).
  3. Multiplas viagens: apos esgotar a capacidade, o caminhao retorna a base,
     recarrega (tempo = volume/vazao_enchimento) e reinicia, ate a jornada.

Regra de prioridade: demandas criticas (prioridade 3) sao alocadas primeiro,
antes do savings, garantindo atendimento mesmo com frota insuficiente.
"""

from typing import Dict, List, Optional, Sequence, Tuple

from .models import (
    Base,
    Caminhao,
    Demanda,
    ParametrosOperacionais,
    Parada,
    Rota,
    Solucao,
    Viagem,
)

# Tolerancia numerica para comparacao de volumes/tempos
EPS = 1e-6


class SolverPipa:
    """
    Uso:
        s = SolverPipa(bases, demandas, frota, params, matriz)
        solucao = s.resolver()
    """

    def __init__(
        self,
        bases: Sequence[Base],
        demandas: Sequence[Demanda],
        frota: Sequence[Caminhao],
        params: ParametrosOperacionais,
        matriz,                       # MatrizDistancia
        indice: Dict[Tuple[str, int], int] = None,
        callback_progresso=None,
    ):
        self.bases = {b.id: b for b in bases}
        self.demandas = {d.id: d for d in demandas}
        self.frota = [c for c in frota if c.disponivel]
        self.p = params
        self.matriz = matriz
        self.callback = callback_progresso
        # A fonte oferece tempo real por classe de via, ou so distancia?
        self._tem_tempo = hasattr(matriz, "tempo")

        # indice[("base", id)] -> linha na matriz; indice[("dem", id)] -> linha
        self.idx = indice or {}

        self._validar()

        # Volume restante por demanda (mutavel durante a resolucao)
        self.restante: Dict[int, float] = {
            d.id: d.volume for d in demandas
        }

    # ------------------------------------------------------------------
    # Validacao
    # ------------------------------------------------------------------

    def _validar(self):
        if not self.bases:
            raise ValueError("Nenhuma base de carregamento definida.")
        if not self.demandas:
            raise ValueError("Nenhum ponto de demanda definido.")
        if not self.frota:
            raise ValueError("Nenhum caminhao disponivel na frota.")

        for c in self.frota:
            if c.base_id not in self.bases:
                raise ValueError(
                    f"Caminhao '{c.placa}' referencia base inexistente "
                    f"(id={c.base_id})."
                )

        cap_max = max(c.capacidade for c in self.frota)
        for d in self.demandas.values():
            if d.volume > cap_max and not d.permite_split:
                raise ValueError(
                    f"Demanda '{d.nome}' ({d.volume} m3) excede a maior "
                    f"capacidade da frota ({cap_max} m3) e nao permite "
                    f"fracionamento. Habilite o split ou revise o volume."
                )

    # ------------------------------------------------------------------
    # Acesso a distancia
    # ------------------------------------------------------------------

    def _d(self, tipo_a: str, id_a: int, tipo_b: str, id_b: int) -> float:
        return self.matriz.dist(self.idx[(tipo_a, id_a)], self.idx[(tipo_b, id_b)])

    def _tempo_entre(self, tipo_a: str, id_a: int,
                     tipo_b: str, id_b: int) -> float:
        """
        Tempo de viagem em minutos entre dois pontos.

        Se a fonte for um roteador com matriz de tempo por classe de via,
        usa o tempo REAL da estrada. Senao, converte distancia por velocidade
        media — menos preciso, mas e o que ha sem malha viaria.
        """
        i = self.idx[(tipo_a, id_a)]
        j = self.idx[(tipo_b, id_b)]
        if self._tem_tempo:
            return self.matriz.tempo(i, j)
        return self.p.tempo_viagem_min(self.matriz.dist(i, j))

    def _t(self, dist_km: float) -> float:
        return self.p.tempo_viagem_min(dist_km)

    # ------------------------------------------------------------------
    # Tempo de atendimento
    # ------------------------------------------------------------------

    def _tempo_atendimento(self, cam: Caminhao, volume: float) -> float:
        """
        Tempo total na parada = FIXO + VARIAVEL.

        FIXO     : manobra, posicionamento, engate/desengate de mangote,
                   conferencia com o beneficiario. Independe do volume.
        VARIAVEL : volume / vazao_descarga. Este e o tempo enchendo o
                   reservatorio do usuario.
        """
        return self.p.tempo_fixo_parada + cam.tempo_descarga_min(volume)

    # ------------------------------------------------------------------
    # Construcao: Clarke-Wright savings
    # ------------------------------------------------------------------

    def _savings(self, base_id: int, ids: List[int]) -> List[Tuple[float, int, int]]:
        """
        s(i,j) = d(base,i) + d(base,j) - d(i,j)

        Quanto maior, mais vantajoso unir i e j na mesma rota.
        """
        out = []
        for a in range(len(ids)):
            for b in range(a + 1, len(ids)):
                i, j = ids[a], ids[b]
                s = (self._d("base", base_id, "dem", i)
                     + self._d("base", base_id, "dem", j)
                     - self._d("dem", i, "dem", j))
                out.append((s, i, j))
        out.sort(reverse=True, key=lambda t: t[0])
        return out

    # ------------------------------------------------------------------
    # Avaliacao de uma sequencia
    # ------------------------------------------------------------------

    def _avaliar(
        self,
        cam: Caminhao,
        base: Base,
        seq: List[Tuple[int, float]],   # [(demanda_id, volume), ...]
        t_inicio: float,
    ) -> Optional[Viagem]:
        """
        Simula uma viagem e devolve o objeto Viagem, ou None se inviavel
        (estoura jornada ou janela de tempo).
        """
        if not seq:
            return None

        vol_total = sum(v for _, v in seq)
        if vol_total > cam.capacidade + EPS:
            return None

        t_ench = base.tempo_enchimento_min(vol_total)
        t = t_inicio + t_ench
        partida = t

        paradas: List[Parada] = []
        dist_acum = 0.0
        anterior = ("base", base.id)

        for dem_id, vol in seq:
            d = self.demandas[dem_id]
            dist = self._d(anterior[0], anterior[1], "dem", dem_id)
            dist_acum += dist
            t += self._tempo_entre(anterior[0], anterior[1], "dem", dem_id)
            chegada = t

            espera = 0.0
            if d.janela_inicio is not None and chegada < d.janela_inicio:
                espera = d.janela_inicio - chegada
                t = d.janela_inicio

            if d.janela_fim is not None and t > d.janela_fim + EPS:
                return None   # perdeu a janela

            inicio_serv = t
            t += self._tempo_atendimento(cam, vol)

            paradas.append(Parada(
                demanda_id=dem_id,
                nome=d.nome,
                x=d.x, y=d.y,
                volume_entregue=vol,
                chegada=chegada,
                inicio_servico=inicio_serv,
                saida=t,
                espera=espera,
                dist_desde_anterior=dist,
                parcial=(vol < d.volume - EPS),
            ))
            anterior = ("dem", dem_id)

        dist_volta = self._d(anterior[0], anterior[1], "base", base.id)
        dist_acum += dist_volta
        t += self._tempo_entre(anterior[0], anterior[1], "base", base.id)

        if t - self.p.jornada_inicio > cam.jornada_max + EPS:
            return None   # estourou a jornada

        return Viagem(
            base_id=base.id,
            volume_carregado=vol_total,
            tempo_enchimento=t_ench,
            paradas=paradas,
            partida_base=partida,
            retorno_base=t,
            distancia=dist_acum,
        )

    # ------------------------------------------------------------------
    # Resolucao
    # ------------------------------------------------------------------

    def resolver(self) -> Solucao:
        sol = Solucao()

        # Caminhoes ordenados: maior capacidade primeiro (atende mais por viagem)
        frota = sorted(self.frota, key=lambda c: -c.capacidade)

        # Demandas ordenadas: criticas primeiro, depois maiores volumes
        pendentes = sorted(
            self.demandas.values(),
            key=lambda d: (-d.prioridade, -d.volume),
        )
        ordem_ids = [d.id for d in pendentes]

        for n_cam, cam in enumerate(frota):
            base = self.bases[cam.base_id]
            rota = Rota(caminhao_id=cam.id, placa=cam.placa)
            t_atual = self.p.jornada_inicio

            while True:
                disponiveis = [
                    i for i in ordem_ids
                    if self.restante.get(i, 0) > EPS
                ]
                if not disponiveis:
                    break

                viagem = self._montar_viagem(cam, base, disponiveis, t_atual)
                if viagem is None:
                    break

                # Baixa os volumes entregues
                for par in viagem.paradas:
                    self.restante[par.demanda_id] -= par.volume_entregue
                    if self.restante[par.demanda_id] < EPS:
                        self.restante[par.demanda_id] = 0.0

                rota.viagens.append(viagem)
                t_atual = viagem.retorno_base

                if not self.p.permite_multiplas_viagens:
                    break

            if rota.viagens:
                self._melhorar_rota(cam, base, rota)
                sol.rotas.append(rota)

            if self.callback:
                self.callback(int(100 * (n_cam + 1) / len(frota)))

        # Registra o que sobrou
        for did, falta in self.restante.items():
            if falta > EPS:
                d = self.demandas[did]
                motivo = self._diagnosticar(d, falta)
                sol.nao_atendidas.append((did, d.nome, round(falta, 3), motivo))

        return sol

    def _montar_viagem(
        self,
        cam: Caminhao,
        base: Base,
        disponiveis: List[int],
        t_inicio: float,
    ) -> Optional[Viagem]:
        """
        Monta UMA viagem por savings, respeitando capacidade e jornada.
        Retorna None se nenhuma parada couber.
        """
        seq: List[Tuple[int, float]] = []
        cap_livre = cam.capacidade

        # Semente: melhor razao entre valor entregue e custo de acesso.
        #
        # Escolher apenas por prioridade leva o caminhao a cruzar o municipio
        # para atender 1 ponto critico distante, queimando a jornada inteira e
        # deixando 10 pontos proximos sem agua. Ponderamos prioridade CONTRA o
        # km ate a base: a prioridade pesa, mas nao a qualquer custo.
        semente = None
        melhor_score = None
        for i in disponiveis:
            vol = min(self.restante[i], cap_livre)
            if vol < EPS:
                continue
            d = self.demandas[i]
            if not d.permite_split and self.restante[i] > cap_livre:
                continue
            if self._avaliar(cam, base, [(i, vol)], t_inicio) is None:
                continue

            dist_base = self._d("base", base.id, "dem", i)
            # peso: critica=6, alta=3, normal=1
            peso = {1: 1.0, 2: 3.0, 3: 6.0}[d.prioridade]
            score = (peso * vol) / max(dist_base, 0.1)

            if melhor_score is None or score > melhor_score:
                melhor_score, semente = score, (i, vol)

        if semente is None:
            return None

        seq.append(semente)
        cap_livre -= semente[1]
        melhor = self._avaliar(cam, base, seq, t_inicio)

        # Insercao por menor custo marginal ponderado pela prioridade.
        #
        # A cada passo, testamos TODOS os pontos pendentes em TODAS as posicoes
        # e inserimos aquele com melhor razao (volume x prioridade)/(km extra).
        # Isso preenche o caminhao com os pontos que ficam "no caminho", em vez
        # de seguir a ordem rigida do savings classico.
        while cap_livre >= self.p.volume_min_parcial:
            ja = {x for x, _ in seq}
            melhor_ins = None   # (score, pos, dem_id, vol, viagem)

            for i in disponiveis:
                if i in ja or self.restante.get(i, 0) < EPS:
                    continue
                d = self.demandas[i]
                vol = min(self.restante[i], cap_livre)
                if not d.permite_split and self.restante[i] > cap_livre:
                    continue

                # Rejeita entrega parcial irrisoria. Deslocar um pipa por
                # 35 km para descarregar 0,9 m3 nao e uma operacao real: o
                # ponto continua desabastecido e o km foi gasto. Se nao cabe
                # um volume minimo util, o ponto fica para a proxima viagem.
                parcial = vol < self.restante[i] - EPS
                if parcial and vol < self.p.volume_min_parcial:
                    continue

                peso = {1: 1.0, 2: 3.0, 3: 6.0}[d.prioridade]
                for pos in range(len(seq) + 1):
                    cand = seq[:pos] + [(i, vol)] + seq[pos:]
                    v = self._avaliar(cam, base, cand, t_inicio)
                    if v is None:
                        continue
                    extra = v.distancia - melhor.distancia
                    score = (peso * vol) / max(extra, 0.1)
                    if melhor_ins is None or score > melhor_ins[0]:
                        melhor_ins = (score, pos, i, vol, v)

            if melhor_ins is None:
                break

            _, pos, dem_id, vol, v = melhor_ins
            seq.insert(pos, (dem_id, vol))
            cap_livre -= vol
            melhor = v

        return melhor

    # ------------------------------------------------------------------
    # Busca local
    # ------------------------------------------------------------------

    def _melhorar_rota(self, cam: Caminhao, base: Base, rota: Rota,
                       max_iter: int = 60):
        """2-opt + Or-opt dentro de cada viagem."""
        for vi, viagem in enumerate(rota.viagens):
            seq = [(p.demanda_id, p.volume_entregue) for p in viagem.paradas]
            if len(seq) < 3:
                continue

            t0 = viagem.partida_base - viagem.tempo_enchimento
            atual = self._avaliar(cam, base, seq, t0)
            if atual is None:
                continue

            melhorou = True
            it = 0
            while melhorou and it < max_iter:
                melhorou = False
                it += 1

                # 2-opt: inverte segmentos
                for i in range(len(seq) - 1):
                    for j in range(i + 2, len(seq)):
                        cand = seq[:i + 1] + seq[i + 1:j + 1][::-1] + seq[j + 1:]
                        v = self._avaliar(cam, base, cand, t0)
                        if v and v.distancia < atual.distancia - 1e-4:
                            seq, atual, melhorou = cand, v, True

                # Or-opt: move blocos de 1..3 paradas
                for tam in (1, 2, 3):
                    for i in range(len(seq) - tam + 1):
                        bloco = seq[i:i + tam]
                        resto = seq[:i] + seq[i + tam:]
                        for pos in range(len(resto) + 1):
                            if pos == i:
                                continue
                            cand = resto[:pos] + bloco + resto[pos:]
                            v = self._avaliar(cam, base, cand, t0)
                            if v and v.distancia < atual.distancia - 1e-4:
                                seq, atual, melhorou = cand, v, True
                                break

            rota.viagens[vi] = atual

        # Reencadeia os tempos entre viagens sucessivas
        t = self.p.jornada_inicio
        for vi, viagem in enumerate(rota.viagens):
            seq = [(p.demanda_id, p.volume_entregue) for p in viagem.paradas]
            v = self._avaliar(cam, base, seq, t)
            if v is None:
                rota.viagens = rota.viagens[:vi]
                break
            rota.viagens[vi] = v
            t = v.retorno_base

    # ------------------------------------------------------------------
    # Diagnostico
    # ------------------------------------------------------------------

    def _diagnosticar(self, d: Demanda, falta: float) -> str:
        cap_max = max(c.capacidade for c in self.frota)
        if not d.permite_split and d.volume > cap_max:
            return f"Volume ({d.volume} m3) > maior caminhao ({cap_max} m3), split desabilitado"
        if d.janela_fim is not None:
            return "Janela de tempo inviavel ou jornada esgotada"
        return "Capacidade/jornada da frota esgotada"


# ----------------------------------------------------------------------
# Indicadores
# ----------------------------------------------------------------------

def indicadores(sol: Solucao, demandas: Sequence[Demanda],
                frota: Sequence[Caminhao],
                params: ParametrosOperacionais) -> Dict:
    """KPIs operacionais da solucao."""
    vol_sol = sum(d.volume for d in demandas)
    vol_ent = sol.volume_entregue
    disp = [c for c in frota if c.disponivel]

    tempo_total = sum(r.tempo_total for r in sol.rotas)
    t_serv = sum(r.tempo_servico for r in sol.rotas)
    t_esp0 = sum(r.tempo_espera for r in sol.rotas)
    t_ench0 = sum(v.tempo_enchimento for r in sol.rotas for v in r.viagens)
    # Tempo dirigindo = o que sobra. Derivar de distancia/velocidade media
    # daria numero diferente do cronograma quando o tempo vem da malha viaria.
    t_dir = max(tempo_total - t_serv - t_esp0 - t_ench0, 0.0)
    t_esp = sum(r.tempo_espera for r in sol.rotas)
    t_ench = sum(v.tempo_enchimento for r in sol.rotas for v in r.viagens)

    cap_ofertada = sum(c.capacidade for c in disp)

    return {
        "volume_solicitado_m3": round(vol_sol, 2),
        "volume_entregue_m3": round(vol_ent, 2),
        "atendimento_pct": round(100 * vol_ent / vol_sol, 1) if vol_sol else 0.0,
        "pontos_solicitados": len(demandas),
        "pontos_atendidos": len(demandas) - len(sol.nao_atendidas),
        "pontos_nao_atendidos": len(sol.nao_atendidas),
        "caminhoes_disponiveis": len(disp),
        "caminhoes_usados": sol.caminhoes_usados,
        "viagens_totais": sum(len(r.viagens) for r in sol.rotas),
        "distancia_total_km": round(sol.distancia_total, 2),
        "km_por_m3": round(sol.distancia_total / vol_ent, 3) if vol_ent else 0.0,
        "tempo_total_frota_h": round(tempo_total / 60, 2),
        "tempo_dirigindo_h": round(t_dir / 60, 2),
        "tempo_atendimento_h": round(t_serv / 60, 2),
        "tempo_enchimento_h": round(t_ench / 60, 2),
        "tempo_espera_h": round(t_esp / 60, 2),
        "produtividade_pct": round(100 * (t_serv) / tempo_total, 1) if tempo_total else 0.0,
        "ocupacao_media_pct": round(
            100 * vol_ent / (cap_ofertada * max(
                sum(len(r.viagens) for r in sol.rotas) / max(len(disp), 1), 1)), 1
        ) if cap_ofertada else 0.0,
        "custo_total_rs": round(sum(
            r.distancia_total * next((c.custo_km for c in frota
                                      if c.id == r.caminhao_id), 0)
            for r in sol.rotas
        ), 2),
    }
