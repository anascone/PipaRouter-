# -*- coding: utf-8 -*-
#
# PipaRouter — roteirização de caminhões-pipa no QGIS
# Copyright (C) 2025  Antonio A. Coelho Neto
#
# Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
# sob os termos da GNU General Public License versão 2 ou posterior.
# Veja o arquivo LICENSE, ou <https://www.gnu.org/licenses/gpl-2.0.html>.
#
"""
Roteamento sobre malha viaria — grafo proprio.

POR QUE NAO USAR O QgsGraphBuilder
-----------------------------------
O builder do QGIS monta um grafo topologico e descarta a ligacao entre aresta
e feicao de origem. Para desenhar o tracado real era preciso recuperar essa
ligacao depois, por proximidade espacial — fragil, e foi a causa das rotas
saindo retas.

Aqui o grafo e construido na mao e cada aresta GUARDA a polilinha que a
originou. Nada a reconstruir: o tracado sai da propria estrutura.

Beneficio adicional: sendo Python puro, a logica de grafo e testavel fora do
QGIS. Antes, so dava para testar com mock — que prova apenas que o mock
concorda comigo.

UNIDADES
    distancia .. metros interno, km na interface
    tempo ...... segundos interno, minutos na interface
    coords ..... EPSG:4326 na fronteira, UTM internamente
"""

import math
from typing import Dict, List, Optional, Sequence, Tuple

try:
    from qgis.core import (
        QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeature,
        QgsGeometry, QgsPointXY, QgsProject, QgsSpatialIndex,
    )
    QGIS_OK = True
except ImportError:
    QGIS_OK = False


VELOCIDADE_PADRAO = {
    "motorway": 70.0, "motorway_link": 50.0,
    "trunk": 65.0, "trunk_link": 45.0,
    "primary": 60.0, "primary_link": 40.0,
    "secondary": 50.0, "secondary_link": 35.0,
    "tertiary": 45.0, "tertiary_link": 30.0,
    "unclassified": 35.0, "residential": 25.0, "living_street": 15.0,
    "service": 20.0, "track": 18.0, "path": 12.0, "road": 30.0,
}

PAVIMENTADA = {
    "motorway", "motorway_link", "trunk", "trunk_link", "primary",
    "primary_link", "secondary", "secondary_link", "tertiary",
    "tertiary_link", "residential", "living_street",
}
JA_NAO_PAVIMENTADA = {"track", "path"}

PISO_ASFALTO = {"asphalt", "paved", "concrete", "paving_stones", "asfalto",
                "concreto"}
PISO_COMPACTADO = {"compacted", "fine_gravel", "gravel", "pebblestone",
                   "cascalho", "picarra"}
PISO_SOLTO = {"unpaved", "dirt", "ground", "earth", "grass", "terra", "chao"}
PISO_PESSIMO = {"sand", "mud", "areia", "barro", "atoleiro"}

VELOCIDADE_FALLBACK = 30.0

CAMPOS_CLASSE = ("highway", "fclass", "type", "tipo", "classe", "road_type",
                 "class", "categoria")
CAMPOS_PISO = ("surface", "piso", "pavimento", "superficie", "revestimento")


def velocidade_da_via(feat, campo_classe, campo_piso, tabela,
                      fator_terra=1.0):
    """
    (velocidade_km_h, pavimentada) de uma feicao.

    O fator de terra so entra quando o piso CONTRADIZ a classe. Uma `track`
    ja vale 18 km/h por ser carrocavel; multiplicar de novo por 0.6 daria
    10.8 e mandaria o caminhao sair de madrugada sem necessidade.
    """
    classe = None
    if campo_classe:
        try:
            v = feat[campo_classe]
            classe = str(v).strip().lower() if v else None
        except (KeyError, TypeError, IndexError):
            classe = None

    vel = tabela.get(classe, VELOCIDADE_FALLBACK) if classe else VELOCIDADE_FALLBACK
    classe_pav = classe in PAVIMENTADA if classe else True
    pav = classe_pav

    piso = ""
    if campo_piso:
        try:
            s = feat[campo_piso]
            piso = str(s).strip().lower() if s else ""
        except (KeyError, TypeError, IndexError):
            piso = ""

    if piso:
        if piso in PISO_ASFALTO:
            pav = True
            if not classe_pav and classe not in JA_NAO_PAVIMENTADA:
                vel *= 1.10
        elif piso in PISO_COMPACTADO:
            pav = False
            if classe_pav:
                vel *= (1.0 + fator_terra) / 2.0
            elif classe in JA_NAO_PAVIMENTADA:
                vel *= 1.15
        elif piso in PISO_SOLTO:
            pav = False
            if classe_pav or classe not in JA_NAO_PAVIMENTADA:
                vel *= fator_terra
        elif piso in PISO_PESSIMO:
            pav = False
            vel *= (fator_terra * 0.75) if classe_pav else 0.75
    else:
        if classe in JA_NAO_PAVIMENTADA:
            pav = False

    return max(vel, 5.0), pav


def detectar_campo(camada, candidatos):
    """Primeiro campo da camada que bate com a lista."""
    if camada is None:
        return None
    try:
        nomes = {f.name().lower(): f.name() for f in camada.fields()}
    except Exception:
        return None
    for c in candidatos:
        if c in nomes:
            return nomes[c]
    return None


class Aresta:
    """Trecho de estrada entre dois nos. GUARDA a polilinha."""
    __slots__ = ("no_a", "no_b", "pts", "comp", "vel", "pav", "tempo")

    def __init__(self, no_a, no_b, pts, comp, vel, pav):
        self.no_a = no_a
        self.no_b = no_b
        self.pts = pts
        self.comp = comp
        self.vel = vel
        self.pav = pav
        self.tempo = comp / (vel / 3.6)

    def geom_de(self, origem):
        return self.pts if origem == self.no_a else list(reversed(self.pts))

    def outro(self, no):
        return self.no_b if no == self.no_a else self.no_a


class Trecho:
    __slots__ = ("dist_km", "tempo_min", "geometria", "km_pav", "km_terra",
                 "aproximado", "motivo")

    def __init__(self, dist_km=0.0, tempo_min=0.0, geometria=None,
                 km_pav=0.0, km_terra=0.0, aproximado=False, motivo=""):
        self.dist_km = dist_km
        self.tempo_min = tempo_min
        self.geometria = geometria or []
        self.km_pav = km_pav
        self.km_terra = km_terra
        self.aproximado = aproximado
        self.motivo = motivo

    @property
    def velocidade_efetiva(self):
        if self.tempo_min <= 0:
            return 0.0
        return self.dist_km / (self.tempo_min / 60.0)


class GrafoViario:
    """
    Grafo puro-Python. Sem dependencia de QGIS — testavel de verdade.

    Recebe linhas ja em coordenadas metricas:
        linhas = [([(x,y), ...], vel_kmh, pavimentada), ...]
    """

    SNAP = 0.5   # metros: vertices mais proximos que isso sao o mesmo no

    def __init__(self, linhas, snap=None):
        if snap is not None:
            self.SNAP = snap
        self.nos: List[Tuple[float, float]] = []
        self.adj: Dict[int, List[int]] = {}
        self.arestas: List[Aresta] = []
        self._no_id: Dict[Tuple[float, float], int] = {}
        self._dij: Dict[int, Tuple] = {}
        self.stats = {"linhas": 0, "curtas": 0}
        self._montar(linhas)

    def _q(self, p):
        return (round(p[0] / self.SNAP) * self.SNAP,
                round(p[1] / self.SNAP) * self.SNAP)

    def _get_no(self, p):
        if p not in self._no_id:
            self._no_id[p] = len(self.nos)
            self.nos.append(p)
            self.adj[self._no_id[p]] = []
        return self._no_id[p]

    def _montar(self, linhas):
        from collections import defaultdict

        limpas = []
        uso = defaultdict(int)
        for pts, vel, pav in linhas:
            q = [self._q(p) for p in pts]
            lim = [q[0]]
            for p in q[1:]:
                if p != lim[-1]:
                    lim.append(p)
            if len(lim) < 2:
                self.stats["curtas"] += 1
                continue
            limpas.append((lim, vel, pav))
            for p in lim:
                uso[p] += 1
        self.stats["linhas"] = len(limpas)

        for pts, vel, pav in limpas:
            # quebra nos extremos e em vertices compartilhados (cruzamentos)
            cortes = [0]
            for k in range(1, len(pts) - 1):
                if uso[pts[k]] > 1:
                    cortes.append(k)
            cortes.append(len(pts) - 1)

            for a, b in zip(cortes, cortes[1:]):
                seg = pts[a:b + 1]
                if len(seg) < 2:
                    continue
                na = self._get_no(seg[0])
                nb = self._get_no(seg[-1])
                if na == nb:
                    continue
                comp = sum(math.dist(p, q) for p, q in zip(seg, seg[1:]))
                if comp <= 0:
                    continue
                aid = len(self.arestas)
                self.arestas.append(Aresta(na, nb, seg, comp, vel, pav))
                self.adj[na].append(aid)
                self.adj[nb].append(aid)

    def dijkstra(self, origem):
        if origem in self._dij:
            return self._dij[origem]
        import heapq
        INF = float("inf")
        dist = [INF] * len(self.nos)
        prev = [-1] * len(self.nos)
        dist[origem] = 0.0
        pq = [(0.0, origem)]
        while pq:
            d, u = heapq.heappop(pq)
            if d > dist[u]:
                continue
            for aid in self.adj[u]:
                ar = self.arestas[aid]
                v = ar.outro(u)
                nd = d + ar.tempo
                if nd < dist[v]:
                    dist[v] = nd
                    prev[v] = aid
                    heapq.heappush(pq, (nd, v))
        self._dij[origem] = (dist, prev)
        return self._dij[origem]

    def caminho(self, ni, nj):
        """(lista de arestas na ordem, tempo_seg) ou (None, motivo)."""
        if ni == nj:
            return [], 0.0
        dist, prev = self.dijkstra(ni)
        if dist[nj] == float("inf"):
            return None, "sem caminho pela malha (rede partida)"
        out = []
        cur = nj
        guard = 0
        while cur != ni:
            aid = prev[cur]
            if aid < 0:
                return None, "caminho interrompido"
            out.append(aid)
            cur = self.arestas[aid].outro(cur)
            guard += 1
            if guard > 500000:
                return None, "caminho longo demais"
        out.reverse()
        return out, dist[nj]

    def polilinha(self, ni, arestas):
        """Costura a geometria das arestas na ordem de percurso."""
        pts = []
        atual = ni
        comp = m_pav = m_terra = 0.0
        for aid in arestas:
            ar = self.arestas[aid]
            for p in ar.geom_de(atual):
                if not pts or pts[-1] != p:
                    pts.append(p)
            comp += ar.comp
            if ar.pav:
                m_pav += ar.comp
            else:
                m_terra += ar.comp
            atual = ar.outro(atual)
        return pts, comp, m_pav, m_terra

    def no_mais_perto(self, alvo):
        melhor, md = -1, float("inf")
        for i, p in enumerate(self.nos):
            d = math.dist(alvo, p)
            if d < md:
                md, melhor = d, i
        return melhor, md

    def componentes(self):
        """Tamanho de cada pedaco desconexo, do maior para o menor."""
        visto = [False] * len(self.nos)
        out = []
        for s in range(len(self.nos)):
            if visto[s]:
                continue
            pilha, n = [s], 0
            visto[s] = True
            while pilha:
                u = pilha.pop()
                n += 1
                for aid in self.adj[u]:
                    v = self.arestas[aid].outro(u)
                    if not visto[v]:
                        visto[v] = True
                        pilha.append(v)
            out.append(n)
        out.sort(reverse=True)
        return out


class Roteador:
    """Envolve o GrafoViario com a leitura da camada QGIS e reprojecao."""

    def __init__(self, camada, campo_classe=None, campo_piso=None,
                 tabela_velocidade=None, fator_terra=0.6,
                 velocidade_fallback=30.0, fator_sinuosidade=1.3,
                 tolerancia_conexao=2000.0, callback=None):
        if not QGIS_OK:
            raise RuntimeError("Roteador exige QGIS.")
        self.camada = camada
        self.campo_classe = campo_classe or detectar_campo(camada, CAMPOS_CLASSE)
        self.campo_piso = campo_piso or detectar_campo(camada, CAMPOS_PISO)
        self.tabela = dict(VELOCIDADE_PADRAO)
        if tabela_velocidade:
            self.tabela.update(tabela_velocidade)
        self.fator_terra = fator_terra
        self.vel_fallback = velocidade_fallback
        self.fator_sinuos = fator_sinuosidade
        self.tol = tolerancia_conexao
        self.callback = callback

        self.pontos = []
        self.grafo = None
        self._entrada = []
        self._acesso_m = []
        self.avisos = []
        self.erros = []
        self.desconectados = []
        self._motivos = {}
        self.stats = {}

    def _crs_metrico(self):
        if not self.pontos:
            return QgsCoordinateReferenceSystem("EPSG:3857")
        lon = sum(x for x, _ in self.pontos) / len(self.pontos)
        lat = sum(y for _, y in self.pontos) / len(self.pontos)
        zona = int((lon + 180) / 6) + 1
        epsg = (32700 if lat < 0 else 32600) + zona
        crs = QgsCoordinateReferenceSystem("EPSG:%d" % epsg)
        return crs if crs.isValid() else QgsCoordinateReferenceSystem("EPSG:3857")

    def preparar(self, pontos_wgs84):
        self.pontos = list(pontos_wgs84)
        crs_m = self._crs_metrico()
        self.crs_metrico = crs_m
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        prj = QgsProject.instance()
        self._tr_para_m = QgsCoordinateTransform(wgs, crs_m, prj)
        self._tr_para_wgs = QgsCoordinateTransform(crs_m, wgs, prj)

        linhas = self._ler_camada()
        self.grafo = GrafoViario(linhas)
        self.stats.update({
            "feicoes_lidas": self.grafo.stats["linhas"],
            "linhas_curtas": self.grafo.stats["curtas"],
            "nos": len(self.grafo.nos),
            "arestas": len(self.grafo.arestas),
            "campo_classe": self.campo_classe,
            "campo_piso": self.campo_piso,
            "crs_metrico": crs_m.authid(),
        })
        if not self.grafo.arestas:
            self.erros.append(
                "Nenhum trecho de estrada foi montado a partir da camada.")
        self._amarrar()
        return self

    def _ler_camada(self):
        crs_lyr = self.camada.crs()
        tr = None
        if crs_lyr != self.crs_metrico:
            tr = QgsCoordinateTransform(crs_lyr, self.crs_metrico,
                                        QgsProject.instance())
        linhas = []
        n_vazia = 0
        for ft in self.camada.getFeatures():
            g = QgsGeometry(ft.geometry())
            if g.isEmpty():
                n_vazia += 1
                continue
            if tr:
                try:
                    g.transform(tr)
                except Exception:
                    n_vazia += 1
                    continue
            partes = ([g.asPolyline()] if not g.isMultipart()
                      else g.asMultiPolyline())
            vel, pav = velocidade_da_via(ft, self.campo_classe,
                                         self.campo_piso, self.tabela,
                                         self.fator_terra)
            for parte in partes:
                if len(parte) < 2:
                    continue
                linhas.append(([(p.x(), p.y()) for p in parte], vel, pav))
        self.stats["geometrias_vazias"] = n_vazia
        return linhas

    def _amarrar(self):
        """Liga cada ponto ao no de estrada mais proximo."""
        self._entrada = []
        self._acesso_m = []
        if not self.grafo.nos:
            self.desconectados = list(range(len(self.pontos)))
            self._entrada = [-1] * len(self.pontos)
            self._acesso_m = [float("inf")] * len(self.pontos)
            return

        sidx = None
        try:
            sidx = QgsSpatialIndex()
            for i, (x, y) in enumerate(self.grafo.nos):
                f = QgsFeature(i)
                f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
                sidx.addFeature(f)
        except Exception as e:
            self.avisos.append("Indice de nos indisponivel (%s); "
                               "busca por forca bruta." % e)
            sidx = None

        for i, (x, y) in enumerate(self.pontos):
            pm = self._tr_para_m.transform(QgsPointXY(x, y))
            alvo = (pm.x(), pm.y())
            melhor, md = -1, float("inf")
            cands = []
            if sidx:
                try:
                    cands = sidx.nearestNeighbor(QgsPointXY(alvo[0], alvo[1]), 8)
                except Exception:
                    cands = []
            if cands:
                for nid in cands:
                    if 0 <= nid < len(self.grafo.nos):
                        d = math.dist(alvo, self.grafo.nos[nid])
                        if d < md:
                            md, melhor = d, nid
            else:
                melhor, md = self.grafo.no_mais_perto(alvo)

            self._entrada.append(melhor)
            self._acesso_m.append(md)
            if melhor < 0:
                self.desconectados.append(i)
            elif md > self.tol:
                self.avisos.append(
                    "Ponto %d: estrada mapeada mais proxima a %.0f m. A rota "
                    "segue pela estrada; o acesso final nao esta na camada."
                    % (i, md))

    def _reta(self, i, j, motivo):
        self._motivos[motivo] = self._motivos.get(motivo, 0) + 1
        x1, y1 = self.pontos[i]
        x2, y2 = self.pontos[j]
        d = self._hav(x1, y1, x2, y2) * self.fator_sinuos
        vel = self.vel_fallback * 0.85
        return Trecho(d, (d / vel) * 60.0, [(x1, y1), (x2, y2)], 0.0, d,
                      True, motivo)

    @staticmethod
    def _hav(x1, y1, x2, y2):
        R = 6371.0088
        lo1, la1, lo2, la2 = map(math.radians, (x1, y1, x2, y2))
        a = (math.sin((la2 - la1) / 2) ** 2
             + math.cos(la1) * math.cos(la2) * math.sin((lo2 - lo1) / 2) ** 2)
        return 2 * R * math.asin(math.sqrt(a))

    def trecho(self, i, j):
        if i == j:
            return Trecho(0, 0, [self.pontos[i]], 0, 0, False)
        if not self.grafo or not self.grafo.arestas:
            return self._reta(i, j, "sem malha viaria")
        ni, nj = self._entrada[i], self._entrada[j]
        if ni < 0 or nj < 0:
            return self._reta(i, j, "ponto sem estrada por perto")
        if ni == nj:
            return self._reta(i, j, "pontos no mesmo acesso")

        arestas, r = self.grafo.caminho(ni, nj)
        if arestas is None:
            return self._reta(i, j, r)

        pts_m, comp, m_pav, m_terra = self.grafo.polilinha(ni, arestas)
        if not pts_m:
            return self._reta(i, j, "arestas sem geometria")

        geo = [self.pontos[i]]
        for x, y in pts_m:
            pw = self._tr_para_wgs.transform(QgsPointXY(x, y))
            xy = (pw.x(), pw.y())
            if geo[-1] != xy:
                geo.append(xy)
        if geo[-1] != self.pontos[j]:
            geo.append(self.pontos[j])

        acesso = self._acesso_m[i] + self._acesso_m[j]
        dist_km = (comp + acesso) / 1000.0
        tempo_min = r / 60.0
        if acesso > 0:
            tempo_min += (acesso / 1000.0) / max(self.vel_fallback * 0.6, 1) * 60.0

        return Trecho(dist_km, tempo_min, geo, m_pav / 1000.0,
                      (m_terra + acesso) / 1000.0, False)

    def resumo(self):
        r = dict(self.stats)
        comp = self.grafo.componentes() if self.grafo else []
        r.update({
            "n_pontos": len(self.pontos),
            "metodo": ("estrada (velocidade por tipo de via)"
                       if self.campo_classe else "estrada (velocidade unica)"),
            "pontos_fora_da_malha": len(self.desconectados),
            "motivos_de_reta": dict(self._motivos),
            "componentes": comp[:5],
            "n_componentes": len(comp),
            "avisos": self.avisos,
            "erros": self.erros,
        })
        fin = [a for a in self._acesso_m if a != float("inf")]
        r["acesso_max_m"] = round(max(fin), 0) if fin else 0
        return r

    def diagnostico(self):
        L = []
        s = self.stats
        if self.erros:
            return "\n".join("ERRO: " + e for e in self.erros)

        L.append("Estradas: %d linhas -> %d cruzamentos, %d trechos."
                 % (s.get("feicoes_lidas", 0), s.get("nos", 0),
                    s.get("arestas", 0)))
        cc = s.get("campo_classe")
        L.append("Tipo de via: campo '%s'." % cc if cc else
                 "Tipo de via NAO encontrado — todas as estradas na mesma "
                 "velocidade.")

        comp = self.grafo.componentes() if self.grafo else []
        if len(comp) > 1:
            tot = sum(comp)
            L.append("Rede em %d pedacos separados (maior tem %d de %d "
                     "cruzamentos = %.0f%%)."
                     % (len(comp), comp[0], tot, 100.0 * comp[0] / tot))
            if comp[0] < tot * 0.7:
                L.append("   A camada esta fragmentada. E o motivo tipico de "
                         "'rede partida'.")

        fin = [a for a in self._acesso_m if a != float("inf")]
        if fin:
            L.append("Acesso ate a estrada: menor %.0f m, maior %.0f m."
                     % (min(fin), max(fin)))

        if self._motivos:
            L.append("Trechos que sairam RETOS:")
            for m, n in sorted(self._motivos.items(), key=lambda t: -t[1]):
                L.append("   %dx — %s" % (n, m))
        else:
            L.append("Nenhum trecho saiu reto.")
        return "\n".join(L)

    def componentes(self):
        return self.grafo.componentes() if self.grafo else []
