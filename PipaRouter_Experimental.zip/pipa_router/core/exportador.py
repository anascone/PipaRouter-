# -*- coding: utf-8 -*-
#
# PipaRouter — roteirização de caminhões-pipa no QGIS
# Copyright (C) 2025  Antonio A. Coelho Neto
#
# Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
# sob os termos da GNU General Public License versão 2 ou posterior.
# Veja o arquivo LICENSE, ou <https://www.gnu.org/licenses/gpl-2.0.html>.
#
"""
Exportacao dos resultados: camadas QGIS, KML/KMZ para o motorista,
planilha para a programacao operacional.

Nenhuma dependencia externa: KML e XML escrito na mao, planilha em CSV/XLSX
via zipfile quando openpyxl nao estiver presente.
"""

import csv
import os
import zipfile
from typing import Dict, List, Optional, Sequence
from xml.sax.saxutils import escape

from .models import Base, Demanda, Solucao

# Paleta: cores distintas e legiveis sobre imagem de satelite
CORES = [
    "ff0000ff",  # vermelho  (KML = aabbggrr)
    "ff00ff00",  # verde
    "ffff0000",  # azul
    "ff00ffff",  # amarelo
    "ffff00ff",  # magenta
    "ffffff00",  # ciano
    "ff0080ff",  # laranja
    "ff8000ff",  # rosa
    "ff008000",  # verde escuro
    "ff800000",  # azul escuro
]


def _hms(minutos: float, base_h: int = 6) -> str:
    """Converte minutos desde o inicio da jornada em hora do relogio."""
    total = base_h * 60 + minutos
    h = int(total // 60) % 24
    m = int(total % 60)
    return f"{h:02d}:{m:02d}"


# ----------------------------------------------------------------------
# KML / KMZ
# ----------------------------------------------------------------------

def _coords_trajeto(fonte, idx, base, paradas):
    """
    Sequencia de coordenadas do trajeto real: base -> paradas -> base.

    Se a fonte souber a geometria da estrada, usa o caminho percorrido de
    verdade. Senao, cai para linha reta entre os pontos.
    """
    if fonte is None or idx is None or not hasattr(fonte, "geometria"):
        c = [(base.x, base.y)]
        c += [(p.x, p.y) for p in paradas]
        c.append((base.x, base.y))
        return c

    # O OSRM traca a viagem inteira numa requisicao so — bem mais rapido
    # que pedir perna por perna, e o resultado e continuo.
    if hasattr(fonte, "geometria_viagem"):
        try:
            seq = [idx[("base", base.id)]]
            seq += [idx[("dem", p.demanda_id)] for p in paradas]
            seq.append(idx[("base", base.id)])
            g = fonte.geometria_viagem(seq)
            if g:
                return g
        except (KeyError, IndexError, Exception):
            pass

    coords = []
    anterior = ("base", base.id)
    for p in paradas:
        try:
            g = fonte.geometria(idx[anterior], idx[("dem", p.demanda_id)])
        except (KeyError, IndexError):
            g = [(base.x, base.y), (p.x, p.y)]
        if coords and g and coords[-1] == g[0]:
            g = g[1:]
        coords.extend(g)
        anterior = ("dem", p.demanda_id)
    try:
        g = fonte.geometria(idx[anterior], idx[("base", base.id)])
    except (KeyError, IndexError):
        g = [(base.x, base.y)]
    if coords and g and coords[-1] == g[0]:
        g = g[1:]
    coords.extend(g)
    return coords or [(base.x, base.y)]


def gerar_kml(sol: Solucao, bases: Sequence[Base],
              demandas: Sequence[Demanda],
              hora_inicio: int = 6,
              fonte=None, idx=None) -> str:
    """KML com uma pasta por caminhao, rotas e pontos numerados."""
    bmap = {b.id: b for b in bases}
    dmap = {d.id: d for d in demandas}

    p = ['<?xml version="1.0" encoding="UTF-8"?>',
         '<kml xmlns="http://www.opengis.net/kml/2.2">',
         '<Document>',
         '<name>PipaRouter - Programacao de Abastecimento</name>']

    # Estilos
    for i, cor in enumerate(CORES):
        p.append(f'''<Style id="rota{i}">
  <LineStyle><color>{cor}</color><width>4</width></LineStyle>
  <IconStyle><color>{cor}</color><scale>1.0</scale>
    <Icon><href>http://maps.google.com/mapfiles/kml/paddle/wht-blank.png</href></Icon>
  </IconStyle>
</Style>''')
    p.append('''<Style id="base">
  <IconStyle><color>ffffffff</color><scale>1.4</scale>
    <Icon><href>http://maps.google.com/mapfiles/kml/shapes/water.png</href></Icon>
  </IconStyle>
</Style>''')
    p.append('''<Style id="naoatend">
  <IconStyle><color>ff0000ff</color><scale>1.1</scale>
    <Icon><href>http://maps.google.com/mapfiles/kml/shapes/caution.png</href></Icon>
  </IconStyle>
</Style>''')

    # Bases
    p.append('<Folder><name>Bases de Carregamento</name>')
    for b in bases:
        p.append(f'''<Placemark>
  <name>{escape(b.nome)}</name>
  <styleUrl>#base</styleUrl>
  <description><![CDATA[Vazao de enchimento: {b.vazao_enchimento} m3/h]]></description>
  <Point><coordinates>{b.x},{b.y},0</coordinates></Point>
</Placemark>''')
    p.append('</Folder>')

    # Rotas
    for ri, r in enumerate(sol.rotas):
        ci = ri % len(CORES)
        p.append(f'<Folder><name>{escape(r.placa)} — '
                 f'{r.distancia_total:.1f} km / {r.volume_total:.1f} m3</name>')

        for vi, v in enumerate(r.viagens, 1):
            b = bmap[v.base_id]
            p.append(f'<Folder><name>Viagem {vi} — {v.volume_carregado:.1f} m3</name>')

            pts = _coords_trajeto(fonte, idx, b, v.paradas)
            coords = [f"{x},{y},0" for x, y in pts]

            p.append(f'''<Placemark>
  <name>Trajeto viagem {vi}</name>
  <styleUrl>#rota{ci}</styleUrl>
  <LineString><tessellate>1</tessellate>
    <coordinates>{" ".join(coords)}</coordinates>
  </LineString>
</Placemark>''')

            # Instrucoes de navegacao da viagem, se a fonte souber
            roteiro = []
            if fonte is not None and idx is not None and \
                    hasattr(fonte, "roteiro_viagem"):
                try:
                    seq = [idx[("base", b.id)]]
                    seq += [idx[("dem", p.demanda_id)] for p in v.paradas]
                    seq.append(idx[("base", b.id)])
                    nomes = [p.nome for p in v.paradas] + ["a base"]
                    roteiro = fonte.roteiro_viagem(seq, nomes)
                except Exception:
                    roteiro = []

            if roteiro:
                # Placemark com o roteiro inteiro, ancorado na base. E o que
                # o motorista abre antes de sair.
                #
                # Cada linha vira um <br/> proprio: o Google Earth ignora o
                # \n dentro de <pre> quando vem de CDATA, e o roteiro sairia
                # todo grudado numa linha so.
                linhas_html = []
                for x in roteiro:
                    e = escape(x)
                    if x.startswith("---"):
                        linhas_html.append(f"<br/><b>{e}</b>")
                    else:
                        linhas_html.append(e)
                txt = "<br/>".join(linhas_html)
                p.append(f'''<Placemark>
  <name>Viagem {vi} — por onde passar</name>
  <styleUrl>#rota{ci}</styleUrl>
  <description><![CDATA[<b>{escape(r.placa)} — viagem {vi}</b><br/>{txt}]]></description>
  <Point><coordinates>{b.x},{b.y},0</coordinates></Point>
</Placemark>''')

            for oi, par in enumerate(v.paradas, 1):
                flag = " (ENTREGA PARCIAL)" if par.parcial else ""
                desc = (f"Caminhao: {r.placa}<br/>"
                        f"Viagem: {vi} | Parada: {oi}<br/>"
                        f"Volume: {par.volume_entregue:.1f} m3{flag}<br/>"
                        f"Chegada prevista: {_hms(par.chegada, hora_inicio)}<br/>"
                        f"Saida prevista: {_hms(par.saida, hora_inicio)}<br/>"
                        f"Tempo na parada: {par.saida - par.inicio_servico:.0f} min<br/>"
                        f"Distancia do anterior: {par.dist_desde_anterior:.1f} km")
                p.append(f'''<Placemark>
  <name>{vi}.{oi} {escape(par.nome)}</name>
  <styleUrl>#rota{ci}</styleUrl>
  <description><![CDATA[{desc}]]></description>
  <Point><coordinates>{par.x},{par.y},0</coordinates></Point>
</Placemark>''')
            p.append('</Folder>')
        p.append('</Folder>')

    # Nao atendidas
    if sol.nao_atendidas:
        p.append('<Folder><name>NAO ATENDIDAS</name>')
        for did, nome, falta, motivo in sol.nao_atendidas:
            d = dmap.get(did)
            if not d:
                continue
            p.append(f'''<Placemark>
  <name>{escape(nome)}</name>
  <styleUrl>#naoatend</styleUrl>
  <description><![CDATA[Volume nao atendido: {falta:.1f} m3<br/>Motivo: {escape(motivo)}]]></description>
  <Point><coordinates>{d.x},{d.y},0</coordinates></Point>
</Placemark>''')
        p.append('</Folder>')

    p.append('</Document></kml>')
    return "\n".join(p)


def salvar_kmz(sol: Solucao, bases, demandas, caminho: str,
               hora_inicio: int = 6, fonte=None, idx=None) -> str:
    kml = gerar_kml(sol, bases, demandas, hora_inicio, fonte, idx)
    with zipfile.ZipFile(caminho, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("doc.kml", kml.encode("utf-8"))
    return caminho


# ----------------------------------------------------------------------
# Planilha
# ----------------------------------------------------------------------

def _linhas_programacao(sol: Solucao, hora_inicio: int = 6) -> List[List]:
    """
    Uma linha por parada. As colunas de TEMPO sao o que o encarregado usa
    para avisar a comunidade a que horas o caminhao chega, entao vem antes
    das colunas de distancia.
    """
    linhas = [[
        "Caminhao", "Viagem", "Ordem", "Local", "Volume_m3",
        "Saiu_de", "Deslocamento_min", "Chegada", "Espera_min",
        "Inicio_Atend", "Tempo_Atend_min", "Saida",
        "Dist_Anterior_km", "Vel_Efetiva_kmh", "Parcial",
        "Latitude", "Longitude",
    ]]
    for r in sol.rotas:
        for vi, v in enumerate(r.viagens, 1):
            anterior = "BASE"
            t_saida_anterior = v.partida_base
            for oi, p in enumerate(v.paradas, 1):
                desloc = p.chegada - t_saida_anterior
                vef = (p.dist_desde_anterior / (desloc / 60.0)
                       if desloc > 0.01 else 0.0)
                linhas.append([
                    r.placa, vi, oi, p.nome, round(p.volume_entregue, 2),
                    anterior,
                    round(desloc, 1),
                    _hms(p.chegada, hora_inicio),
                    round(p.espera, 1),
                    _hms(p.inicio_servico, hora_inicio),
                    round(p.saida - p.inicio_servico, 1),
                    _hms(p.saida, hora_inicio),
                    round(p.dist_desde_anterior, 2),
                    round(vef, 1),
                    "SIM" if p.parcial else "NAO",
                    round(p.y, 6), round(p.x, 6),
                ])
                anterior = p.nome[:18]
                t_saida_anterior = p.saida
    return linhas


def salvar_csv(sol: Solucao, caminho: str, hora_inicio: int = 6) -> str:
    with open(caminho, "w", newline="", encoding="utf-8-sig") as f:
        csv.writer(f, delimiter=";").writerows(
            _linhas_programacao(sol, hora_inicio))
    return caminho


def salvar_xlsx(sol: Solucao, kpi: Dict, caminho: str,
                hora_inicio: int = 6, fonte=None, idx=None,
                bases=None) -> Optional[str]:
    """XLSX com 4 abas. Requer openpyxl; retorna None se ausente."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
    except ImportError:
        return None

    wb = Workbook()
    NAVY = "0026BD"
    TEAL = "17E3CB"

    def cabecalho(ws, linha):
        for c in ws[linha]:
            if c.value is not None:
                c.font = Font(bold=True, color="FFFFFF", size=10)
                c.fill = PatternFill("solid", fgColor=NAVY)
                c.alignment = Alignment(horizontal="center", vertical="center")

    # Aba 1: Programacao
    ws = wb.active
    ws.title = "Programacao"
    for l in _linhas_programacao(sol, hora_inicio):
        ws.append(l)
    cabecalho(ws, 1)
    ws.freeze_panes = "A2"
    larguras = [12, 8, 7, 26, 10, 20, 17, 10, 11, 13, 16, 10,
                16, 16, 8, 11, 11]
    for i, w in enumerate(larguras, 1):
        ws.column_dimensions[ws.cell(1, i).column_letter].width = w
    # Destaca a coluna de deslocamento — e a pergunta que o plugin responde.
    # (Atribuir ws.cell(...).fill a si mesmo quebra o openpyxl: o getter
    # devolve um StyleProxy, que o setter nao aceita de volta.)
    azul = PatternFill("solid", fgColor="E3F2FD")
    for row in range(2, ws.max_row + 1):
        ws.cell(row, 7).fill = azul

    # Aba 2: Resumo por caminhao
    ws2 = wb.create_sheet("Resumo_Frota")
    ws2.append(["Caminhao", "Viagens", "Atendimentos", "Volume_m3",
                "Distancia_km", "Tempo_Total_h", "Tempo_Atend_h",
                "Tempo_Espera_h", "Produtividade_%"])
    for r in sol.rotas:
        tt = r.tempo_total
        ws2.append([
            r.placa, len(r.viagens), r.n_atendimentos,
            round(r.volume_total, 2), round(r.distancia_total, 2),
            round(tt / 60, 2), round(r.tempo_servico / 60, 2),
            round(r.tempo_espera / 60, 2),
            round(100 * r.tempo_servico / tt, 1) if tt else 0,
        ])
    cabecalho(ws2, 1)
    for i in range(1, 10):
        ws2.column_dimensions[ws2.cell(1, i).column_letter].width = 16

    # Aba 3: Indicadores + nao atendidas
    ws3 = wb.create_sheet("Indicadores")
    ws3.append(["Indicador", "Valor"])
    cabecalho(ws3, 1)
    for k, v in kpi.items():
        ws3.append([k.replace("_", " ").title(), v])
    ws3.column_dimensions["A"].width = 32
    ws3.column_dimensions["B"].width = 16

    if sol.nao_atendidas:
        ws3.append([])
        r0 = ws3.max_row + 1
        ws3.append(["DEMANDAS NAO ATENDIDAS", "", "", ""])
        ws3.cell(r0, 1).font = Font(bold=True, color="FFFFFF")
        ws3.cell(r0, 1).fill = PatternFill("solid", fgColor="C00000")
        ws3.append(["Local", "Volume Faltante (m3)", "Motivo"])
        cabecalho(ws3, ws3.max_row)
        for _, nome, falta, motivo in sol.nao_atendidas:
            ws3.append([nome, falta, motivo])
        ws3.column_dimensions["C"].width = 52

    # Aba 4: Roteiro de navegacao — para imprimir e dar ao motorista
    if fonte is not None and idx is not None and bases and \
            hasattr(fonte, "roteiro_viagem"):
        bmap = {b.id: b for b in bases}
        ws4 = wb.create_sheet("Roteiro")
        ws4.append(["Caminhao", "Viagem", "Instrucao"])
        cabecalho(ws4, 1)
        alguma = False
        for r in sol.rotas:
            for vi, v in enumerate(r.viagens, 1):
                b = bmap.get(v.base_id)
                if not b:
                    continue
                try:
                    seq = [idx[("base", b.id)]]
                    seq += [idx[("dem", p.demanda_id)] for p in v.paradas]
                    seq.append(idx[("base", b.id)])
                    nomes = [p.nome for p in v.paradas] + ["a base"]
                    for ln in fonte.roteiro_viagem(seq, nomes):
                        ws4.append([r.placa, vi, ln])
                        alguma = True
                except Exception:
                    pass
        if alguma:
            ws4.column_dimensions["A"].width = 14
            ws4.column_dimensions["B"].width = 8
            ws4.column_dimensions["C"].width = 76
        else:
            wb.remove(ws4)

    wb.save(caminho)
    return caminho


# ----------------------------------------------------------------------
# Camadas QGIS
# ----------------------------------------------------------------------

def camadas_qgis(sol: Solucao, bases: Sequence[Base],
                 crs: str = "EPSG:4326", hora_inicio: int = 6,
                 fonte=None, idx=None):
    """
    Cria camadas em memoria: rotas (linhas) e paradas (pontos).
    Retorna (layer_rotas, layer_paradas) ou (None, None) fora do QGIS.
    """
    try:
        from qgis.core import (
            QgsFeature, QgsField, QgsGeometry, QgsPointXY, QgsVectorLayer,
        )
        from qgis.PyQt.QtCore import QVariant
    except ImportError:
        return None, None

    bmap = {b.id: b for b in bases}

    lr = QgsVectorLayer(f"LineString?crs={crs}", "Pipa - Rotas", "memory")
    dpr = lr.dataProvider()
    dpr.addAttributes([
        QgsField("caminhao", QVariant.String),
        QgsField("viagem", QVariant.Int),
        QgsField("volume_m3", QVariant.Double),
        QgsField("dist_km", QVariant.Double),
        QgsField("paradas", QVariant.Int),
    ])
    lr.updateFields()

    feats = []
    for r in sol.rotas:
        for vi, v in enumerate(r.viagens, 1):
            b = bmap[v.base_id]
            pts = [QgsPointXY(x, y)
                   for x, y in _coords_trajeto(fonte, idx, b, v.paradas)]
            f = QgsFeature()
            f.setGeometry(QgsGeometry.fromPolylineXY(pts))
            f.setAttributes([r.placa, vi, round(v.volume_carregado, 2),
                             round(v.distancia, 2), len(v.paradas)])
            feats.append(f)
    dpr.addFeatures(feats)
    lr.updateExtents()

    lp = QgsVectorLayer(f"Point?crs={crs}", "Pipa - Paradas", "memory")
    dpp = lp.dataProvider()
    dpp.addAttributes([
        QgsField("caminhao", QVariant.String),
        QgsField("viagem", QVariant.Int),
        QgsField("ordem", QVariant.Int),
        QgsField("local", QVariant.String),
        QgsField("volume_m3", QVariant.Double),
        QgsField("chegada", QVariant.String),
        QgsField("saida", QVariant.String),
        QgsField("parcial", QVariant.String),
    ])
    lp.updateFields()

    feats = []
    for r in sol.rotas:
        for vi, v in enumerate(r.viagens, 1):
            for oi, p in enumerate(v.paradas, 1):
                f = QgsFeature()
                f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(p.x, p.y)))
                f.setAttributes([
                    r.placa, vi, oi, p.nome, round(p.volume_entregue, 2),
                    _hms(p.chegada, hora_inicio), _hms(p.saida, hora_inicio),
                    "SIM" if p.parcial else "NAO",
                ])
                feats.append(f)
    dpp.addFeatures(feats)
    lp.updateExtents()

    return lr, lp
