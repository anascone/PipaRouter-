# -*- coding: utf-8 -*-
#
# PipaRouter — roteirização de caminhões-pipa no QGIS
# Copyright (C) 2025  Antonio A. Coelho Neto
#
# Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
# sob os termos da GNU General Public License versão 2 ou posterior.
# Veja o arquivo LICENSE, ou <https://www.gnu.org/licenses/gpl-2.0.html>.
#
"""
Matriz de distancias offline.

Duas estrategias, em ordem de preferencia:
  1. REDE VIARIA: Dijkstra sobre malha viaria local (QgsGraph). Requer camada
     de linhas carregada no projeto (OSM via QuickOSM, baixado previamente).
  2. EUCLIDIANA CORRIGIDA: distancia reta x fator de sinuosidade. Fallback
     puro-Python, sem dependencia alguma. Adequado para triagem rapida e para
     areas rurais onde a malha viaria mapeada e incompleta.

O cache em SQLite evita recalcular a matriz a cada rodada — em 200 pontos sao
~40.000 pares, e o Dijkstra repetido e o gargalo real do plugin.
"""

import math
import os
import sqlite3
from typing import Dict, List, Optional, Sequence, Tuple

try:
    from qgis.core import (
        QgsCoordinateReferenceSystem,
        QgsCoordinateTransform,
        QgsPointXY,
        QgsProject,
    )
    from qgis.analysis import (
        QgsGraphBuilder,
        QgsGraphAnalyzer,
        QgsVectorLayerDirector,
        QgsNetworkDistanceStrategy,
    )
    QGIS_DISPONIVEL = True
except ImportError:
    QGIS_DISPONIVEL = False


# --------------------------------------------------------------------------
# Geodesia
# --------------------------------------------------------------------------

RAIO_TERRA_KM = 6371.0088


def haversine(x1: float, y1: float, x2: float, y2: float) -> float:
    """
    Distancia ortodromica em km entre dois pontos em GRAUS decimais (EPSG:4326).

    Usamos haversine em vez de distancia cartesiana porque o Piaui se estende
    por ~6 graus de latitude; erro cartesiano seria material no eixo N-S.
    """
    lon1, lat1, lon2, lat2 = map(math.radians, (x1, y1, x2, y2))
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = (math.sin(dlat / 2) ** 2
         + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2)
    return 2 * RAIO_TERRA_KM * math.asin(math.sqrt(a))


def euclidiana_projetada(x1: float, y1: float, x2: float, y2: float) -> float:
    """Distancia plana em km, para coordenadas ja projetadas em METROS (UTM)."""
    return math.hypot(x2 - x1, y2 - y1) / 1000.0


# --------------------------------------------------------------------------
# Cache
# --------------------------------------------------------------------------

class CacheMatriz:
    """Cache SQLite de pares OD. Chave = (x1,y1,x2,y2) arredondados a 6 casas."""

    def __init__(self, caminho: Optional[str] = None):
        self.caminho = caminho or ":memory:"
        if caminho and not os.path.isdir(os.path.dirname(caminho) or "."):
            os.makedirs(os.path.dirname(caminho), exist_ok=True)
        self.conn = sqlite3.connect(self.caminho)
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS od (
                x1 REAL, y1 REAL, x2 REAL, y2 REAL,
                metodo TEXT,
                dist_km REAL,
                PRIMARY KEY (x1, y1, x2, y2, metodo)
            )
        """)
        self.conn.commit()

    @staticmethod
    def _k(v: float) -> float:
        return round(v, 6)

    def get(self, x1, y1, x2, y2, metodo) -> Optional[float]:
        cur = self.conn.execute(
            "SELECT dist_km FROM od WHERE x1=? AND y1=? AND x2=? AND y2=? AND metodo=?",
            (self._k(x1), self._k(y1), self._k(x2), self._k(y2), metodo),
        )
        row = cur.fetchone()
        return row[0] if row else None

    def put(self, x1, y1, x2, y2, metodo, dist):
        self.conn.execute(
            "INSERT OR REPLACE INTO od VALUES (?,?,?,?,?,?)",
            (self._k(x1), self._k(y1), self._k(x2), self._k(y2), metodo, dist),
        )

    def commit(self):
        self.conn.commit()

    def close(self):
        self.conn.commit()
        self.conn.close()


# --------------------------------------------------------------------------
# Matriz
# --------------------------------------------------------------------------

class MatrizDistancia:
    """
    Matriz OD simetrica ou assimetrica entre N pontos.

    Uso:
        m = MatrizDistancia(pontos, fator_sinuosidade=1.3)
        m.construir()          # euclidiana corrigida
        d = m.dist(i, j)       # km

        m = MatrizDistancia(pontos, camada_viaria=layer)
        m.construir()          # Dijkstra sobre a malha
    """

    def __init__(
        self,
        pontos: Sequence[Tuple[float, float]],
        fator_sinuosidade: float = 1.3,
        camada_viaria=None,
        crs_pontos: str = "EPSG:4326",
        cache: Optional[CacheMatriz] = None,
        callback_progresso=None,
    ):
        self.pontos = list(pontos)
        self.n = len(self.pontos)
        self.fator = fator_sinuosidade
        self.camada = camada_viaria
        self.crs_pontos = crs_pontos
        self.cache = cache
        self.callback = callback_progresso
        self._m: List[List[float]] = []
        self.metodo = "rede" if camada_viaria is not None else "euclidiana"
        self.avisos: List[str] = []

    # -- construcao -------------------------------------------------------

    def construir(self) -> "MatrizDistancia":
        if self.n == 0:
            raise ValueError("Matriz vazia: nenhum ponto fornecido.")
        if self.camada is not None and QGIS_DISPONIVEL:
            try:
                self._construir_rede()
            except Exception as e:
                self.avisos.append(
                    f"Falha ao rotear pela malha viaria ({e}). "
                    f"Revertendo para distancia euclidiana corrigida."
                )
                self.metodo = "euclidiana"
                self._construir_euclidiana()
        else:
            self._construir_euclidiana()
        return self

    def _geografico(self) -> bool:
        return self.crs_pontos.upper() in ("EPSG:4326", "EPSG:4674", "EPSG:4326")

    def _dist_direta(self, i: int, j: int) -> float:
        x1, y1 = self.pontos[i]
        x2, y2 = self.pontos[j]
        if self._geografico():
            return haversine(x1, y1, x2, y2)
        return euclidiana_projetada(x1, y1, x2, y2)

    def _construir_euclidiana(self):
        n = self.n
        self._m = [[0.0] * n for _ in range(n)]
        total = n * (n - 1) // 2
        feito = 0
        for i in range(n):
            for j in range(i + 1, n):
                d = self._dist_direta(i, j) * self.fator
                self._m[i][j] = d
                self._m[j][i] = d
                feito += 1
                if self.callback and feito % 500 == 0:
                    self.callback(int(100 * feito / max(total, 1)))
        if self.callback:
            self.callback(100)

    def _construir_rede(self):
        """Dijkstra sobre a malha viaria. Um passe por ponto de origem."""
        crs = QgsCoordinateReferenceSystem(self.crs_pontos)
        director = QgsVectorLayerDirector(
            self.camada, -1, "", "", "", QgsVectorLayerDirector.DirectionBoth
        )
        director.addStrategy(QgsNetworkDistanceStrategy())
        builder = QgsGraphBuilder(crs)

        qgs_pontos = [QgsPointXY(x, y) for x, y in self.pontos]
        tied = director.makeGraph(builder, qgs_pontos)
        graph = builder.graph()

        idx = [graph.findVertex(p) for p in tied]
        faltando = [i for i, v in enumerate(idx) if v < 0]
        if faltando:
            raise RuntimeError(
                f"{len(faltando)} ponto(s) nao conectaram a malha viaria."
            )

        n = self.n
        self._m = [[0.0] * n for _ in range(n)]
        for i in range(n):
            tree, custo = QgsGraphAnalyzer.dijkstra(graph, idx[i], 0)
            for j in range(n):
                if i == j:
                    continue
                c = custo[idx[j]]
                if c < 0 or c == float("inf"):
                    # Sem caminho na malha: cai para euclidiana neste par
                    self._m[i][j] = self._dist_direta(i, j) * self.fator
                    self.avisos.append(
                        f"Sem rota na malha entre pontos {i} e {j}; "
                        f"usada distancia direta."
                    )
                else:
                    self._m[i][j] = c / 1000.0
            if self.callback:
                self.callback(int(100 * (i + 1) / n))

    # -- acesso -----------------------------------------------------------

    def dist(self, i: int, j: int) -> float:
        return self._m[i][j]

    @property
    def matriz(self) -> List[List[float]]:
        return self._m

    def resumo(self) -> Dict:
        vals = [self._m[i][j] for i in range(self.n)
                for j in range(self.n) if i != j]
        return {
            "n_pontos": self.n,
            "metodo": self.metodo,
            "dist_min_km": round(min(vals), 3) if vals else 0,
            "dist_max_km": round(max(vals), 3) if vals else 0,
            "dist_media_km": round(sum(vals) / len(vals), 3) if vals else 0,
            "avisos": self.avisos,
        }
