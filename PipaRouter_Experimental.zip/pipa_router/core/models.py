# -*- coding: utf-8 -*-
#
# PipaRouter — roteirização de caminhões-pipa no QGIS
# Copyright (C) 2025  Antonio A. Coelho Neto
#
# Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
# sob os termos da GNU General Public License versão 2 ou posterior.
# Veja o arquivo LICENSE, ou <https://www.gnu.org/licenses/gpl-2.0.html>.
#
"""
Estruturas de dados do PipaRouter.

Unidades adotadas (SI operacional de saneamento):
    volume ......... m3
    vazao .......... m3/h
    distancia ...... km
    velocidade ..... km/h
    tempo .......... minutos (interno), horas na interface
"""

from dataclasses import dataclass, field
from typing import List, Optional, Tuple


@dataclass
class Base:
    """Ponto de carregamento (ETA, poco, manancial, hidrante autorizado)."""
    id: int
    nome: str
    x: float
    y: float
    vazao_enchimento: float = 60.0   # m3/h - vazao do ponto de carga
    volume_disponivel: float = 1e9   # m3/dia - limite da fonte (default: irrestrito)

    def tempo_enchimento_min(self, volume_m3: float) -> float:
        """Tempo para encher o caminhao com `volume_m3`, em minutos."""
        if self.vazao_enchimento <= 0:
            raise ValueError(
                f"Base '{self.nome}': vazao de enchimento deve ser > 0."
            )
        return (volume_m3 / self.vazao_enchimento) * 60.0


@dataclass
class Demanda:
    """Ponto de atendimento inserido pelo usuario em tempo de execucao."""
    id: int
    nome: str
    x: float
    y: float
    volume: float                       # m3 solicitados
    prioridade: int = 1                 # 1 = normal, 2 = alta, 3 = critica
    janela_inicio: Optional[float] = None   # min desde o inicio da jornada
    janela_fim: Optional[float] = None
    permite_split: bool = True          # aceita atendimento fracionado?

    def __post_init__(self):
        if self.volume <= 0:
            raise ValueError(
                f"Demanda '{self.nome}': volume deve ser > 0 (recebido: {self.volume})."
            )
        if self.prioridade not in (1, 2, 3):
            raise ValueError(
                f"Demanda '{self.nome}': prioridade deve ser 1, 2 ou 3."
            )
        if (self.janela_inicio is not None and self.janela_fim is not None
                and self.janela_inicio >= self.janela_fim):
            raise ValueError(
                f"Demanda '{self.nome}': janela invalida "
                f"({self.janela_inicio} >= {self.janela_fim})."
            )


@dataclass
class Caminhao:
    """Veiculo da frota."""
    id: int
    placa: str
    capacidade: float                   # m3
    base_id: int
    vazao_descarga: float = 30.0        # m3/h - vazao da bomba/gravidade do pipa
    jornada_max: float = 480.0          # min (8h)
    custo_km: float = 0.0               # R$/km (opcional, para indicadores)
    disponivel: bool = True

    def __post_init__(self):
        if self.capacidade <= 0:
            raise ValueError(
                f"Caminhao '{self.placa}': capacidade deve ser > 0."
            )
        if self.vazao_descarga <= 0:
            raise ValueError(
                f"Caminhao '{self.placa}': vazao de descarga deve ser > 0."
            )

    def tempo_descarga_min(self, volume_m3: float) -> float:
        """Componente VARIAVEL do tempo de atendimento: volume / vazao."""
        return (volume_m3 / self.vazao_descarga) * 60.0


@dataclass
class ParametrosOperacionais:
    """Parametros globais definidos pelo usuario na interface."""
    velocidade_media: float = 40.0      # km/h - via pavimentada
    fator_nao_pavimentado: float = 0.6  # multiplicador da velocidade em estrada de terra
    tempo_fixo_parada: float = 10.0     # min - manobra, engate, desengate, conferencia
    fator_sinuosidade: float = 1.3      # euclidiana -> rodoviaria (fallback offline)
    jornada_inicio: float = 0.0         # min
    permite_multiplas_viagens: bool = True   # caminhao pode retornar a base e recarregar
    volume_min_parcial: float = 3.0     # m3 - menor entrega fracionada que faz sentido

    def __post_init__(self):
        if self.velocidade_media <= 0:
            raise ValueError("Velocidade media deve ser > 0.")
        if not (0 < self.fator_nao_pavimentado <= 1):
            raise ValueError("Fator de nao pavimentado deve estar em (0, 1].")
        if self.tempo_fixo_parada < 0:
            raise ValueError("Tempo fixo de parada nao pode ser negativo.")
        if self.fator_sinuosidade < 1:
            raise ValueError("Fator de sinuosidade deve ser >= 1.")

    def tempo_viagem_min(self, distancia_km: float,
                         pavimentado: bool = True) -> float:
        """Converte distancia em tempo de viagem."""
        v = self.velocidade_media
        if not pavimentado:
            v *= self.fator_nao_pavimentado
        return (distancia_km / v) * 60.0


@dataclass
class Parada:
    """Uma visita dentro de uma rota."""
    demanda_id: int
    nome: str
    x: float
    y: float
    volume_entregue: float
    chegada: float          # min desde inicio da jornada
    inicio_servico: float   # min (pode diferir de chegada se houver espera por janela)
    saida: float            # min
    espera: float           # min aguardando abertura de janela
    dist_desde_anterior: float  # km
    parcial: bool = False   # True se a demanda foi fracionada


@dataclass
class Viagem:
    """Um ciclo base -> demandas -> base."""
    base_id: int
    volume_carregado: float
    tempo_enchimento: float     # min
    paradas: List[Parada] = field(default_factory=list)
    partida_base: float = 0.0   # min
    retorno_base: float = 0.0   # min
    distancia: float = 0.0      # km


@dataclass
class Rota:
    """Programacao completa de um caminhao no dia."""
    caminhao_id: int
    placa: str
    viagens: List[Viagem] = field(default_factory=list)

    @property
    def distancia_total(self) -> float:
        return sum(v.distancia for v in self.viagens)

    @property
    def volume_total(self) -> float:
        return sum(v.volume_carregado for v in self.viagens)

    @property
    def tempo_total(self) -> float:
        if not self.viagens:
            return 0.0
        return self.viagens[-1].retorno_base - self.viagens[0].partida_base

    @property
    def n_atendimentos(self) -> int:
        return sum(len(v.paradas) for v in self.viagens)

    @property
    def tempo_dirigindo(self) -> float:
        """Minutos efetivamente em deslocamento."""
        total = 0.0
        for v in self.viagens:
            total += sum(p.dist_desde_anterior for p in v.paradas)
        return total

    @property
    def tempo_servico(self) -> float:
        """Minutos em atendimento (fixo + descarga)."""
        total = 0.0
        for v in self.viagens:
            for p in v.paradas:
                total += (p.saida - p.inicio_servico)
        return total

    @property
    def tempo_espera(self) -> float:
        return sum(p.espera for v in self.viagens for p in v.paradas)


@dataclass
class Solucao:
    """Resultado completo da otimizacao."""
    rotas: List[Rota] = field(default_factory=list)
    nao_atendidas: List[Tuple[int, str, float, str]] = field(default_factory=list)
    # (demanda_id, nome, volume_faltante, motivo)

    @property
    def distancia_total(self) -> float:
        return sum(r.distancia_total for r in self.rotas)

    @property
    def volume_entregue(self) -> float:
        return sum(r.volume_total for r in self.rotas)

    @property
    def caminhoes_usados(self) -> int:
        return sum(1 for r in self.rotas if r.viagens)
