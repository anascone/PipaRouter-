# -*- coding: utf-8 -*-
#
# PipaRouter — roteirização de caminhões-pipa no QGIS
# Copyright (C) 2025  Antonio A. Coelho Neto
#
# Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
# sob os termos da GNU General Public License versão 2 ou posterior.
# Veja o arquivo LICENSE, ou <https://www.gnu.org/licenses/gpl-2.0.html>.
#
"""
Roteamento via OSRM.

O OSRM e o mesmo motor que roda por tras de muitos apps de navegacao. Duas
diferencas praticas em relacao ao grafo interno do plugin:

  - a rota sai igual a de um GPS, porque E o algoritmo de um GPS, com a rede
    completa do OSM, restricoes de sentido, e velocidades calibradas por perfil
  - /table devolve a matriz N x N inteira numa requisicao — o solver consulta
    os mesmos pares milhares de vezes na busca local, entao isso importa

MODOS
  Servidor local  (127.0.0.1:5000) -> offline, sem limite, precisa instalar
  Servidor publico                 -> conveniencia, tem limite de uso

O servidor publico do projeto OSM (routing.openstreetmap.de) e para uso
moderado. Uma programacao diaria de pipa cabe. Rodar o estado inteiro nao —
para isso, servidor local.

LICENCA DOS DADOS
  OSM/ODbL: pode usar comercialmente, pode exportar KMZ/planilha/camada,
  exige atribuicao "© OpenStreetMap contributors". Diferente do Google Maps,
  cujos termos proibem usar as rotas fora de um mapa Google.

O algoritmo de encode/decode de polyline e o padrao do Google, implementado
aqui a partir da especificacao publica (a mesma que o OSRM usa por default).
"""

import json
from typing import Dict, List, Optional, Sequence, Tuple


# ----------------------------------------------------------------------
# Polyline — algoritmo publico (precisao 5 = padrao do OSRM)
# ----------------------------------------------------------------------

def encode_polyline(coords: Sequence[Tuple[float, float]],
                    precisao: int = 5) -> str:
    """
    Codifica [(lat, lon), ...] no formato encoded polyline.

    Usamos polyline em vez de lista de coordenadas na URL porque uma
    programacao com 40 pontos estoura o limite de tamanho de URL se cada
    coordenada for escrita por extenso.
    """
    fator = 10 ** precisao
    out = []

    def _enc(v: int):
        v = v << 1
        if v < 0:
            v = ~v
        while v >= 0x20:
            out.append(chr((0x20 | (v & 0x1f)) + 63))
            v >>= 5
        out.append(chr(v + 63))

    lat_ant = lon_ant = 0
    for lat, lon in coords:
        la = int(round(lat * fator))
        lo = int(round(lon * fator))
        _enc(la - lat_ant)
        _enc(lo - lon_ant)
        lat_ant, lon_ant = la, lo
    return "".join(out)


def decode_polyline(s: str, precisao: int = 5) -> List[Tuple[float, float]]:
    """Decodifica para [(lat, lon), ...]."""
    fator = 10 ** precisao
    coords = []
    i = 0
    lat = lon = 0
    n = len(s)

    def _dec(idx):
        shift = res = 0
        while True:
            b = ord(s[idx]) - 63
            idx += 1
            res |= (b & 0x1f) << shift
            shift += 5
            if b < 0x20:
                break
        return (~(res >> 1) if (res & 1) else (res >> 1)), idx

    while i < n:
        d, i = _dec(i)
        lat += d
        d, i = _dec(i)
        lon += d
        coords.append((lat / fator, lon / fator))
    return coords


# ----------------------------------------------------------------------
# Cliente
# ----------------------------------------------------------------------

# Ordem importa: o primeiro e o default. O servidor local exige instalar o
# OSRM via Docker — ninguem tem isso no primeiro uso, entao deixa-lo como
# padrao garante que todo usuario novo bata num erro de conexao antes de ver
# o plugin funcionar. O publico funciona na hora, sem instalar nada.
SERVIDORES = [
    ("OSM público (funciona já, precisa de internet)",
     "https://routing.openstreetmap.de/routed-car"),
    ("No meu computador (offline, precisa instalar)",
     "http://127.0.0.1:5000"),
]


class ErroOSRM(Exception):
    pass


class ClienteOSRM:
    """
    Cliente minimo do OSRM: /table para a matriz, /route para a geometria.
    """

    # Servidores publicos costumam recusar (403) cliente sem User-Agent
    # identificavel. Identificar-se e tambem o que a politica de uso do
    # servidor da OSM pede.
    UA = "PipaRouter-QGIS/2.0 (abastecimento de agua; QGIS plugin)"

    def __init__(self, base_url: str, timeout: int = 60,
                 perfil: str = "driving"):
        self.base = base_url.rstrip("/")
        self.timeout = timeout
        self.perfil = perfil

    def _url(self, servico: str, coords_polyline: str, params: str = "") -> str:
        return (f"{self.base}/{servico}/v1/{self.perfil}/"
                f"polyline({coords_polyline})" + (f"?{params}" if params else ""))

    def _get(self, url: str) -> dict:
        """
        GET com fallback de biblioteca.

        urllib3 vem com o QGIS na maioria das instalacoes, mas nao em todas.
        urllib e stdlib e sempre existe. Tentamos o melhor disponivel em vez
        de exigir dependencia.
        """
        data = None
        self._status = None
        try:
            import urllib3
            http = urllib3.PoolManager(timeout=urllib3.Timeout(
                connect=10.0, read=self.timeout))
            r = http.request("GET", url, headers={"User-Agent": self.UA})
            if r.status != 200:
                self._status = r.status
                data = None
            else:
                data = r.data
        except ImportError:
            import urllib.request
            import urllib.error
            try:
                req = urllib.request.Request(
                    url, headers={"User-Agent": self.UA})
                with urllib.request.urlopen(req, timeout=self.timeout) as r:
                    data = r.read()
            except urllib.error.HTTPError as e:
                self._status = e.code
                data = None
            except urllib.error.URLError as e:
                raise ErroOSRM("o servidor não respondeu (não está no ar, "
                               "ou não há rede até ele)") from e
        except ErroOSRM:
            raise          # ja e nosso; nao re-embrulhar
        except Exception as e:
            # urllib3 levanta tipos proprios com stack trace embutido no str().
            # "HTTPConnectionPool(host='127.0.0.1', port=5000): Max retries
            # exceeded with url: /table/v1/driving/polyline(bfutEhlzaK...)"
            # nao ajuda ninguem. Traduzimos para o que aconteceu de fato.
            txt = str(e)
            if ("Max retries" in txt or "refused" in txt.lower()
                    or "10061" in txt or "Connection" in txt):
                raise ErroOSRM("o servidor não respondeu (não está no ar, "
                               "ou não há rede até ele)") from e
            if "timed out" in txt.lower() or "timeout" in txt.lower():
                raise ErroOSRM("o servidor demorou demais para responder") from e
            if "Name or service not known" in txt or "getaddrinfo" in txt:
                raise ErroOSRM("endereço do servidor não encontrado") from e
            raise ErroOSRM(f"falha na conexão: {type(e).__name__}") from e

        if data is None:
            st = self._status
            if st == 403:
                raise ErroOSRM(
                    "o servidor recusou o acesso (403). Se for o servidor "
                    "público, ele pode estar bloqueando uso automatizado — "
                    "use a camada do QGIS ou instale o servidor local")
            if st == 429:
                raise ErroOSRM(
                    "limite de uso do servidor público atingido (429). "
                    "Espere alguns minutos, ou instale o servidor local")
            if st in (502, 503, 504):
                raise ErroOSRM(
                    f"o servidor está fora do ar no momento ({st})")
            raise ErroOSRM(f"o servidor respondeu com erro {st}")

        try:
            j = json.loads(data, strict=False)
        except Exception as e:
            raise ErroOSRM("o servidor respondeu algo que não é uma rota "
                           "(endereço errado?)") from e

        if j.get("code") != "Ok":
            raise ErroOSRM(f"OSRM: {j.get('code')} — "
                           f"{j.get('message', 'sem detalhe')}")
        return j

    # -- servicos ---------------------------------------------------------

    def testar(self) -> Tuple[bool, str]:
        """(ok, mensagem). Usa dois pontos quaisquer so para ver se responde."""
        try:
            pl = encode_polyline([(-9.02, -42.70), (-9.03, -42.71)])
            self._get(self._url("route", pl, "overview=false"))
            return True, "Servidor respondeu."
        except ErroOSRM as e:
            return False, str(e)
        except Exception as e:
            return False, f"{e}"

    def tabela(self, pontos_wgs84: Sequence[Tuple[float, float]]) -> Tuple:
        """
        Matriz N x N de duracao (s) e distancia (m), numa requisicao.

        pontos_wgs84: [(lon, lat), ...]
        """
        pl = encode_polyline([(y, x) for x, y in pontos_wgs84])
        url = self._url("table", pl, "annotations=duration,distance")
        j = self._get(url)
        dur = j.get("durations")
        dist = j.get("distances")
        if dur is None:
            raise ErroOSRM("servidor nao devolveu a matriz de tempo "
                           "(annotations nao suportado?)")
        return dur, dist

    def rota(self, pontos_wgs84: Sequence[Tuple[float, float]],
             com_instrucoes: bool = False) -> dict:
        """
        Rota passando pelos pontos na ordem.

        com_instrucoes=True pede `steps`, que traz a lista de manobras com
        nome de rua — o "pegue a PE-316, siga 12 km, vire a direita". Custa
        uma resposta maior, entao so pedimos quando o usuario vai ver.
        """
        pl = encode_polyline([(y, x) for x, y in pontos_wgs84])
        steps = "true" if com_instrucoes else "false"
        url = self._url("route", pl,
                        f"overview=full&geometries=polyline&steps={steps}&"
                        f"annotations=false")
        j = self._get(url)
        rotas = j.get("routes") or []
        if not rotas:
            raise ErroOSRM("nenhuma rota encontrada entre os pontos")
        r = rotas[0]

        geo = [(lon, lat) for lat, lon in decode_polyline(r["geometry"])]

        pernas = []
        for leg in r.get("legs", []):
            p = {
                "distancia_m": leg.get("distance", 0.0),
                "duracao_s": leg.get("duration", 0.0),
                "resumo": leg.get("summary", ""),
                "manobras": [],
            }
            for st in leg.get("steps", []):
                man = st.get("maneuver") or {}
                loc = man.get("location")
                p["manobras"].append({
                    "rua": st.get("name") or "",
                    "ref": st.get("ref") or "",
                    "distancia_m": st.get("distance", 0.0),
                    "duracao_s": st.get("duration", 0.0),
                    "tipo": man.get("type") or "",
                    "modificador": man.get("modifier") or "",
                    "saida": man.get("exit"),
                    "lon": loc[0] if loc else None,
                    "lat": loc[1] if loc else None,
                })
            pernas.append(p)

        return {
            "geometria": geo,
            "distancia_m": r.get("distance", 0.0),
            "duracao_s": r.get("duration", 0.0),
            "pernas": pernas,
            "snap": [w.get("location") for w in j.get("waypoints", [])],
        }


# ----------------------------------------------------------------------
# Fonte para o solver
# ----------------------------------------------------------------------

class FonteOSRM:
    """
    Mesma interface das outras fontes: dist(), tempo(), geometria().

    A matriz vem numa requisicao (/table). As geometrias sao buscadas sob
    demanda e cacheadas — pedir a rota de todos os N x N pares seria lento e
    desnecessario: o solver so precisa desenhar os pares que entraram na
    solucao final.
    """

    def __init__(self, cliente: ClienteOSRM,
                 pontos_wgs84: Sequence[Tuple[float, float]],
                 callback=None):
        self.cli = cliente
        self.pontos = list(pontos_wgs84)
        self.exata = True
        self._geo: Dict[Tuple[int, int], List] = {}
        self._viagens: Dict[tuple, dict] = {}
        self.avisos: List[str] = []
        self.erros: List[str] = []
        self._sem_rota = 0

        if callback:
            callback(10)
        dur, dist = self.cli.tabela(self.pontos)
        if callback:
            callback(90)

        n = len(self.pontos)
        self._mt = [[0.0] * n for _ in range(n)]
        self._md = [[0.0] * n for _ in range(n)]
        self._aprox = [[False] * n for _ in range(n)]

        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                d = dur[i][j] if dur and dur[i] else None
                m = dist[i][j] if dist and dist[i] else None

                # OSRM devolve null quando nao ha rota
                if d is None:
                    self._sem_rota += 1
                    self._aprox[i][j] = True
                    km = self._hav(i, j) * 1.3
                    self._md[i][j] = km
                    self._mt[i][j] = (km / 25.0) * 60.0
                else:
                    self._mt[i][j] = d / 60.0
                    self._md[i][j] = (m / 1000.0) if m is not None else \
                        (d / 60.0) / 60.0 * 40.0

        if self._sem_rota:
            self.avisos.append(
                f"{self._sem_rota} par(es) sem rota no servidor — nesses o "
                f"caminho e estimado.")
        if callback:
            callback(100)

        # Distancia dos pontos ate a via onde o OSRM os encaixou
        self.snap_m = []

    def _hav(self, i, j):
        import math
        R = 6371.0088
        x1, y1 = self.pontos[i]
        x2, y2 = self.pontos[j]
        lo1, la1, lo2, la2 = map(math.radians, (x1, y1, x2, y2))
        a = (math.sin((la2 - la1) / 2) ** 2
             + math.cos(la1) * math.cos(la2) * math.sin((lo2 - lo1) / 2) ** 2)
        return 2 * R * math.asin(math.sqrt(a))

    # -- interface --------------------------------------------------------

    def dist(self, i: int, j: int) -> float:
        return self._md[i][j]

    def tempo(self, i: int, j: int) -> float:
        return self._mt[i][j]

    def aproximado(self, i: int, j: int) -> bool:
        return self._aprox[i][j]

    def km_pav(self, i, j):
        # O OSRM nao devolve piso por default. Reportamos 0 e o painel
        # simplesmente nao mostra a divisao — melhor que inventar.
        return 0.0

    def km_terra(self, i, j):
        return 0.0

    def geometria(self, i: int, j: int) -> List[Tuple[float, float]]:
        """Traçado real entre dois pontos. Busca e cacheia."""
        k = (i, j)
        if k in self._geo:
            return self._geo[k]
        if self._aprox[i][j]:
            g = [self.pontos[i], self.pontos[j]]
        else:
            try:
                r = self.cli.rota([self.pontos[i], self.pontos[j]])
                g = r["geometria"] or [self.pontos[i], self.pontos[j]]
            except ErroOSRM as e:
                self.avisos.append(f"Sem traçado para um trecho: {e}")
                g = [self.pontos[i], self.pontos[j]]
        self._geo[k] = g
        return g

    def geometria_viagem(self, indices: Sequence[int]) -> List[Tuple[float, float]]:
        """
        Traçado de uma viagem inteira (base -> paradas -> base) numa
        requisicao só. Bem mais rapido que pedir perna por perna.
        """
        if len(indices) < 2:
            return [self.pontos[indices[0]]] if indices else []
        k = tuple(indices)
        if k in self._viagens:
            return self._viagens[k]["geometria"]
        try:
            r = self.cli.rota([self.pontos[i] for i in indices])
            self._viagens[k] = r
            return r["geometria"]
        except ErroOSRM:
            out = []
            for a, b in zip(indices, indices[1:]):
                g = self.geometria(a, b)
                if out and g and out[-1] == g[0]:
                    g = g[1:]
                out.extend(g)
            return out

    def roteiro_viagem(self, indices: Sequence[int],
                       nomes: Optional[List[str]] = None) -> List[str]:
        """
        Instrucoes de navegacao da viagem: 'pegue a PE-316, siga 12 km,
        vire a direita'. E o que o motorista precisa ler.
        """
        if len(indices) < 2:
            return []
        k = tuple(indices)
        r = self._viagens.get(k)
        if r is None or not any(p.get("manobras") for p in r.get("pernas", [])):
            try:
                r = self.cli.rota([self.pontos[i] for i in indices],
                                  com_instrucoes=True)
                self._viagens[k] = r
            except ErroOSRM as e:
                return [f"(sem instruções: {e})"]
        return roteiro_pt(r.get("pernas", []), nomes)

    @property
    def n_aproximados(self) -> int:
        return self._sem_rota

    def resumo(self) -> Dict:
        n = len(self.pontos)
        tot = n * (n - 1)
        return {
            "fonte": "osrm",
            "metodo": f"OSRM ({self.cli.base})",
            "n_pontos": n,
            "trechos_totais": tot,
            "trechos_aproximados": self._sem_rota,
            "pct_exato": round(100 * (tot - self._sem_rota) / tot, 1) if tot else 0,
            "avisos": self.avisos,
            "erros": self.erros,
            "servidor": self.cli.base,
        }

    def diagnostico(self) -> str:
        L = [f"Servidor: {self.cli.base}"]
        n = len(self.pontos)
        tot = n * (n - 1)
        L.append(f"Matriz {n}x{n} obtida em 1 requisição.")
        if self._sem_rota:
            L.append(f"{self._sem_rota} de {tot} pares sem rota — nesses o "
                     f"caminho sai reto.")
            L.append("   Pode ser ponto em ilha viária ou fora da área do "
                     "servidor.")
        else:
            L.append("Todos os pares têm rota pela estrada.")
        for a in self.avisos[:3]:
            L.append(f"! {a}")
        return "\n".join(L)


# ----------------------------------------------------------------------
# Instrucoes de navegacao em portugues
# ----------------------------------------------------------------------

_MOD = {
    "left": "à esquerda",
    "right": "à direita",
    "sharp left": "à esquerda (fechada)",
    "sharp right": "à direita (fechada)",
    "slight left": "levemente à esquerda",
    "slight right": "levemente à direita",
    "straight": "em frente",
    "uturn": "retorno",
}

_ORDINAL = {1: "1ª", 2: "2ª", 3: "3ª", 4: "4ª", 5: "5ª", 6: "6ª"}


def _via(m) -> str:
    """Nome da via, preferindo a referencia (PE-316) quando existe."""
    ref = (m.get("ref") or "").strip()
    rua = (m.get("rua") or "").strip()
    if ref and rua:
        # "Rod. Cap. Pedro Teixeira (PE-316)"
        return f"{rua} ({ref})" if ref not in rua else rua
    return ref or rua


def instrucao_pt(m: dict, primeira: bool = False) -> str:
    """
    Traduz uma manobra do OSRM para portugues.

    O OSRM devolve tipo+modificador em ingles, no padrao do OSM. A traducao
    literal ("turn right onto") fica esquisita; aqui montamos a frase como um
    GPS falaria em portugues.
    """
    tipo = (m.get("tipo") or "").strip()
    mod = (m.get("modificador") or "").strip()
    via = _via(m)
    onde = f" na {via}" if via else ""
    dir_ = _MOD.get(mod, mod)

    if tipo == "depart":
        return f"Saia{onde}" if via else "Saia"
    if tipo == "arrive":
        if mod in ("left", "right"):
            return f"Chegou — o destino fica {dir_}"
        return "Chegou ao destino"
    if tipo == "turn":
        if mod == "straight":
            return f"Siga em frente{onde}"
        if mod == "uturn":
            return f"Faça o retorno{onde}"
        return f"Vire {dir_}{onde}"
    if tipo == "new name":
        return f"Continue{onde}" if via else "Continue em frente"
    if tipo == "continue":
        if mod == "uturn":
            return f"Faça o retorno{onde}"
        return f"Continue {dir_}{onde}" if dir_ else f"Continue{onde}"
    if tipo == "merge":
        return f"Entre{onde}" if via else f"Entre {dir_}".strip()
    if tipo in ("on ramp", "off ramp"):
        acao = "Pegue o acesso" if tipo == "on ramp" else "Pegue a saída"
        s = m.get("saida")
        if s and tipo == "off ramp":
            return f"Pegue a {_ORDINAL.get(s, str(s)+'ª')} saída{onde}"
        return f"{acao} {dir_}{onde}".replace("  ", " ").strip()
    if tipo == "fork":
        return f"Na bifurcação, mantenha-se {dir_}{onde}"
    if tipo == "end of road":
        return f"No fim da via, vire {dir_}{onde}"
    if tipo == "roundabout" or tipo == "rotary":
        s = m.get("saida")
        if s:
            return f"Na rotatória, pegue a {_ORDINAL.get(s, str(s)+'ª')} saída{onde}"
        return f"Entre na rotatória{onde}"
    if tipo in ("exit roundabout", "exit rotary"):
        return f"Saia da rotatória{onde}"
    if tipo == "roundabout turn":
        return f"Na rotatória, vire {dir_}{onde}"
    if tipo == "notification":
        return f"Continue{onde}"
    # Tipo desconhecido: nao inventa, mostra o que der
    if via:
        return f"Siga{onde}"
    return "Siga em frente"


def _fmt_dist(m: float) -> str:
    if m < 1000:
        return f"{m:.0f} m"
    return f"{m/1000:.1f} km"


def roteiro_pt(pernas: List[dict], nomes_destinos: Optional[List[str]] = None,
               juntar_iguais: bool = True) -> List[str]:
    """
    Roteiro de navegacao legivel, como o de um GPS.

    juntar_iguais: o OSRM fragmenta a mesma via em varios steps quando ela
    muda de segmento. Juntar da "siga 12 km pela PE-316" em vez de oito
    linhas de "continue".
    """
    L = []
    for k, p in enumerate(pernas):
        nome = (nomes_destinos[k] if nomes_destinos and k < len(nomes_destinos)
                else f"parada {k+1}")
        L.append(f"--- até {nome} "
                 f"({_fmt_dist(p['distancia_m'])}, "
                 f"{p['duracao_s']/60:.0f} min) ---")

        mans = p.get("manobras") or []
        if juntar_iguais:
            mans = _juntar(mans)

        for i, m in enumerate(mans):
            txt = instrucao_pt(m, primeira=(i == 0))
            d = m.get("distancia_m", 0)
            if d >= 50 and m.get("tipo") != "arrive":
                L.append(f"  {txt}, siga {_fmt_dist(d)}")
            else:
                L.append(f"  {txt}")
    return L


def _juntar(mans: List[dict]) -> List[dict]:
    """Funde manobras consecutivas de 'continue' na mesma via."""
    if not mans:
        return mans
    out = [dict(mans[0])]
    for m in mans[1:]:
        ant = out[-1]
        mesma_via = _via(m) and _via(m) == _via(ant)
        eh_continuacao = m.get("tipo") in ("new name", "continue",
                                           "notification")
        if mesma_via and eh_continuacao:
            ant["distancia_m"] = ant.get("distancia_m", 0) + m.get("distancia_m", 0)
            ant["duracao_s"] = ant.get("duracao_s", 0) + m.get("duracao_s", 0)
        else:
            out.append(dict(m))
    return out
