# -*- coding: utf-8 -*-
#
# PipaRouter — roteirização de caminhões-pipa no QGIS
# Copyright (C) 2025  Antonio A. Coelho Neto
#
# Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
# sob os termos da GNU General Public License versão 2 ou posterior.
# Veja o arquivo LICENSE, ou <https://www.gnu.org/licenses/gpl-2.0.html>.
#
"""
Painel principal do PipaRouter.

Desenho da interface segue o fluxo real da operacao:
    1. Onde enche      -> 1 clique
    2. Quais caminhoes -> lista simples
    3. Onde entrega    -> clique no mapa, um por um
    4. Calcular        -> 1 botao
    5. Ajustar         -> tirar/por ponto e recalcular

Nao ha aba de "parametros" na cara do usuario. Os defaults funcionam. Quem
precisar mexer, abre o botao "Ajustes avancados".
"""

import os
from typing import Dict, List, Optional

from qgis.core import QgsProject
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QFont, QIcon
from qgis.PyQt.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QDockWidget, QDoubleSpinBox,
    QFileDialog, QFormLayout, QFrame, QGroupBox, QHBoxLayout, QHeaderView,
    QLabel, QListWidget, QListWidgetItem, QMenu, QMessageBox, QProgressBar,
    QPushButton, QScrollArea, QSpinBox, QSplitter, QTableWidget,
    QTableWidgetItem, QTextEdit, QToolButton, QVBoxLayout, QWidget,
)

from ..core.models import (
    Base, Caminhao, Demanda, ParametrosOperacionais,
)
from ..core.matriz import MatrizDistancia
from ..core.solver import SolverPipa, indicadores
from ..core import exportador
from .mapa import FerramentaClique, MarcadoresMapa
from .dialogos_ponto import DialogoBase, DialogoPonto

AZUL = "#0026BD"
TEAL = "#17E3CB"


def _btn(txt, cor=AZUL, grande=False):
    b = QPushButton(txt)
    pad = "11px 16px" if grande else "7px 12px"
    fs = "13px" if grande else "12px"
    b.setStyleSheet(f"""
        QPushButton{{background:{cor};color:white;font-weight:bold;
            padding:{pad};border:none;border-radius:4px;font-size:{fs};}}
        QPushButton:hover{{background:{TEAL};color:{AZUL};}}
        QPushButton:disabled{{background:#CCC;color:#888;}}
    """)
    return b


def _passo(n, titulo):
    w = QWidget()
    h = QHBoxLayout(w)
    h.setContentsMargins(0, 0, 0, 0)
    num = QLabel(str(n))
    num.setFixedSize(24, 24)
    num.setAlignment(Qt.AlignCenter)
    num.setStyleSheet(
        f"background:{AZUL};color:white;font-weight:bold;border-radius:12px;")
    t = QLabel(titulo)
    t.setStyleSheet("font-weight:bold;font-size:13px;")
    h.addWidget(num)
    h.addWidget(t)
    h.addStretch()
    return w


class PainelPipa(QDockWidget):

    def __init__(self, iface, parent=None):
        super().__init__("PipaRouter", parent)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.marcadores = MarcadoresMapa(self.canvas)
        self.ferramenta = None
        self.ferramenta_anterior = None

        self.base: Optional[Base] = None
        self.pontos: List[Dict] = []     # {id,nome,x,y,volume,prio,pessoas,ativo}
        self.frota: List[Caminhao] = []
        self.solucao = None
        self.kpi = None
        self.fonte = None
        self._ft_ret = None
        self.ferramenta_anterior = None
        self._via_recem_baixada = None
        self._idx = None
        self.tabela_vel = None
        self._prox_id = 1

        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self._montar()
        self._frota_padrao()
        self._atualizar_estado()

    # ==================================================================
    # Construcao da interface
    # ==================================================================

    def _montar(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        cont = QWidget()
        scroll.setWidget(cont)
        self.setWidget(scroll)

        v = QVBoxLayout(cont)
        v.setSpacing(12)

        cab = QLabel("Levar água até as pessoas")
        cab.setStyleSheet(
            f"font-size:16px;font-weight:bold;color:{AZUL};padding:2px 0;")
        v.addWidget(cab)
        sub = QLabel("Marque no mapa onde o caminhão enche e onde precisa "
                     "entregar. O plugin monta a rota.")
        sub.setWordWrap(True)
        sub.setStyleSheet("color:#555;font-size:11px;")
        v.addWidget(sub)

        h_sv = QHBoxLayout()
        b_sv = _btn("Salvar esta operação", "#546E7A")
        b_sv.setToolTip("Guarda base, frota e locais para usar de novo.")
        b_sv.clicked.connect(self._salvar_operacao)
        b_ab = _btn("Abrir operação salva", "#546E7A")
        b_ab.clicked.connect(self._abrir_operacao)
        h_sv.addWidget(b_sv)
        h_sv.addWidget(b_ab)
        h_sv.addStretch()
        v.addLayout(h_sv)

        v.addWidget(self._sep())
        v.addWidget(self._bloco_base())
        v.addWidget(self._bloco_frota())
        v.addWidget(self._bloco_pontos())
        v.addWidget(self._bloco_estradas())
        v.addWidget(self._sep())
        v.addWidget(self._bloco_calcular())
        v.addWidget(self._bloco_resultado())
        v.addStretch()

    def _sep(self):
        f = QFrame()
        f.setFrameShape(QFrame.HLine)
        f.setStyleSheet("color:#DDD;")
        return f

    # -- Passo 1: base --------------------------------------------------

    def _bloco_base(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)
        v.addWidget(_passo(1, "Onde o caminhão enche"))

        self.btn_base = _btn("📍  Marcar no mapa")
        self.btn_base.clicked.connect(self._marcar_base)
        v.addWidget(self.btn_base)

        self.lbl_base = QLabel("Nenhum ponto de carregamento marcado.")
        self.lbl_base.setWordWrap(True)
        self.lbl_base.setStyleSheet(
            "color:#888;font-size:11px;padding:4px 0 0 4px;")
        v.addWidget(self.lbl_base)
        return w

    # -- Passo 2: frota -------------------------------------------------

    def _bloco_frota(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)
        v.addWidget(_passo(2, "Quais caminhões você tem"))

        self.lst_frota = QListWidget()
        self.lst_frota.setMaximumHeight(110)
        self.lst_frota.setStyleSheet("font-size:11px;")
        self.lst_frota.itemDoubleClicked.connect(self._editar_caminhao)
        v.addWidget(self.lst_frota)

        h = QHBoxLayout()
        b1 = _btn("+ Caminhão", "#546E7A")
        b1.clicked.connect(self._add_caminhao)
        b2 = _btn("− Remover", "#546E7A")
        b2.clicked.connect(self._del_caminhao)
        h.addWidget(b1)
        h.addWidget(b2)
        v.addLayout(h)

        d = QLabel("Duplo clique para editar.")
        d.setStyleSheet("color:#888;font-size:10px;")
        v.addWidget(d)
        return w

    # -- Passo 3: pontos ------------------------------------------------

    def _bloco_pontos(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)
        v.addWidget(_passo(3, "Onde precisa entregar"))

        self.btn_add_ponto = _btn("📍  Clicar no mapa para adicionar", grande=True)
        self.btn_add_ponto.setCheckable(True)
        self.btn_add_ponto.clicked.connect(self._modo_add_ponto)
        v.addWidget(self.btn_add_ponto)

        dica = QLabel("Clique em cada lugar que precisa de água. "
                      "Clique com o botão direito para parar.")
        dica.setWordWrap(True)
        dica.setStyleSheet("color:#666;font-size:10px;padding:2px 0 4px 2px;")
        v.addWidget(dica)

        self.tb_pontos = QTableWidget(0, 4)
        self.tb_pontos.setHorizontalHeaderLabels(["Vai?", "Lugar", "m³", "!"])
        self.tb_pontos.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tb_pontos.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tb_pontos.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tb_pontos.customContextMenuRequested.connect(self._menu_ponto)
        self.tb_pontos.itemSelectionChanged.connect(self._destacar_sel)
        self.tb_pontos.itemChanged.connect(self._ponto_toggled)
        hh = self.tb_pontos.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.Fixed)
        hh.setSectionResizeMode(1, QHeaderView.Stretch)
        hh.setSectionResizeMode(2, QHeaderView.Fixed)
        hh.setSectionResizeMode(3, QHeaderView.Fixed)
        self.tb_pontos.setColumnWidth(0, 38)
        self.tb_pontos.setColumnWidth(2, 52)
        self.tb_pontos.setColumnWidth(3, 26)
        self.tb_pontos.setMinimumHeight(150)
        self.tb_pontos.setStyleSheet("font-size:11px;")
        v.addWidget(self.tb_pontos)

        info = QLabel("Desmarque a caixinha para tirar um lugar da rota "
                      "sem apagar. Botão direito para mais opções.")
        info.setWordWrap(True)
        info.setStyleSheet("color:#666;font-size:10px;")
        v.addWidget(info)

        h = QHBoxLayout()
        self.lbl_tot = QLabel("0 lugares · 0 m³")
        self.lbl_tot.setStyleSheet(
            f"font-weight:bold;color:{AZUL};font-size:12px;")
        h.addWidget(self.lbl_tot)
        h.addStretch()
        b = _btn("Limpar tudo", "#B0BEC5")
        b.clicked.connect(self._limpar_pontos)
        h.addWidget(b)
        v.addLayout(h)

        imp = QPushButton("Importar de uma camada do mapa...")
        imp.setFlat(True)
        imp.setStyleSheet(
            f"color:{AZUL};text-decoration:underline;font-size:11px;border:none;")
        imp.clicked.connect(self._importar)
        v.addWidget(imp)
        return w

    # -- Passo 4: calcular ----------------------------------------------

    def _bloco_estradas(self):
        """
        Passo 4: as estradas.

        Isto estava escondido em 'Ajustes avancados' — errado. Sem estradas
        o plugin nao faz nada util: a rota sai reta. E passo do fluxo, nao
        ajuste fino.
        """
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 6, 0, 0)
        v.setSpacing(5)

        v.addWidget(_passo(4, "As estradas da região"))

        self.lbl_estradas = QLabel()
        self.lbl_estradas.setWordWrap(True)
        self.lbl_estradas.setStyleSheet("font-size:10px;padding:2px 0;")
        v.addWidget(self.lbl_estradas)

        h = QHBoxLayout()
        h.setSpacing(5)
        self.btn_baixar = _btn("⬇  Ao redor dos meus pontos", "#2E7D32")
        self.btn_baixar.setToolTip(
            "Baixa só o necessário para a operação de hoje (~30 s).")
        self.btn_baixar.clicked.connect(lambda: self._baixar_estradas("pontos"))
        h.addWidget(self.btn_baixar)

        self.btn_dl_area = _btn("▭  Desenhar a área no mapa", "#2E7D32")
        self.btn_dl_area.setToolTip(
            "Arraste o mouse no mapa para escolher a região.\n"
            "Use para baixar uma regional inteira de uma vez.")
        self.btn_dl_area.clicked.connect(self._desenhar_area_dl)
        h.addWidget(self.btn_dl_area)
        v.addLayout(h)

        self._att_estradas()
        return w

    def _att_estradas(self):
        """
        Mostra o estado atual das estradas, sem o usuario perguntar.

        Tolerante a ser chamado antes do bloco avancado existir: o Passo 4 e
        montado antes do cb_via, e um AttributeError aqui derruba o plugin
        inteiro na abertura.
        """
        if not hasattr(self, "lbl_estradas"):
            return
        try:
            from ..core.baixar_osm import listar_cache
            itens = listar_cache()
        except Exception:
            itens = []

        cb = getattr(self, "cb_via", None)
        via = (cb.currentData() if (cb is not None and cb.count()) else None)
        if via is not None:
            n = via.featureCount()
            self.lbl_estradas.setText(
                f"<span style='color:#2E7D32;'>✓ <b>{n:,} trechos</b> "
                f"carregados ({via.name()})</span>".replace(",", "."))
        elif itens:
            tot = sum(i.get("trechos", 0) for i in itens)
            self.lbl_estradas.setText(
                f"<span style='color:#F57C00;'>{len(itens)} região(ões) já "
                f"baixada(s), mas nenhuma carregada. Baixe de novo — "
                f"ele reaproveita o que já tem.</span>")
        else:
            self.lbl_estradas.setText(
                "<span style='color:#C62828;'><b>Sem estradas.</b> "
                "A rota sairia em linha reta. Baixe abaixo — é rápido "
                "e fica salvo para usar sem internet.</span>")

    def _bloco_calcular(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)

        self.btn_calc = _btn("🚛   MONTAR A ROTA", "#2E7D32", grande=True)
        self.btn_calc.setMinimumHeight(46)
        self.btn_calc.clicked.connect(self.calcular)
        v.addWidget(self.btn_calc)

        self.barra = QProgressBar()
        self.barra.setVisible(False)
        self.barra.setTextVisible(False)
        self.barra.setMaximumHeight(4)
        v.addWidget(self.barra)

        self.btn_avanc = QToolButton()
        self.btn_avanc.setText("Ajustes avançados")
        self.btn_avanc.setCheckable(True)
        self.btn_avanc.setStyleSheet(
            "QToolButton{border:none;color:#666;font-size:11px;padding:4px;}")
        self.btn_avanc.setArrowType(Qt.RightArrow)
        self.btn_avanc.toggled.connect(self._toggle_avanc)
        v.addWidget(self.btn_avanc)

        self.box_avanc = self._avancado()
        self.box_avanc.setVisible(False)
        v.addWidget(self.box_avanc)
        return w

    def _avancado(self):
        g = QGroupBox()
        g.setStyleSheet("QGroupBox{border:1px solid #DDD;border-radius:4px;"
                        "margin-top:4px;padding:8px;}")
        f = QFormLayout(g)
        f.setSpacing(7)

        # --- Como calcular a rota ---
        # Ordem = prioridade do default. O primeiro item e o que abre
        # selecionado, entao tem que ser o que funciona sem instalar nada
        # nem depender de internet. Servidor de rotas da o melhor tracado,
        # mas exige uma das duas coisas.
        self.cb_motor = QComboBox()
        self.cb_motor.addItem("Camada de estradas do QGIS (offline)", "camada")
        self.cb_motor.addItem("Servidor de rotas (igual a um GPS)", "osrm")
        self.cb_motor.addItem("Estimativa rápida (linha reta)", "reta")
        self.cb_motor.setToolTip(
            "Camada do QGIS: usa o OSM que você baixa com o QuickOSM.\n"
            "  Funciona offline, sem instalar nada.\n\n"
            "Servidor de rotas: melhor traçado, igual a um GPS.\n"
            "  Precisa de internet, ou do servidor instalado aqui.\n\n"
            "Estimativa: linha reta. Só para triagem.")
        self.cb_motor.currentIndexChanged.connect(self._motor_mudou)
        f.addRow("Como calcular a rota:", self.cb_motor)

        from ..core.osrm import SERVIDORES
        self.cb_srv = QComboBox()
        for nome, url in SERVIDORES:
            self.cb_srv.addItem(nome, url)
        self.cb_srv.setEditable(True)
        self.cb_srv.setToolTip(
            "Servidor no meu computador: precisa instalar o OSRM,\n"
            "mas funciona sem internet e sem limite de uso.\n\n"
            "OSM público: não precisa instalar nada, mas exige\n"
            "internet e tem limite de uso.")
        f.addRow("Servidor:", self.cb_srv)

        self.btn_test_srv = _btn("Testar conexão com o servidor", "#546E7A")
        self.btn_test_srv.clicked.connect(self._testar_servidor)
        f.addRow("", self.btn_test_srv)

        self.lbl_srv = QLabel()
        self.lbl_srv.setWordWrap(True)
        self.lbl_srv.setStyleSheet("font-size:10px;padding:2px;")
        f.addRow("", self.lbl_srv)

        # --- Estradas: o que define a precisao do tempo ---
        self.cb_via = QComboBox()
        self.cb_via.setToolTip(
            "Camada com as estradas da região.\n"
            "Baixe com o QuickOSM: Vetor > QuickOSM > chave 'highway'.")
        self.cb_via.currentIndexChanged.connect(self._via_mudou)

        self.cb_classe = QComboBox()
        self.cb_classe.setToolTip(
            "Campo que diz o tipo da via (highway, no OSM).\n"
            "É o que permite dar velocidade diferente para\n"
            "asfalto e carroçável.")
        self.cb_piso = QComboBox()
        self.cb_piso.setToolTip(
            "Campo que diz o piso (surface, no OSM). Opcional,\n"
            "mas melhora bastante onde a BR não é asfaltada.")

        # Tres botoes visiveis, nao um menu escondido. A opcao de escolher a
        # area no mapa e a mais util e ninguem a encontrava dentro de um
        # dropdown.
        # Os botoes de baixar ficam no Passo 4, no fluxo principal.
        # Aqui embaixo fica so o ajuste fino de quem ja tem camada propria.
        self.btn_dl_estado = _btn("🗺  Baixar um estado inteiro", "#78909C")
        self.btn_dl_estado.setToolTip(
            "Demora ~90 min e traz bastante coisa dos estados vizinhos.\n"
            "Na maioria dos casos, desenhar a área no Passo 4 é melhor.")
        self.btn_dl_estado.clicked.connect(
            lambda: self._baixar_estradas("estado"))
        f.addRow("", self.btn_dl_estado)

        f.addRow("Camada de estradas:", self.cb_via)
        f.addRow("Campo do tipo de via:", self.cb_classe)
        f.addRow("Campo do piso:", self.cb_piso)

        self.btn_testar = _btn("Testar a camada de estradas", "#546E7A")
        self.btn_testar.setToolTip(
            "Roda a mesma verificacao do calculo e diz, em portugues,\n"
            "se a rota vai seguir as estradas — e se nao for, por que.")
        self.btn_testar.clicked.connect(self._testar_camada)
        f.addRow("", self.btn_testar)

        self.lbl_precisao = QLabel()
        self.lbl_precisao.setWordWrap(True)
        self.lbl_precisao.setStyleSheet("font-size:10px;padding:4px;")
        f.addRow("", self.lbl_precisao)

        # --- Velocidades ---
        self.sp_vel = QDoubleSpinBox()
        self.sp_vel.setRange(5, 120)
        self.sp_vel.setValue(40)
        self.sp_vel.setSuffix(" km/h")
        self.sp_vel.setToolTip(
            "Usada só quando não há camada de estradas,\n"
            "ou para trechos fora da malha.")

        self.sp_terra = QDoubleSpinBox()
        self.sp_terra.setRange(0.2, 1.0)
        self.sp_terra.setValue(0.6)
        self.sp_terra.setSingleStep(0.05)
        self.sp_terra.setToolTip(
            "Quanto a estrada de terra reduz a velocidade.\n"
            "0.6 = anda a 60% do que andaria no asfalto.")

        self.sp_sinuos = QDoubleSpinBox()
        self.sp_sinuos.setRange(1.0, 2.5)
        self.sp_sinuos.setValue(1.3)
        self.sp_sinuos.setSingleStep(0.05)
        self.sp_sinuos.setToolTip(
            "Só para trechos sem estrada mapeada.\n"
            "Quanto a estrada dá volta em relação à linha reta.")

        f.addRow("Velocidade (sem estradas):", self.sp_vel)
        f.addRow("Fator da terra:", self.sp_terra)
        f.addRow("Fator de volta:", self.sp_sinuos)

        # --- Operacao ---
        self.sp_fixo = QDoubleSpinBox()
        self.sp_fixo.setRange(0, 120)
        self.sp_fixo.setValue(10)
        self.sp_fixo.setSuffix(" min")
        self.sp_fixo.setToolTip(
            "Tempo parado em cada casa ANTES de descarregar:\n"
            "manobrar, posicionar, puxar a mangueira, conversar.")

        self.sp_hora = QSpinBox()
        self.sp_hora.setRange(0, 23)
        self.sp_hora.setValue(6)
        self.sp_hora.setSuffix("h")

        f.addRow("Tempo parado por casa:", self.sp_fixo)
        f.addRow("Começa às:", self.sp_hora)

        b_cache = QPushButton("Ver estradas já baixadas / liberar espaço")
        b_cache.setFlat(True)
        b_cache.setStyleSheet(
            f"color:{AZUL};text-decoration:underline;font-size:10px;border:none;")
        b_cache.clicked.connect(self._ver_cache)
        f.addRow("", b_cache)

        b = QPushButton("Ver tabela de velocidades por tipo de via")
        b.setFlat(True)
        b.setStyleSheet(
            f"color:{AZUL};text-decoration:underline;font-size:10px;border:none;")
        b.clicked.connect(self._ver_velocidades)
        f.addRow("", b)
        return g

    def _motor_mudou(self):
        """Mostra so o que interessa ao modo escolhido."""
        m = self.cb_motor.currentData()
        for w in (self.cb_srv, self.btn_test_srv, self.lbl_srv):
            w.setVisible(m == "osrm")
        for w in (self.cb_via, self.cb_classe, self.cb_piso,
                  self.btn_testar, self.lbl_precisao):
            w.setVisible(m == "camada")
        self.sp_sinuos.setEnabled(m == "reta")
        self.sp_vel.setEnabled(m != "osrm")
        self.sp_terra.setEnabled(m == "camada")
        if m == "osrm" and not self.lbl_srv.text():
            self.lbl_srv.setText(
                "<span style='color:#666;'>Aperte 'Testar conexão' para ver "
                "se o servidor responde.</span>")

    def _url_servidor(self) -> str:
        """
        URL do servidor, tolerando o combo editavel.

        currentData() volta None quando o usuario digita uma URL propria;
        nesse caso o que vale e o texto.
        """
        d = self.cb_srv.currentData()
        t = self.cb_srv.currentText().strip()
        if d and t == self.cb_srv.itemText(self.cb_srv.currentIndex()):
            return d
        return t or (d or "")

    def _salvar_pref(self):
        from qgis.PyQt.QtCore import QSettings
        s = QSettings()
        s.setValue("piparouter/motor", self.cb_motor.currentData())
        s.setValue("piparouter/servidor", self._url_servidor())

    def _carregar_pref(self):
        from qgis.PyQt.QtCore import QSettings
        s = QSettings()
        m = s.value("piparouter/motor")
        if m:
            i = self.cb_motor.findData(m)
            if i >= 0:
                self.cb_motor.setCurrentIndex(i)
        u = s.value("piparouter/servidor")
        if u:
            i = self.cb_srv.findData(u)
            if i >= 0:
                self.cb_srv.setCurrentIndex(i)
            else:
                self.cb_srv.setEditText(u)

    def _testar_servidor(self):
        from ..core.osrm import ClienteOSRM
        url = self._url_servidor()
        if not url:
            return
        self.lbl_srv.setText("Testando...")
        from qgis.PyQt.QtWidgets import QApplication
        QApplication.processEvents()

        ok, msg = ClienteOSRM(url).testar()
        if ok:
            self._salvar_pref()
            self.lbl_srv.setText(
                f"<span style='color:#2E7D32;'><b>Servidor respondendo.</b> "
                f"A rota vai sair pelas estradas, igual a um GPS.</span>")
        else:
            local = "127.0.0.1" in url or "localhost" in url
            if local:
                dica = ("<br><br>Para usar o servidor do seu computador é "
                        "preciso instalá-lo uma vez (veja o README). "
                        "Enquanto isso, escolha <b>'OSM público'</b> aqui na "
                        "lista, ou use a <b>'Camada de estradas do QGIS'</b> "
                        "em 'Como calcular a rota' — essa funciona offline.")
            else:
                dica = ("<br><br>Use a <b>'Camada de estradas do QGIS'</b> em "
                        "'Como calcular a rota'. Funciona offline com o OSM "
                        "que você baixar pelo QuickOSM.")
            self.lbl_srv.setText(
                f"<span style='color:#C62828;'><b>Não deu.</b> {msg}"
                f"{dica}</span>")

    def _via_mudou(self):
        """Detecta os campos de classe e piso; atualiza o Passo 4."""
        if hasattr(self, "lbl_estradas"):
            self._att_estradas()
        lyr = self.cb_via.currentData()
        self.cb_classe.clear()
        self.cb_piso.clear()
        self.cb_classe.addItem("— não tem —", None)
        self.cb_piso.addItem("— não tem —", None)

        if not lyr:
            self._att_precisao()
            return

        nomes = [f.name() for f in lyr.fields()]
        for n in nomes:
            self.cb_classe.addItem(n, n)
            self.cb_piso.addItem(n, n)

        # OSM/QuickOSM usa 'highway' e 'surface'. Tenta achar sozinho.
        for cand in ("highway", "fclass", "tipo", "classe", "road_type",
                     "type", "class"):
            for n in nomes:
                if n.lower() == cand:
                    self.cb_classe.setCurrentIndex(self.cb_classe.findData(n))
                    break
            else:
                continue
            break
        for cand in ("surface", "piso", "pavimento", "superficie"):
            for n in nomes:
                if n.lower() == cand:
                    self.cb_piso.setCurrentIndex(self.cb_piso.findData(n))
                    break
            else:
                continue
            break
        self._att_precisao()

    def _att_precisao(self):
        """Diz ao usuario, antes de calcular, o quanto confiar no tempo."""
        via = self.cb_via.currentData() if self.cb_via.count() else None
        cls = self.cb_classe.currentData() if self.cb_classe.count() else None
        if not via:
            self.lbl_precisao.setText(
                "<span style='color:#C62828;'><b>Tempo estimado.</b> "
                "Sem camada de estradas, a distância é linha reta corrigida e "
                "a velocidade é uma média só. O horário de chegada pode errar "
                "por muito.</span>")
        elif not cls:
            self.lbl_precisao.setText(
                "<span style='color:#E65100;'><b>Tempo aproximado.</b> "
                "A rota segue as estradas, mas sem o tipo de via todas correm "
                "à mesma velocidade. Asfalto e carroçável ficam iguais.</span>")
        else:
            piso = self.cb_piso.currentData()
            extra = ("" if piso else
                     " Informe também o piso para melhorar onde a estrada não "
                     "é asfaltada.")
            self.lbl_precisao.setText(
                f"<span style='color:#2E7D32;'><b>Tempo calculado pela "
                f"estrada.</b> Cada trecho usa a velocidade do seu tipo de "
                f"via.{extra}</span>")

    def _salvar_operacao(self):
        """
        Grava base, frota e locais num JSON.

        Existe porque remarcar 20 povoados a cada uso e inviavel. A operacao
        de um municipio muda pouco entre semanas: mudam os volumes e quem
        entra na rota, nao onde ficam os lugares.
        """
        import json
        if not self.base and not self.pontos:
            QMessageBox.information(self, "PipaRouter", "Não há nada para salvar.")
            return
        f, _ = QFileDialog.getSaveFileName(
            self, "Salvar operação", "operacao_pipa.json", "JSON (*.json)")
        if not f:
            return
        dados = {
            "versao": 1,
            "base": ({"nome": self.base.nome, "x": self.base.x,
                      "y": self.base.y,
                      "vazao": self.base.vazao_enchimento}
                     if self.base else None),
            "frota": [{"placa": c.placa, "capacidade": c.capacidade,
                       "vazao_descarga": c.vazao_descarga,
                       "jornada_h": c.jornada_max / 60.0,
                       "custo_km": c.custo_km} for c in self.frota],
            "pontos": [{"nome": p["nome"], "x": p["x"], "y": p["y"],
                        "volume": p["volume"], "prio": p["prio"],
                        "pessoas": p["pessoas"], "ativo": p["ativo"]}
                       for p in self.pontos],
        }
        try:
            with open(f, "w", encoding="utf-8") as fh:
                json.dump(dados, fh, ensure_ascii=False, indent=1)
            self.iface.messageBar().pushSuccess("PipaRouter", f"Salvo: {f}")
        except Exception as e:
            QMessageBox.warning(self, "PipaRouter", f"Não deu para salvar:\n{e}")

    def _abrir_operacao(self):
        import json
        f, _ = QFileDialog.getOpenFileName(
            self, "Abrir operação", "", "JSON (*.json)")
        if not f:
            return
        try:
            with open(f, encoding="utf-8") as fh:
                d = json.load(fh)
        except Exception as e:
            QMessageBox.warning(self, "PipaRouter", f"Não deu para abrir:\n{e}")
            return

        if self.pontos or self.base:
            r = QMessageBox.question(
                self, "PipaRouter",
                "Isto vai substituir o que está marcado agora. Continuar?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if r != QMessageBox.Yes:
                return

        self.marcadores.limpar_tudo()
        self.pontos = []
        self.solucao = None
        self.box_res.setVisible(False)

        b = d.get("base")
        if b:
            self.base = Base(1, b["nome"], b["x"], b["y"],
                             vazao_enchimento=b.get("vazao", 50.0))
            self.marcadores.marcar_base(b["x"], b["y"])
            self.lbl_base.setText(
                f"<b style='color:{AZUL};'>{b['nome']}</b> · enche a "
                f"{b.get('vazao',50):g} m³/h")
            self.btn_base.setText("📍  Trocar local")

        self.frota = []
        for i, c in enumerate(d.get("frota", []), 1):
            self.frota.append(Caminhao(
                id=i, placa=c["placa"], capacidade=c["capacidade"],
                base_id=1, vazao_descarga=c.get("vazao_descarga", 30.0),
                jornada_max=c.get("jornada_h", 8) * 60,
                custo_km=c.get("custo_km", 0.0)))
        if not self.frota:
            self._frota_padrao()
        self._render_frota()

        self._prox_id = 1
        for p in d.get("pontos", []):
            novo = {"id": self._prox_id, "nome": p["nome"], "x": p["x"],
                    "y": p["y"], "volume": p["volume"],
                    "prio": p.get("prio", 1), "pessoas": p.get("pessoas", 0),
                    "ativo": p.get("ativo", True)}
            self._prox_id += 1
            self.pontos.append(novo)
            self.marcadores.marcar_ponto(novo["id"], novo["x"], novo["y"],
                                         novo["prio"],
                                         atendido=None if novo["ativo"] else False)
        self.canvas.refresh()
        self._render_pontos()
        self._atualizar_estado()
        self.iface.messageBar().pushSuccess(
            "PipaRouter",
            f"{len(self.pontos)} locais carregados. Ajuste os volumes e "
            f"monte a rota.")

    def _desenhar_area_dl(self):
        """Liga a ferramenta de desenhar o retangulo da area a baixar."""
        from .mapa import FerramentaRetangulo

        # Ja ligada? desliga (o botao vira um interruptor)
        if getattr(self, "_ft_ret", None):
            self._cancelar_desenho()
            return

        self.ferramenta_anterior = self.canvas.mapTool()
        self._ft_ret = FerramentaRetangulo(
            self.canvas,
            ao_escolher=self._area_desenhada,
            ao_cancelar=self._cancelar_desenho,
            iface=self.iface)
        self.canvas.setMapTool(self._ft_ret)

        self.btn_dl_area.setText("◼  Arrastando... (clique para cancelar)")
        self.btn_dl_area.setStyleSheet(
            "background:#F57C00;color:white;font-weight:bold;"
            "border:none;padding:7px;border-radius:3px;")
        self.iface.messageBar().pushInfo(
            "PipaRouter",
            "Agora ARRASTE o mouse no mapa (segure o botão esquerdo e mova) "
            "para marcar a região. O tamanho em km aparece embaixo.")

    def _cancelar_desenho(self):
        self._restaurar_ferramenta()
        self._botao_area_normal()

    def _botao_area_normal(self):
        self.btn_dl_area.setText("▭  Desenhar a área no mapa")
        self.btn_dl_area.setStyleSheet(
            "background:#2E7D32;color:white;font-weight:bold;"
            "border:none;padding:7px;border-radius:3px;")

    def _restaurar_ferramenta(self):
        ft = getattr(self, "_ft_ret", None)
        if ft:
            try:
                self.canvas.unsetMapTool(ft)
            except Exception:
                pass
            self._ft_ret = None
        if getattr(self, "ferramenta_anterior", None):
            try:
                self.canvas.setMapTool(self.ferramenta_anterior)
            except Exception:
                pass
            self.ferramenta_anterior = None

    def _area_desenhada(self, s, w, n, e):
        self._restaurar_ferramenta()
        self._botao_area_normal()
        self._baixar_estradas("bbox", bbox=(s, w, n, e))

    def _bbox_da_tela(self):
        """Retângulo visível do mapa, em EPSG:4326."""
        from qgis.core import (
            QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject,
        )
        ext = self.canvas.extent()
        crs = self.canvas.mapSettings().destinationCrs()
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        if crs != wgs:
            tr = QgsCoordinateTransform(crs, wgs, QgsProject.instance())
            ext = tr.transformBoundingBox(ext)
        return (ext.yMinimum(), ext.xMinimum(), ext.yMaximum(), ext.xMaximum())

    def _baixar_estradas(self, modo="pontos", bbox=None):
        """
        Baixa estradas do OSM.

        modo: 'pontos' (ao redor dos pontos marcados)
              'bbox'   (retangulo desenhado no mapa)
              'tela'   (o que esta enquadrado)
              'estado' (bbox de um estado)
        """
        from ..core.baixar_osm import (
            baixar_estradas, baixar_area_grande, carregar_camada, estimar,
            ErroOverpass, ESTADOS, _bbox,
        )
        from qgis.PyQt.QtWidgets import QApplication, QInputDialog

        # --- define a area ---
        if modo == "bbox" and bbox:
            pass          # ja veio pronta do desenho
        elif modo == "pontos":
            pts = []
            if self.base:
                pts.append((self.base.x, self.base.y))
            pts += [(p["x"], p["y"]) for p in self.pontos if p["ativo"]]
            if not pts:
                QMessageBox.information(
                    self, "PipaRouter",
                    "Marque primeiro onde o caminhão enche e onde vai "
                    "entregar.\n\nAí eu sei qual área baixar.")
                return
            bbox = _bbox(pts, 5.0)

        elif modo == "tela":
            bbox = self._bbox_da_tela()
            QMessageBox.information(
                self, "PipaRouter",
                "Vou baixar as estradas da área que está aparecendo no mapa "
                "agora.\n\nSe não for a área certa, feche isto, ajuste o "
                "zoom e tente de novo.")

        elif modo == "estado":
            nomes = sorted(ESTADOS)
            nome, ok = QInputDialog.getItem(
                self, "PipaRouter", "Qual estado?", nomes,
                nomes.index("Piauí") if "Piauí" in nomes else 0, False)
            if not ok:
                return
            bbox = ESTADOS[nome]

        est = estimar(bbox)

        # --- confirma se for grande ---
        if est["quadriculas"] > 1:
            aviso = ""
            if modo == "estado":
                # A bbox de um estado e um retangulo; o estado nao e.
                # Nao deixar isso implicito: o usuario vai esperar 2h
                # achando que baixa "o Piaui".
                aviso = (
                    "\n\nATENÇÃO: isto baixa o RETÂNGULO que envolve o "
                    "estado, não o contorno dele. No caso do Piauí, mais da "
                    "metade do que vier é Maranhão, Ceará e Bahia.\n\n"
                    "Se você opera uma região, use '▭ Desenhar a área no "
                    "mapa' — a mesma regional sai em ~6 minutos.")

            r = QMessageBox.question(
                self, "PipaRouter",
                f"Área: {est['largura_km']:.0f} x {est['altura_km']:.0f} km "
                f"({est['km2']:,.0f} km²)\n\n"
                f"Vai precisar de {est['quadriculas']} consultas ao "
                f"servidor.\n"
                f"Tempo estimado: ~{est['minutos_estimados']:.0f} minutos\n"
                f"Tamanho estimado: ~{est['mb_estimados']:.0f} MB\n\n"
                f"O QGIS fica ocupado durante o download.\n"
                f"Se cair no meio, o que já veio fica guardado — é só "
                f"mandar baixar de novo que ele continua de onde parou."
                f"{aviso}\n\n"
                f"Começar?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if r != QMessageBox.Yes:
                return

        # --- baixa ---
        self.barra.setVisible(True)
        self.barra.setValue(0)
        self.btn_baixar.setEnabled(False)
        self._cancelar_dl = False

        def prog(p, msg=""):
            self.barra.setValue(p)
            if msg:
                self.btn_baixar.setText(msg[:42])
            QApplication.processEvents()

        try:
            if est["quadriculas"] > 1:
                gpkg, info = baixar_area_grande(
                    bbox, callback=prog,
                    cancelado=lambda: self._cancelar_dl)
            else:
                pts = [(bbox[1], bbox[0]), (bbox[3], bbox[2])]
                gpkg, info = baixar_estradas(pts, margem_km=0.0,
                                             callback=prog)

            lyr = carregar_camada(gpkg, f"Estradas OSM ({info['trechos']})")
            QgsProject.instance().addMapLayer(lyr)
            self._carregar_camadas_linha()
            i2 = self.cb_via.findText(lyr.name())
            if i2 >= 0:
                self.cb_via.setCurrentIndex(i2)
            self._via_mudou()
            self._att_estradas()

            falhou = info.get("quadriculas_falharam", 0)
            msg = [f"{info['trechos']:,} trechos de estrada prontos."]
            if info.get("do_cache"):
                msg.append("(já estava salvo aqui — não precisei baixar)")
            if falhou:
                msg.append(f"\n{falhou} pedaço(s) falharam. Nessas partes a "
                           f"rota pode sair reta. Aperte o mesmo botão de "
                           f"novo — ele tenta só os que faltam.")
            msg.append("\nJá selecionei a camada. É só montar a rota.")
            msg.append("\nFica salvo — da próxima vez funciona sem internet.")
            msg.append(f"\n{info.get('atribuicao','')}")
            QMessageBox.information(self, "PipaRouter", "\n".join(msg))

        except ErroOverpass as e:
            QMessageBox.warning(self, "PipaRouter",
                                f"Não consegui baixar.\n\n{e}")
        except Exception as e:
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, "PipaRouter", f"Erro: {e}")
        finally:
            self.barra.setVisible(False)
            self.btn_baixar.setEnabled(True)
            self.btn_baixar.setText("⬇  Baixar estradas")

    def _testar_camada(self):
        """Diagnostica a camada ANTES de calcular."""
        via = self.cb_via.currentData() if self.cb_via.count() else None
        pontos = []
        if self.base:
            pontos.append((self.base.x, self.base.y))
        pontos += [(p["x"], p["y"]) for p in self.pontos if p["ativo"]]

        if not pontos:
            QMessageBox.information(
                self, "PipaRouter",
                "Marque pelo menos o ponto de carregamento antes de testar.")
            return

        from .diagnostico import DialogoDiagnostico
        d = DialogoDiagnostico(
            via, pontos,
            self.cb_classe.currentData() if self.cb_classe.count() else None,
            self.cb_piso.currentData() if self.cb_piso.count() else None,
            self.tabela_vel, self.sp_terra.value(), self)
        d.exec_()

    def _ver_cache(self):
        from ..core.baixar_osm import listar_cache, limpar_cache, pasta_cache
        itens = listar_cache()
        if not itens:
            QMessageBox.information(
                self, "PipaRouter",
                "Nenhuma estrada baixada ainda.\n\n"
                "Use um dos botões de baixar estradas, em Ajustes "
                "avançados.")
            return
        tot = sum(i["mb"] for i in itens)
        L = [f"{len(itens)} região(ões) baixada(s), {tot:.1f} MB no total:", ""]
        for i in itens:
            q = i.get("baixado_em", "?")
            n = i.get("trechos", "?")
            L.append(f"  • {n} trechos, {i['mb']:.1f} MB — baixado em {q}")
        L.append("")
        L.append(f"Ficam em: {pasta_cache()}")
        L.append("")
        L.append("Estes arquivos são o que faz o plugin funcionar sem "
                 "internet. Só apague se precisar do espaço.")

        cx = QMessageBox(self)
        cx.setWindowTitle("PipaRouter")
        cx.setText("\n".join(L))
        b_lim = cx.addButton("Apagar tudo", QMessageBox.DestructiveRole)
        cx.addButton("Fechar", QMessageBox.RejectRole)
        cx.exec_()
        if cx.clickedButton() is b_lim:
            mb = limpar_cache()
            QMessageBox.information(
                self, "PipaRouter",
                f"{mb} MB liberados.\n\n"
                f"Vai precisar baixar de novo na próxima vez.")

    def _ver_velocidades(self):
        from ..core.roteador import VELOCIDADE_PADRAO
        d = DialogoVelocidades(self.tabela_vel or VELOCIDADE_PADRAO, self)
        if d.exec_():
            self.tabela_vel = d.tabela()

    def _toggle_avanc(self, on):
        self.box_avanc.setVisible(on)
        self.btn_avanc.setArrowType(Qt.DownArrow if on else Qt.RightArrow)
        if on:
            self._carregar_camadas_linha()
            self._att_precisao()
            self._motor_mudou()
            if not getattr(self, "_pref_lida", False):
                self._carregar_pref()
                self._motor_mudou()
                self._pref_lida = True

    def _carregar_camadas_linha(self):
        from qgis.core import QgsWkbTypes
        self.cb_via.clear()
        self.cb_via.addItem("— não tenho —", None)
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                if (lyr.type() == lyr.VectorLayer
                        and lyr.geometryType() == QgsWkbTypes.LineGeometry):
                    self.cb_via.addItem(lyr.name(), lyr)
            except Exception:
                pass
        self._via_mudou()

    # -- Passo 5: resultado ---------------------------------------------

    def _bloco_resultado(self):
        self.box_res = QGroupBox("Resultado")
        self.box_res.setStyleSheet(
            f"QGroupBox{{font-weight:bold;color:{AZUL};border:1px solid #DDD;"
            "border-radius:4px;margin-top:8px;padding-top:12px;}}")
        v = QVBoxLayout(self.box_res)

        self.lbl_resumo = QLabel()
        self.lbl_resumo.setWordWrap(True)
        self.lbl_resumo.setStyleSheet("font-size:12px;padding:4px;")
        v.addWidget(self.lbl_resumo)

        self.txt_rotas = QTextEdit()
        self.txt_rotas.setReadOnly(True)
        self.txt_rotas.setFont(QFont("Courier New", 8))
        self.txt_rotas.setMinimumHeight(190)
        v.addWidget(self.txt_rotas)

        self.btn_pq_reta = _btn("Por que a rota saiu reta?", "#C62828")
        self.btn_pq_reta.clicked.connect(self._testar_camada)
        self.btn_pq_reta.setVisible(False)
        v.addWidget(self.btn_pq_reta)

        h = QHBoxLayout()
        self.btn_mapa = _btn("Ver no mapa", "#546E7A")
        self.btn_mapa.clicked.connect(self._add_camadas)
        self.btn_kmz = _btn("KMZ", "#546E7A")
        self.btn_kmz.clicked.connect(self._exp_kmz)
        self.btn_xls = _btn("Planilha", "#546E7A")
        self.btn_xls.clicked.connect(self._exp_xls)
        for b in (self.btn_mapa, self.btn_kmz, self.btn_xls):
            h.addWidget(b)
        v.addLayout(h)

        self.box_res.setVisible(False)
        return self.box_res

    # ==================================================================
    # Frota
    # ==================================================================

    def _frota_padrao(self):
        self.frota = [Caminhao(1, "Caminhão 1", 10.0, 1,
                               vazao_descarga=30.0, jornada_max=480)]
        self._render_frota()

    def _render_frota(self):
        self.lst_frota.clear()
        for c in self.frota:
            t = (f"{c.placa} · {c.capacidade:g} m³ · "
                 f"descarga {c.vazao_descarga:g} m³/h · "
                 f"{c.jornada_max/60:g}h de jornada")
            self.lst_frota.addItem(QListWidgetItem(t))

    def _add_caminhao(self):
        from .dialogos_ponto import DialogoBase  # noqa
        d = DialogoCaminhao(len(self.frota) + 1, parent=self)
        if d.exec_():
            self.frota.append(Caminhao(
                id=len(self.frota) + 1, placa=d.nome(),
                capacidade=d.capacidade(), base_id=1,
                vazao_descarga=d.vazao(), jornada_max=d.jornada() * 60,
                custo_km=d.custo(),
            ))
            self._render_frota()
            self._atualizar_estado()

    def _editar_caminhao(self, item):
        i = self.lst_frota.row(item)
        c = self.frota[i]
        d = DialogoCaminhao(i + 1, c, parent=self)
        if d.exec_():
            c.placa = d.nome()
            c.capacidade = d.capacidade()
            c.vazao_descarga = d.vazao()
            c.jornada_max = d.jornada() * 60
            c.custo_km = d.custo()
            self._render_frota()

    def _del_caminhao(self):
        i = self.lst_frota.currentRow()
        if i < 0:
            return
        if len(self.frota) == 1:
            QMessageBox.information(
                self, "PipaRouter", "Você precisa de pelo menos um caminhão.")
            return
        self.frota.pop(i)
        for k, c in enumerate(self.frota, 1):
            c.id = k
        self._render_frota()

    # ==================================================================
    # Base
    # ==================================================================

    def _marcar_base(self):
        self._ativar_ferramenta(self._base_clicada)
        self.iface.messageBar().pushInfo(
            "PipaRouter", "Clique no mapa onde o caminhão enche.")

    def _base_clicada(self, x, y):
        self._desativar_ferramenta()
        d = DialogoBase(x, y, self)
        if not d.exec_():
            return
        self.base = Base(1, d.nome(), x, y, vazao_enchimento=d.vazao())
        self.marcadores.marcar_base(x, y)
        self.canvas.refresh()
        self.lbl_base.setText(
            f"<b style='color:{AZUL};'>{d.nome()}</b> · enche a "
            f"{d.vazao():g} m³/h")
        self.lbl_base.setStyleSheet("font-size:11px;padding:4px 0 0 4px;")
        self.btn_base.setText("📍  Trocar local")
        self._atualizar_estado()

    # ==================================================================
    # Pontos de entrega
    # ==================================================================

    def _modo_add_ponto(self, on):
        if on:
            if not self.base:
                self.btn_add_ponto.setChecked(False)
                QMessageBox.information(
                    self, "PipaRouter",
                    "Primeiro marque onde o caminhão enche (passo 1).")
                return
            self._ativar_ferramenta(self._ponto_clicado, self._parar_add)
            self.btn_add_ponto.setText("Clicando... (botão direito para parar)")
            self.iface.messageBar().pushInfo(
                "PipaRouter",
                "Clique em cada lugar que precisa de água. "
                "Botão direito encerra.")
        else:
            self._parar_add()

    def _parar_add(self):
        self._desativar_ferramenta()
        self.btn_add_ponto.setChecked(False)
        self.btn_add_ponto.setText("📍  Clicar no mapa para adicionar")

    def _ponto_clicado(self, x, y):
        d = DialogoPonto(x, y, parent=self)
        if not d.exec_():
            return
        p = {
            "id": self._prox_id,
            "nome": d.nome(),
            "x": x, "y": y,
            "volume": d.volume(),
            "prio": d.prioridade(),
            "pessoas": d.pessoas(),
            "ativo": True,
        }
        self._prox_id += 1
        self.pontos.append(p)
        self.marcadores.marcar_ponto(p["id"], x, y, p["prio"])
        self.canvas.refresh()
        self._render_pontos()
        self._atualizar_estado()

    def _render_pontos(self):
        self.tb_pontos.blockSignals(True)
        self.tb_pontos.setRowCount(0)
        for p in self.pontos:
            r = self.tb_pontos.rowCount()
            self.tb_pontos.insertRow(r)

            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Checked if p["ativo"] else Qt.Unchecked)
            chk.setData(Qt.UserRole, p["id"])
            self.tb_pontos.setItem(r, 0, chk)

            it = QTableWidgetItem(p["nome"])
            if p["pessoas"]:
                it.setToolTip(f"{p['pessoas']} pessoas · {p['volume']:.1f} m³")
            if not p["ativo"]:
                it.setForeground(QColor("#AAA"))
                f = it.font()
                f.setStrikeOut(True)
                it.setFont(f)
            self.tb_pontos.setItem(r, 1, it)

            self.tb_pontos.setItem(r, 2, QTableWidgetItem(f"{p['volume']:.1f}"))

            urg = {1: "", 2: "!", 3: "!!"}[p["prio"]]
            iu = QTableWidgetItem(urg)
            iu.setForeground(QColor({1: "#0026BD", 2: "#F57C00",
                                     3: "#C62828"}[p["prio"]]))
            iu.setToolTip({1: "Normal", 2: "Urgente",
                           3: "Crítico — sem água"}[p["prio"]])
            self.tb_pontos.setItem(r, 3, iu)
        self.tb_pontos.blockSignals(False)
        self._atualizar_total()

    def _ponto_toggled(self, item):
        if item.column() != 0:
            return
        pid = item.data(Qt.UserRole)
        for p in self.pontos:
            if p["id"] == pid:
                p["ativo"] = item.checkState() == Qt.Checked
                self.marcadores.marcar_ponto(
                    p["id"], p["x"], p["y"], p["prio"],
                    atendido=None if p["ativo"] else False)
                break
        self.canvas.refresh()
        self._render_pontos()
        self._atualizar_total()

    def _atualizar_total(self):
        at = [p for p in self.pontos if p["ativo"]]
        vol = sum(p["volume"] for p in at)
        pes = sum(p["pessoas"] for p in at)
        txt = f"{len(at)} lugares · {vol:.1f} m³"
        if pes:
            txt += f" · ~{pes} pessoas"
        if len(at) < len(self.pontos):
            txt += f"  ({len(self.pontos)-len(at)} fora)"
        self.lbl_tot.setText(txt)

    def _menu_ponto(self, pos):
        r = self.tb_pontos.rowAt(pos.y())
        if r < 0:
            return
        p = self.pontos[r]
        m = QMenu(self)
        a1 = m.addAction("Tirar da rota" if p["ativo"] else "Colocar na rota")
        a2 = m.addAction("Editar...")
        m.addSeparator()
        a3 = m.addAction("Ir até no mapa")
        m.addSeparator()
        a4 = m.addAction("Apagar")
        act = m.exec_(self.tb_pontos.mapToGlobal(pos))

        if act == a1:
            p["ativo"] = not p["ativo"]
            self.marcadores.marcar_ponto(
                p["id"], p["x"], p["y"], p["prio"],
                atendido=None if p["ativo"] else False)
            self.canvas.refresh()
            self._render_pontos()
        elif act == a2:
            d = DialogoPonto(p["x"], p["y"], p["nome"], self)
            d.sp_vol.setValue(p["volume"])
            d.rb_m3.setChecked(True)
            {1: d.rb_p1, 2: d.rb_p2, 3: d.rb_p3}[p["prio"]].setChecked(True)
            if d.exec_():
                p.update(nome=d.nome(), volume=d.volume(),
                         prio=d.prioridade(), pessoas=d.pessoas())
                self.marcadores.marcar_ponto(p["id"], p["x"], p["y"], p["prio"])
                self.canvas.refresh()
                self._render_pontos()
        elif act == a3:
            self._zoom(p["x"], p["y"])
        elif act == a4:
            self.marcadores.remover_ponto(p["id"])
            self.pontos.remove(p)
            self.canvas.refresh()
            self._render_pontos()
        self._atualizar_estado()

    def _destacar_sel(self):
        r = self.tb_pontos.currentRow()
        if 0 <= r < len(self.pontos):
            p = self.pontos[r]
            self.marcadores.destacar(p["x"], p["y"])
            self.canvas.refresh()

    def _zoom(self, x, y):
        from qgis.core import (
            QgsCoordinateReferenceSystem, QgsCoordinateTransform,
            QgsPointXY, QgsRectangle,
        )
        crs_mapa = self.canvas.mapSettings().destinationCrs()
        crs_wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        p = QgsPointXY(x, y)
        if crs_mapa != crs_wgs:
            tr = QgsCoordinateTransform(crs_wgs, crs_mapa, QgsProject.instance())
            p = tr.transform(p)
        d = self.canvas.extent().width() * 0.08
        self.canvas.setExtent(QgsRectangle(p.x()-d, p.y()-d, p.x()+d, p.y()+d))
        self.canvas.refresh()

    def _limpar_pontos(self):
        if not self.pontos:
            return
        if QMessageBox.question(
            self, "PipaRouter",
            f"Apagar todos os {len(self.pontos)} lugares?",
            QMessageBox.Yes | QMessageBox.No,
        ) != QMessageBox.Yes:
            return
        for p in self.pontos:
            self.marcadores.remover_ponto(p["id"])
        self.pontos = []
        self.marcadores.limpar_rotas()
        self.canvas.refresh()
        self._render_pontos()
        self.box_res.setVisible(False)
        self._atualizar_estado()

    def _importar(self):
        d = DialogoImportar(self)
        if not d.exec_():
            return
        novos = d.resultado()
        if not novos:
            QMessageBox.information(self, "PipaRouter",
                                    "Nenhum ponto encontrado na camada.")
            return
        for n in novos:
            n["id"] = self._prox_id
            self._prox_id += 1
            n["ativo"] = True
            self.pontos.append(n)
            self.marcadores.marcar_ponto(n["id"], n["x"], n["y"], n["prio"])
        self.canvas.refresh()
        self._render_pontos()
        self._atualizar_estado()

        self.iface.messageBar().pushSuccess(
            "PipaRouter", f"{len(novos)} lugares importados.")

    # ==================================================================
    # Ferramenta de mapa
    # ==================================================================

    def _ativar_ferramenta(self, cb, cb_cancel=None):
        self.ferramenta_anterior = self.canvas.mapTool()
        self.ferramenta = FerramentaClique(self.canvas)
        self.ferramenta.ponto_clicado.connect(cb)
        self.ferramenta.cancelado.connect(cb_cancel or self._desativar_ferramenta)
        self.canvas.setMapTool(self.ferramenta)

    def _desativar_ferramenta(self):
        if self.ferramenta:
            self.canvas.unsetMapTool(self.ferramenta)
            self.ferramenta = None
        if self.ferramenta_anterior:
            self.canvas.setMapTool(self.ferramenta_anterior)
            self.ferramenta_anterior = None

    # ==================================================================
    # Estado
    # ==================================================================

    def _atualizar_estado(self):
        ok = bool(self.base) and any(p["ativo"] for p in self.pontos) \
            and bool(self.frota)
        self.btn_calc.setEnabled(ok)
        if not self.base:
            self.btn_calc.setText("🚛   Marque onde o caminhão enche")
        elif not any(p["ativo"] for p in self.pontos):
            self.btn_calc.setText("🚛   Marque onde entregar")
        else:
            self.btn_calc.setText("🚛   MONTAR A ROTA")

    # ==================================================================
    # Calculo
    # ==================================================================

    def _checar_cobertura(self, via, pontos_xy) -> bool:
        """
        Confere se ha estrada perto de cada ponto.

        NAO usar extent(): o extent de uma camada de linhas e a caixa das
        LINHAS, nao da area baixada. Uma base 300 m ao norte da estrada mais
        setentrional cai fora do extent — e roteia perfeitamente. Comparar
        ponto com extent gera falso alarme justamente no caso normal (o ponto
        fica na ponta de um acesso que o OSM nao mapeou).

        A pergunta certa e: existe estrada a uma distancia razoavel?
        """
        from qgis.core import (
            QgsCoordinateReferenceSystem, QgsCoordinateTransform,
            QgsDistanceArea, QgsGeometry, QgsPointXY, QgsProject,
            QgsRectangle, QgsSpatialIndex,
        )
        if via is None:
            return True

        if via.featureCount() == 0:
            QMessageBox.warning(
                self, "PipaRouter",
                "A camada de estradas está vazia.\n\n"
                "Use o botão '⬇ Ao redor dos meus pontos'.")
            return False

        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        tr = None
        if via.crs() != wgs:
            tr = QgsCoordinateTransform(wgs, via.crs(),
                                        QgsProject.instance())

        da = QgsDistanceArea()
        da.setEllipsoid("WGS84")
        da.setSourceCrs(via.crs(), QgsProject.instance().transformContext())

        idx = QgsSpatialIndex(via.getFeatures())

        # Acima disto, o ponto provavelmente esta fora da area baixada.
        # Abaixo, e so um acesso nao mapeado — normal, e roteavel.
        LIMITE_M = 3000.0

        longe = []
        for i, (x, y) in enumerate(pontos_xy):
            p = QgsPointXY(x, y)
            if tr:
                try:
                    p = tr.transform(p)
                except Exception:
                    continue
            gp = QgsGeometry.fromPointXY(p)

            d_min = float("inf")
            try:
                viz = idx.nearestNeighbor(p, 5)
            except Exception:
                viz = []
            for fid in viz:
                ft = via.getFeature(fid)
                g = ft.geometry()
                if g.isEmpty():
                    continue
                try:
                    d = da.measureLine(p, g.closestSegmentWithContext(p)[1])
                except Exception:
                    d = g.distance(gp) * 111000  # aproximacao grosseira
                if d < d_min:
                    d_min = d

            if d_min > LIMITE_M:
                nome = ("o ponto de carregamento" if i == 0
                        else f"o local {i}")
                longe.append((nome, d_min))

        if not longe:
            return True

        det = "\n".join(f"  • {n}: estrada mais próxima a {d/1000:.1f} km"
                        for n, d in longe)
        cx = QMessageBox(self)
        cx.setIcon(QMessageBox.Warning)
        cx.setWindowTitle("PipaRouter")
        cx.setText(
            f"Não achei estrada perto de "
            f"{'1 ponto' if len(longe)==1 else str(len(longe))+' pontos'}:\n\n"
            f"{det}\n\n"
            f"A área de estradas baixada não cobre esse(s) ponto(s). "
            f"A rota sairia reta ali.\n\n"
            f"Posso baixar agora a área que falta — cobrindo todos os "
            f"pontos marcados.")
        b_baixa = cx.addButton("Baixar a área que falta",
                               QMessageBox.AcceptRole)
        b_segue = cx.addButton("Calcular assim mesmo", QMessageBox.DestructiveRole)
        cx.addButton("Cancelar", QMessageBox.RejectRole)
        cx.setDefaultButton(b_baixa)
        cx.exec_()

        if cx.clickedButton() is b_baixa:
            # Baixa cobrindo TODOS os pontos, nao so os que faltam: se o
            # ponto novo fica a 53 km, a area velha e a nova nao se tocam, e
            # duas camadas soltas nao roteiam entre si.
            self._baixar_estradas("pontos")
            nova = self.cb_via.currentData() if self.cb_via.count() else None
            if nova is None:
                return False
            self._via_recem_baixada = nova
            return True

        return cx.clickedButton() is b_segue

    def calcular(self):
        ativos = [p for p in self.pontos if p["ativo"]]
        if not ativos or not self.base:
            return

        demandas = [Demanda(id=p["id"], nome=p["nome"], x=p["x"], y=p["y"],
                            volume=p["volume"], prioridade=p["prio"])
                    for p in ativos]

        params = ParametrosOperacionais(
            velocidade_media=self.sp_vel.value(),
            fator_nao_pavimentado=self.sp_terra.value(),
            tempo_fixo_parada=self.sp_fixo.value(),
            fator_sinuosidade=self.sp_sinuos.value(),
            volume_min_parcial=3.0,
        )

        pontos_xy = [(self.base.x, self.base.y)] + [(d.x, d.y) for d in demandas]
        idx = {("base", 1): 0}
        for k, d in enumerate(demandas, 1):
            idx[("dem", d.id)] = k
        self._idx = idx

        motor = (self.cb_motor.currentData()
                 if hasattr(self, "cb_motor") else "reta")
        via = self.cb_via.currentData() if self.cb_via.count() else None

        # Modo camada sem camada = reta garantida. Em vez de entregar uma
        # linha inutil e avisar depois, oferecemos resolver agora: o plugin
        # sabe onde ficam os pontos e sabe baixar a area.
        if motor == "camada" and via is None:
            r = QMessageBox.question(
                self, "PipaRouter",
                "Você ainda não tem as estradas desta região.\n\n"
                "Sem elas a rota sai em linha reta — não serve para o "
                "motorista.\n\n"
                "Quer que eu baixe agora? (precisa de internet só desta vez; "
                "depois fica salvo)",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
            if r == QMessageBox.Yes:
                self._baixar_estradas("pontos")
                via = (self.cb_via.currentData()
                       if self.cb_via.count() else None)
                if via is None:
                    return
            else:
                return

        if motor == "camada":
            self._via_recem_baixada = None
            if not self._checar_cobertura(via, pontos_xy):
                return
            # O checar pode ter baixado uma camada nova. Sem reler, o
            # calculo seguiria com a camada velha — que e justamente a que
            # nao cobre os pontos.
            if self._via_recem_baixada is not None:
                via = self._via_recem_baixada

        self.barra.setVisible(True)
        self.btn_calc.setEnabled(False)
        self.btn_calc.setText("Calculando...")
        from qgis.PyQt.QtWidgets import QApplication
        QApplication.processEvents()

        try:
            if motor == "osrm":
                # Rota por servidor OSRM: e o mesmo motor de um GPS.
                from ..core.osrm import (
                    ClienteOSRM, FonteOSRM, ErroOSRM, SERVIDORES,
                )
                url = self._url_servidor()
                try:
                    self.fonte = FonteOSRM(
                        ClienteOSRM(url), pontos_xy,
                        callback=lambda p: self._prog(int(p * .5)))
                except ErroOSRM as e:
                    # Nao adianta so reportar: o usuario quer a rota, nao um
                    # diagnostico. Se o local nao respondeu, testamos o
                    # publico e oferecemos — um clique em vez de um manual.
                    publico = SERVIDORES[0][1]
                    local = "127.0.0.1" in url or "localhost" in url

                    if local:
                        self.btn_calc.setText("Tentando servidor público...")
                        QApplication.processEvents()
                        ok_pub, _ = ClienteOSRM(publico).testar()

                        if ok_pub:
                            r = QMessageBox.question(
                                self, "PipaRouter",
                                "O servidor no seu computador não está "
                                "rodando.\n\n"
                                "Mas o servidor público da OpenStreetMap "
                                "respondeu.\n\n"
                                "Quer calcular a rota com ele agora?\n"
                                "(precisa de internet, mas não precisa "
                                "instalar nada)",
                                QMessageBox.Yes | QMessageBox.No,
                                QMessageBox.Yes)
                            if r == QMessageBox.Yes:
                                i_pub = self.cb_srv.findData(publico)
                                if i_pub >= 0:
                                    self.cb_srv.setCurrentIndex(i_pub)
                                self.fonte = FonteOSRM(
                                    ClienteOSRM(publico), pontos_xy,
                                    callback=lambda p: self._prog(int(p * .5)))
                            else:
                                return
                        else:
                            self._erro_sem_servidor(e, local=True)
                            return
                    else:
                        self._erro_sem_servidor(e, local=False)
                        return

            elif motor == "camada" and via is not None:
                from ..core.roteador import Roteador
                from ..core.fontes import FonteEstrada
                rot = Roteador(
                    via,
                    campo_classe=self.cb_classe.currentData(),
                    campo_piso=self.cb_piso.currentData(),
                    tabela_velocidade=self.tabela_vel,
                    fator_terra=self.sp_terra.value(),
                    velocidade_fallback=self.sp_vel.value(),
                    fator_sinuosidade=self.sp_sinuos.value(),
                )
                rot.preparar(pontos_xy)
                self.fonte = FonteEstrada(
                    rot, callback=lambda p: self._prog(int(p * .5)))
            else:
                from ..core.fontes import FonteEstimada
                m = MatrizDistancia(
                    pontos_xy, fator_sinuosidade=params.fator_sinuosidade,
                    callback_progresso=lambda p: self._prog(int(p * .5)),
                ).construir()
                self.fonte = FonteEstimada(m, params)

            s = SolverPipa([self.base], demandas, self.frota, params,
                           self.fonte, idx,
                           callback_progresso=lambda p: self._prog(
                               50 + int(p * .5)))
            self.solucao = s.resolver()
            self.kpi = indicadores(self.solucao, demandas, self.frota, params)
            self._mostrar_resultado()

        except Exception as e:
            import traceback
            traceback.print_exc()
            QMessageBox.critical(
                self, "PipaRouter", f"Não deu para calcular:\n\n{e}")
        finally:
            self.barra.setVisible(False)
            self._atualizar_estado()

    def _erro_sem_servidor(self, e, local: bool):
        """
        Mensagem de erro em portugues de gente.

        O usuario nao precisa ver 'HTTPConnectionPool(host=...): Max retries
        exceeded'. Ele precisa saber o que fazer agora.
        """
        if local:
            txt = (
                "O servidor de rotas do seu computador não está rodando, "
                "e o servidor público também não respondeu.\n\n"
                "Você tem duas saídas agora:\n\n"
                "1) Sem internet? Em 'Como calcular a rota', escolha\n"
                "   'Camada de estradas do QGIS'. Funciona offline,\n"
                "   usando o OSM que você baixar com o QuickOSM.\n\n"
                "2) Com internet? Em 'Servidor', escolha\n"
                "   'OSM público'. Não precisa instalar nada.\n\n"
                "Para rodar o servidor no seu computador (offline, sem\n"
                "limite), veja as instruções no README do plugin."
            )
        else:
            txt = (
                "Não consegui falar com o servidor público de rotas.\n\n"
                "Provavelmente é falta de internet.\n\n"
                "Em 'Como calcular a rota', escolha 'Camada de estradas\n"
                "do QGIS' — funciona offline, usando o OSM que você\n"
                "baixar com o QuickOSM."
            )
        cx = QMessageBox(self)
        cx.setIcon(QMessageBox.Warning)
        cx.setWindowTitle("PipaRouter")
        cx.setText(txt)
        cx.setDetailedText(f"Detalhe técnico:\n{e}")

        # Se ha camada de linha no projeto, oferece trocar de modo em 1 clique
        tem_camada = self.cb_via.count() > 1
        if tem_camada:
            b_troca = cx.addButton("Usar a camada de estradas",
                                   QMessageBox.AcceptRole)
        cx.addButton("Fechar", QMessageBox.RejectRole)
        cx.exec_()

        if tem_camada and cx.clickedButton() is b_troca:
            i = self.cb_motor.findData("camada")
            if i >= 0:
                self.cb_motor.setCurrentIndex(i)
                self._motor_mudou()
            if self.cb_via.currentIndex() == 0 and self.cb_via.count() > 1:
                self.cb_via.setCurrentIndex(1)
            self.iface.messageBar().pushInfo(
                "PipaRouter",
                "Modo trocado para 'Camada de estradas do QGIS'. "
                "Aperte MONTAR A ROTA de novo.")

    def _prog(self, v):
        self.barra.setValue(v)
        from qgis.PyQt.QtWidgets import QApplication
        QApplication.processEvents()

    def _mostrar_resultado(self):
        h0 = self.sp_hora.value()
        sol, kpi = self.solucao, self.kpi

        # Marcadores por status
        atendidos = {p.demanda_id for r in sol.rotas
                     for v in r.viagens for p in v.paradas}
        # Um ponto pode estar "na rota" mas receber menos do que pediu.
        # Contar essa familia como atendida seria mentira: ela vai receber
        # meia caixa d'agua. Separamos os dois casos.
        entregue_por_ponto = {}
        for r in sol.rotas:
            for v in r.viagens:
                for p in v.paradas:
                    entregue_por_ponto[p.demanda_id] = \
                        entregue_por_ponto.get(p.demanda_id, 0) + p.volume_entregue

        completos, parciais = set(), set()
        for p in self.pontos:
            if not p["ativo"]:
                continue
            ent = entregue_por_ponto.get(p["id"], 0)
            if ent >= p["volume"] - 1e-6:
                completos.add(p["id"])
            elif ent > 0:
                parciais.add(p["id"])

        for p in self.pontos:
            if not p["ativo"]:
                continue
            self.marcadores.marcar_ponto(
                p["id"], p["x"], p["y"], p["prio"],
                atendido=(p["id"] in atendidos))

        # Rotas no canvas
        self.marcadores.limpar_rotas()
        for ri, r in enumerate(sol.rotas):
            for v in r.viagens:
                coords = exportador._coords_trajeto(
                    self.fonte, self._idx, self.base, v.paradas)
                self.marcadores.desenhar_rota(ri, coords)
        self.canvas.refresh()

        # Resumo honesto: separa quem recebe tudo, quem recebe parte,
        # e quem nao recebe nada.
        pes_ok = sum(p["pessoas"] for p in self.pontos
                     if p["ativo"] and p["id"] in completos)
        pes_parc = sum(p["pessoas"] for p in self.pontos
                       if p["ativo"] and p["id"] in parciais)
        pes_fora = sum(p["pessoas"] for p in self.pontos
                       if p["ativo"] and p["id"] not in atendidos)
        n_fora = len([p for p in self.pontos
                      if p["ativo"] and p["id"] not in atendidos])

        if not parciais and not n_fora:
            cor, icone = "#2E7D32", "✓"
            msg = "Todos os lugares recebem tudo o que pediram."
        elif not n_fora:
            cor, icone = "#F57C00", "!"
            msg = (f"Todos os lugares serão visitados, mas "
                   f"<b>{len(parciais)}</b> recebem menos do que pediram.")
        else:
            cor, icone = "#C62828", "⚠"
            msg = f"<b>{n_fora} lugares não recebem água nenhuma.</b>"

        linhas = []
        if pes_ok:
            linhas.append(f"~<b>{pes_ok}</b> pessoas recebem o pedido completo.")
        if pes_parc:
            linhas.append(f"<span style='color:#E65100;'>~<b>{pes_parc}</b> "
                          f"pessoas recebem só parte.</span>")
        if pes_fora:
            linhas.append(f"<span style='color:#C62828;'>~<b>{pes_fora}</b> "
                          f"pessoas ficam sem nada.</span>")
        extra = "<br>" + "<br>".join(linhas) if linhas else ""

        # Faixa de alerta quando o tracado nao seguiu as estradas.
        # Fica ACIMA do resumo de atendimento: de nada adianta saber que
        # 100% recebe agua se a linha entregue ao motorista atravessa cerca.
        alerta = ""
        r2 = self.fonte.resumo() if self.fonte else {}
        if r2.get("fonte") == "osrm":
            ap = r2.get("trechos_aproximados", 0)
            if ap:
                alerta = (
                    "<div style='background:#FFF8E1;border-left:4px solid "
                    "#F57C00;padding:8px;margin-bottom:6px;'>"
                    f"<span style='font-size:11px;color:#5D4037;'>{ap} "
                    f"trecho(s) sem rota no servidor — nesses o caminho é "
                    f"reto.</span></div>")
        elif r2.get("fonte") != "estrada":
            alerta = (
                "<div style='background:#FFEBEE;border-left:4px solid #C62828;"
                "padding:8px;margin-bottom:6px;'>"
                "<b style='color:#C62828;'>⚠ A linha no mapa é reta.</b><br>"
                "<span style='font-size:11px;color:#555;'>Sem camada de "
                "estradas o traçado não serve para o motorista. Abra "
                "<b>Ajustes avançados</b> e informe as estradas.</span></div>")
        else:
            ap = r2.get("trechos_aproximados", 0)
            tt = r2.get("trechos_totais", 0)
            if ap and tt and ap >= tt * 0.5:
                alerta = (
                    "<div style='background:#FFEBEE;border-left:4px solid "
                    "#C62828;padding:8px;margin-bottom:6px;'>"
                    "<b style='color:#C62828;'>⚠ A rota não seguiu as "
                    "estradas.</b><br>"
                    f"<span style='font-size:11px;color:#555;'>{ap} de {tt} "
                    "trechos saíram retos. Veja o detalhe abaixo — "
                    "normalmente a camada não cobre a área toda.</span></div>")
            elif ap:
                alerta = (
                    "<div style='background:#FFF8E1;border-left:4px solid "
                    "#F57C00;padding:8px;margin-bottom:6px;'>"
                    f"<span style='font-size:11px;color:#5D4037;'>{ap} de "
                    f"{tt} trechos sem estrada mapeada — nesses o caminho "
                    f"é reto.</span></div>")

        self.lbl_resumo.setText(
            alerta +
            f"<div style='background:{cor}15;border-left:4px solid {cor};"
            f"padding:8px;'>"
            f"<span style='color:{cor};font-size:14px;'>{icone}</span> "
            f"<b style='color:{cor};'>{msg}</b>{extra}<br><br>"
            f"<span style='color:#555;'>"
            f"{kpi['caminhoes_usados']} caminhão(ões) · "
            f"{kpi['viagens_totais']} viagens · "
            f"{kpi['distancia_total_km']:.0f} km · "
            f"{kpi['volume_entregue_m3']:.1f} de "
            f"{kpi['volume_solicitado_m3']:.1f} m³ pedidos</span></div>")

        # Aviso de precisao — o usuario tem que saber o quanto confiar
        L = []
        res = self.fonte.resumo() if self.fonte else {}
        if res.get("fonte") == "osrm":
            apx = res.get("trechos_aproximados", 0)
            tot = res.get("trechos_totais", 0)
            if apx:
                L.append(f"! {apx} de {tot} trechos sem rota no servidor — "
                         f"nesses o caminho sai reto.")
            else:
                L.append("Rota calculada pelo servidor, seguindo as estradas.")
            L.append(f"  ({res.get('servidor','')})")
            L.append("")
            for a in res.get("avisos", [])[:2]:
                L.append(f"! {a}")
                L.append("")
        elif res.get("fonte") == "estrada":
            apx = res.get("trechos_aproximados", 0)
            tot = res.get("trechos_totais", 0)
            pct_geo = res.get("pct_geometria_real", 0)

            if apx and tot and apx >= tot * 0.5:
                # Metade ou mais em reta: o roteamento nao esta funcionando.
                # Isso e um problema, nao um detalhe — avisa em vermelho.
                L.append("!" * 46)
                L.append("A ROTA NAO ESTA SEGUINDO AS ESTRADAS")
                L.append("!" * 46)
                L.append(self.fonte.diagnostico()
                         if hasattr(self.fonte, "diagnostico") else "")
                L.append("")
                L.append("O que costuma resolver:")
                L.append("  · a camada nao cobre a area toda — baixe o OSM")
                L.append("    de novo com um retangulo maior que os pontos")
                L.append("  · o QuickOSM trouxe so um tipo de via — use a")
                L.append("    chave 'highway' SEM valor, para vir tudo")
                L.append("  · a camada e de outro municipio")
                L.append("")
            elif apx:
                L.append(f"! {apx} de {tot} trechos sem estrada mapeada — "
                         f"nesses o caminho e reto.")
                L.append("")
            else:
                extra = (f" Curvas recuperadas em {pct_geo:.0f}% dos trechos."
                         if pct_geo else "")
                L.append(f"Rota pelas estradas.{extra}")
                L.append("")

            ac = res.get("acessos_longos", {})
            if ac:
                L.append(f"! {len(ac)} local(is) sem acesso mapeado: a rota "
                         f"chega pela estrada, o ultimo trecho e reto.")
                L.append("")
            for a in res.get("avisos", [])[:2]:
                L.append(f"! {a}")
            if res.get("avisos"):
                L.append("")
        else:
            L.append("!" * 46)
            L.append("TEMPO E ROTA ESTIMADOS — sem camada de estradas.")
            L.append("A linha no mapa e reta, nao serve para o motorista.")
            L.append("Abra 'Ajustes avancados' e informe as estradas.")
            L.append("!" * 46)
            L.append("")

        # Detalhe das rotas
        for r in sol.rotas:
            L.append("─" * 46)
            L.append(f"{r.placa}   {r.distancia_total:.0f} km   "
                     f"{r.tempo_total/60:.1f}h")
            for vi, v in enumerate(r.viagens, 1):
                L.append(f"  Viagem {vi} — enche {v.volume_carregado:.1f} m³ "
                         f"em {v.tempo_enchimento:.0f} min, "
                         f"sai {exportador._hms(v.partida_base, h0)}")
                t_ant = v.partida_base
                for oi, p in enumerate(v.paradas, 1):
                    desloc = p.chegada - t_ant
                    vef = (p.dist_desde_anterior / (desloc / 60.0)
                           if desloc > 0.01 else 0)
                    L.append(f"     ↓ {desloc:4.0f} min de estrada "
                             f"({p.dist_desde_anterior:.1f} km, "
                             f"{vef:.0f} km/h)")
                    fl = " (parte do pedido)" if p.parcial else ""
                    L.append(f"    {oi}. {exportador._hms(p.chegada, h0)}  "
                             f"{p.nome[:20]:20s} {p.volume_entregue:5.1f} m³{fl}")
                    t_atend = p.saida - p.inicio_servico
                    L.append(f"       fica {t_atend:.0f} min, "
                             f"sai {exportador._hms(p.saida, h0)}")
                    t_ant = p.saida
                volta = v.retorno_base - t_ant
                L.append(f"     ↓ {volta:4.0f} min de volta")
                L.append(f"     chega na base {exportador._hms(v.retorno_base, h0)}")

                # Instrucoes de navegacao — o que o motorista le
                if hasattr(self.fonte, "roteiro_viagem") and self._idx:
                    try:
                        seq = [self._idx[("base", self.base.id)]]
                        seq += [self._idx[("dem", p.demanda_id)]
                                for p in v.paradas]
                        seq.append(self._idx[("base", self.base.id)])
                        nomes = [p.nome for p in v.paradas] + ["a base"]
                        rot = self.fonte.roteiro_viagem(seq, nomes)
                        if rot:
                            L.append("")
                            L.append("     POR ONDE PASSAR:")
                            for ln in rot:
                                L.append(f"     {ln}")
                    except Exception:
                        pass
            L.append("")

        # Piso: so aparece quando temos a informacao real da malha.
        # O OSRM nao devolve piso, entao o bloco simplesmente nao aparece —
        # melhor omitir que inventar.
        if res.get("fonte") == "estrada" and self.fonte:
            kp = kt = 0.0
            for r in sol.rotas:
                for v in r.viagens:
                    ant = ("base", self.base.id)
                    for p in v.paradas:
                        try:
                            a = self._idx[ant]
                            b = self._idx[("dem", p.demanda_id)]
                            kp += self.fonte.km_pav(a, b)
                            kt += self.fonte.km_terra(a, b)
                        except Exception:
                            pass
                        ant = ("dem", p.demanda_id)
            if kp + kt > 0.1:
                L.append("─" * 46)
                L.append("TIPO DE ESTRADA:")
                L.append(f"  asfalto ............. {kp:5.1f} km")
                L.append(f"  terra ............... {kt:5.1f} km "
                         f"({100*kt/(kp+kt):.0f}% do percurso)")
                L.append("")

        # Tempo: onde a jornada foi gasta
        L.append("─" * 46)
        L.append("ONDE O TEMPO FOI:")
        L.append(f"  na estrada .......... {kpi['tempo_dirigindo_h']:5.1f} h")
        L.append(f"  enchendo na base .... {kpi['tempo_enchimento_h']:5.1f} h")
        L.append(f"  atendendo ........... {kpi['tempo_atendimento_h']:5.1f} h")
        if kpi["tempo_espera_h"] > 0.05:
            L.append(f"  esperando ........... {kpi['tempo_espera_h']:5.1f} h")
        L.append("")

        if sol.nao_atendidas:
            L.append("═" * 46)
            nada = [(n, f) for i, n, f, _ in sol.nao_atendidas
                    if i not in atendidos]
            parc = [(n, f) for i, n, f, _ in sol.nao_atendidas
                    if i in atendidos]
            if nada:
                L.append("NÃO RECEBEM NADA:")
                for n, f in nada:
                    L.append(f"  • {n} — precisa de {f:.1f} m³")
                L.append("")
            if parc:
                L.append("RECEBEM SÓ PARTE:")
                for n, f in parc:
                    L.append(f"  • {n} — ainda faltam {f:.1f} m³")
                L.append("")
            L.append("O que fazer:")
            L.append("  · adicionar mais um caminhão (passo 2)")
            L.append("  · aumentar a jornada")
            L.append("  · tirar lugares menos urgentes da rota")
            L.append("  · marcar os que ficaram como Crítico e recalcular")

        self.txt_rotas.setPlainText("\n".join(L))
        # Botao de socorro so aparece quando ha reta na rota
        r3 = self.fonte.resumo() if self.fonte else {}
        tem_reta = (r3.get("fonte") != "estrada"
                    or r3.get("trechos_aproximados", 0) > 0)
        self.btn_pq_reta.setVisible(bool(tem_reta))
        self.box_res.setVisible(True)

    # ==================================================================
    # Exportacao
    # ==================================================================

    def _add_camadas(self):
        lr, lp = exportador.camadas_qgis(
            self.solucao, [self.base], hora_inicio=self.sp_hora.value(),
            fonte=self.fonte, idx=self._idx)
        if lr is None:
            return
        QgsProject.instance().addMapLayers([lr, lp])
        self.iface.messageBar().pushSuccess(
            "PipaRouter", "Camadas adicionadas.")

    def _exp_kmz(self):
        f, _ = QFileDialog.getSaveFileName(
            self, "Salvar para o celular do motorista",
            "rota_pipa.kmz", "KMZ (*.kmz)")
        if not f:
            return
        dem = [Demanda(p["id"], p["nome"], p["x"], p["y"], p["volume"],
                       p["prio"]) for p in self.pontos if p["ativo"]]
        exportador.salvar_kmz(self.solucao, [self.base], dem, f,
                              self.sp_hora.value(), self.fonte, self._idx)
        QMessageBox.information(
            self, "PipaRouter",
            f"Salvo em:\n{f}\n\nEnvie para o celular do motorista. "
            f"Abre no Google Earth ou Maps.me.")

    def _exp_xls(self):
        f, _ = QFileDialog.getSaveFileName(
            self, "Salvar planilha", "programacao_pipa.xlsx",
            "Excel (*.xlsx);;CSV (*.csv)")
        if not f:
            return
        if f.lower().endswith(".csv"):
            exportador.salvar_csv(self.solucao, f, self.sp_hora.value())
        else:
            if exportador.salvar_xlsx(
                    self.solucao, self.kpi, f, self.sp_hora.value(),
                    self.fonte, self._idx, [self.base]) is None:
                f = f[:-5] + ".csv"
                exportador.salvar_csv(self.solucao, f, self.sp_hora.value())
        self.iface.messageBar().pushSuccess("PipaRouter", f"Salvo: {f}")

    # ==================================================================

    def closeEvent(self, e):
        self._desativar_ferramenta()
        self.marcadores.limpar_tudo()
        self.canvas.refresh()
        super().closeEvent(e)


# ======================================================================
# Dialogos auxiliares
# ======================================================================

class DialogoCaminhao(QWidget):
    """Cadastro/edicao de caminhao, em linguagem de campo."""

    def __init__(self, n, cam=None, parent=None):
        from qgis.PyQt.QtWidgets import QDialog, QDialogButtonBox, QLineEdit
        self._d = QDialog(parent)
        self._d.setWindowTitle("Caminhão")
        self._d.setMinimumWidth(400)

        v = QVBoxLayout(self._d)
        cab = QLabel("Dados do caminhão")
        cab.setStyleSheet(
            f"font-size:15px;font-weight:bold;color:{AZUL};padding:4px 0;")
        v.addWidget(cab)

        f = QFormLayout()
        f.setSpacing(10)
        self.ed_nome = QLineEdit(cam.placa if cam else f"Caminhão {n}")
        self.ed_nome.setPlaceholderText("Placa ou apelido")

        self.sp_cap = QDoubleSpinBox()
        self.sp_cap.setRange(1, 60)
        self.sp_cap.setValue(cam.capacidade if cam else 10)
        self.sp_cap.setSuffix(" m³")
        self.sp_cap.setToolTip("Quanto o tanque carrega cheio.")

        self.sp_vaz = QDoubleSpinBox()
        self.sp_vaz.setRange(1, 200)
        self.sp_vaz.setValue(cam.vazao_descarga if cam else 30)
        self.sp_vaz.setSuffix(" m³/h")

        self.sp_jor = QDoubleSpinBox()
        self.sp_jor.setRange(1, 16)
        self.sp_jor.setValue(cam.jornada_max/60 if cam else 8)
        self.sp_jor.setSuffix(" h")

        self.sp_custo = QDoubleSpinBox()
        self.sp_custo.setRange(0, 100)
        self.sp_custo.setValue(cam.custo_km if cam else 0)
        self.sp_custo.setPrefix("R$ ")
        self.sp_custo.setSuffix(" /km")

        f.addRow("Nome:", self.ed_nome)
        f.addRow("Quanto carrega:", self.sp_cap)
        f.addRow("Velocidade de descarga:", self.sp_vaz)
        f.addRow("Jornada:", self.sp_jor)
        f.addRow("Custo (opcional):", self.sp_custo)
        v.addLayout(f)

        self.lbl = QLabel()
        self.lbl.setStyleSheet(
            "background:#E3F2FD;border-left:3px solid #0026BD;"
            "padding:8px;font-size:11px;")
        self.lbl.setWordWrap(True)
        v.addWidget(self.lbl)
        for w in (self.sp_cap, self.sp_vaz):
            w.valueChanged.connect(self._att)
        self._att()

        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("Salvar")
        bb.button(QDialogButtonBox.Ok).setStyleSheet(
            f"background:{AZUL};color:white;font-weight:bold;padding:7px 18px;")
        bb.button(QDialogButtonBox.Cancel).setText("Cancelar")
        bb.accepted.connect(self._d.accept)
        bb.rejected.connect(self._d.reject)
        v.addWidget(bb)

    def _att(self):
        cap, vaz = self.sp_cap.value(), self.sp_vaz.value()
        t = (cap / vaz) * 60
        self.lbl.setText(
            f"Descarregar o tanque cheio ({cap:g} m³) leva "
            f"<b>{t:.0f} minutos</b>.<br>"
            f"<span style='color:#555;'>Se estiver muito diferente do real, "
            f"o horário de cada entrega vai sair errado. Cronometre uma "
            f"descarga para conferir.</span>")

    def exec_(self):
        return self._d.exec_()

    def nome(self):
        return self.ed_nome.text().strip() or "Caminhão"

    def capacidade(self):
        return self.sp_cap.value()

    def vazao(self):
        return self.sp_vaz.value()

    def jornada(self):
        return self.sp_jor.value()

    def custo(self):
        return self.sp_custo.value()


class DialogoImportar(QWidget):
    """Importa pontos de uma camada existente."""

    def __init__(self, parent=None):
        from qgis.core import QgsWkbTypes
        from qgis.PyQt.QtWidgets import QDialog, QDialogButtonBox
        self._d = QDialog(parent)
        self._d.setWindowTitle("Importar lugares de uma camada")
        self._d.setMinimumWidth(430)
        self._res = []

        v = QVBoxLayout(self._d)
        cab = QLabel("Trazer lugares de uma camada do mapa")
        cab.setStyleSheet(
            f"font-size:14px;font-weight:bold;color:{AZUL};padding:4px 0;")
        v.addWidget(cab)

        f = QFormLayout()
        self.cb_lyr = QComboBox()
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                if (lyr.type() == lyr.VectorLayer
                        and lyr.geometryType() == QgsWkbTypes.PointGeometry):
                    self.cb_lyr.addItem(lyr.name(), lyr)
            except Exception:
                pass
        self.cb_nome = QComboBox()
        self.cb_vol = QComboBox()
        self.cb_lyr.currentIndexChanged.connect(self._campos)
        self.chk_sel = QCheckBox("Só os que estão selecionados")

        f.addRow("Camada:", self.cb_lyr)
        f.addRow("Nome do lugar:", self.cb_nome)
        f.addRow("Volume (m³):", self.cb_vol)
        f.addRow("", self.chk_sel)
        v.addLayout(f)

        d = QLabel("Se a camada não tiver o volume, todos entram com 10 m³ e "
                   "você ajusta depois.")
        d.setWordWrap(True)
        d.setStyleSheet("color:#666;font-size:11px;")
        v.addWidget(d)

        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("Importar")
        bb.accepted.connect(self._importar)
        bb.rejected.connect(self._d.reject)
        v.addWidget(bb)
        self._campos()

    def _campos(self):
        lyr = self.cb_lyr.currentData()
        self.cb_nome.clear()
        self.cb_vol.clear()
        self.cb_nome.addItem("— usar numeração —", None)
        self.cb_vol.addItem("— 10 m³ para todos —", None)
        if not lyr:
            return
        for fld in lyr.fields():
            self.cb_nome.addItem(fld.name(), fld.name())
            self.cb_vol.addItem(fld.name(), fld.name())

    def _importar(self):
        lyr = self.cb_lyr.currentData()
        if not lyr:
            self._d.reject()
            return
        from qgis.core import (
            QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject,
        )
        tr = None
        if lyr.crs() != QgsCoordinateReferenceSystem("EPSG:4326"):
            tr = QgsCoordinateTransform(
                lyr.crs(), QgsCoordinateReferenceSystem("EPSG:4326"),
                QgsProject.instance())

        fn = self.cb_nome.currentData()
        fv = self.cb_vol.currentData()
        feats = (lyr.selectedFeatures() if self.chk_sel.isChecked()
                 else lyr.getFeatures())

        for i, ft in enumerate(feats, 1):
            g = ft.geometry()
            if g.isEmpty():
                continue
            p = g.asPoint()
            if tr:
                p = tr.transform(p)
            try:
                vol = float(ft[fv]) if fv else 10.0
                if vol <= 0:
                    vol = 10.0
            except (TypeError, ValueError, KeyError):
                vol = 10.0
            try:
                nome = str(ft[fn]) if fn else f"Lugar {i}"
            except KeyError:
                nome = f"Lugar {i}"
            self._res.append({
                "nome": nome, "x": p.x(), "y": p.y(),
                "volume": round(vol, 2), "prio": 1,
                "pessoas": int((vol * 1000) / (40 * 7)),
            })
        self._d.accept()

    def exec_(self):
        return self._d.exec_()

    def resultado(self):
        return self._res


class DialogoVelocidades:
    """
    Tabela de velocidade por tipo de via, editavel.

    Existe porque os defaults sao chute informado, nao medida. Quem roda a
    operacao sabe que a vicinal para tal povoado nao faz 45 km/h com o pipa
    cheio. Esta tela deixa corrigir.
    """

    ROTULOS = {
        "motorway":      "Rodovia duplicada",
        "trunk":         "Rodovia principal",
        "primary":       "BR / estadual asfaltada",
        "secondary":     "Estadual secundária",
        "tertiary":      "Vicinal principal",
        "unclassified":  "Vicinal sem classificação",
        "residential":   "Rua de povoado",
        "living_street": "Rua estreita / vila",
        "service":       "Acesso / servidão",
        "track":         "Carroçável",
        "path":          "Trilha",
        "road":          "Sem informação",
    }

    def __init__(self, tabela, parent=None):
        from qgis.PyQt.QtWidgets import (
            QDialog, QDialogButtonBox, QTableWidget, QTableWidgetItem,
        )
        self._d = QDialog(parent)
        self._d.setWindowTitle("Velocidade por tipo de via")
        self._d.setMinimumWidth(430)
        self._d.setMinimumHeight(480)

        v = QVBoxLayout(self._d)
        cab = QLabel("Quanto o caminhão CARREGADO anda em cada tipo de via")
        cab.setStyleSheet(
            f"font-size:14px;font-weight:bold;color:{AZUL};padding:4px 0;")
        cab.setWordWrap(True)
        v.addWidget(cab)

        aviso = QLabel(
            "Estes valores são uma referência, não uma medição. Se você sabe "
            "que a carroçável para determinado povoado não faz 18 km/h com o "
            "pipa cheio, corrija aqui — o horário de chegada depende disto."
        )
        aviso.setWordWrap(True)
        aviso.setStyleSheet(
            "background:#FFF8E1;border-left:3px solid #F57C00;"
            "padding:8px;font-size:11px;color:#5D4037;")
        v.addWidget(aviso)

        self.tb = QTableWidget(0, 2)
        self.tb.setHorizontalHeaderLabels(["Tipo de via", "km/h"])
        self.tb.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.tb.setColumnWidth(1, 70)
        self._chaves = []
        for k in sorted(tabela, key=lambda k: -tabela[k]):
            if k.endswith("_link"):
                continue
            r = self.tb.rowCount()
            self.tb.insertRow(r)
            it = QTableWidgetItem(self.ROTULOS.get(k, k))
            it.setFlags(Qt.ItemIsEnabled)
            it.setToolTip(f"OSM: highway={k}")
            self.tb.setItem(r, 0, it)
            self.tb.setItem(r, 1, QTableWidgetItem(f"{tabela[k]:g}"))
            self._chaves.append(k)
        v.addWidget(self.tb)

        nota = QLabel(
            "As vias de acesso (_link) acompanham a via principal. "
            "O piso de terra é aplicado depois, pelo 'Fator da terra'.")
        nota.setWordWrap(True)
        nota.setStyleSheet("color:#666;font-size:10px;")
        v.addWidget(nota)

        self._tabela_orig = dict(tabela)
        bb = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
            | QDialogButtonBox.RestoreDefaults)
        bb.button(QDialogButtonBox.Ok).setText("Usar estes valores")
        bb.button(QDialogButtonBox.Cancel).setText("Cancelar")
        bb.button(QDialogButtonBox.RestoreDefaults).setText("Restaurar padrão")
        bb.accepted.connect(self._d.accept)
        bb.rejected.connect(self._d.reject)
        bb.button(QDialogButtonBox.RestoreDefaults).clicked.connect(
            self._restaurar)
        v.addWidget(bb)

    def _restaurar(self):
        from ..core.roteador import VELOCIDADE_PADRAO
        from qgis.PyQt.QtWidgets import QTableWidgetItem
        for r, k in enumerate(self._chaves):
            self.tb.setItem(r, 1, QTableWidgetItem(
                f"{VELOCIDADE_PADRAO.get(k, 30):g}"))

    def exec_(self):
        return self._d.exec_()

    def tabela(self):
        from ..core.roteador import VELOCIDADE_PADRAO
        out = dict(VELOCIDADE_PADRAO)
        for r, k in enumerate(self._chaves):
            it = self.tb.item(r, 1)
            try:
                val = float(it.text().replace(",", "."))
                if val > 0:
                    out[k] = val
            except (ValueError, AttributeError):
                pass
        # Vias de acesso acompanham a principal, a 70%
        for k in list(out):
            lk = k + "_link"
            if lk in VELOCIDADE_PADRAO:
                out[lk] = round(out[k] * 0.7, 1)
        return out
