# -*- coding: utf-8 -*-
#
# PipaRouter — roteirização de caminhões-pipa no QGIS
# Copyright (C) 2025  Antonio A. Coelho Neto
#
# Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
# sob os termos da GNU General Public License versão 2 ou posterior.
# Veja o arquivo LICENSE, ou <https://www.gnu.org/licenses/gpl-2.0.html>.
#
"""
Diagnostico da camada de estradas, dentro do plugin.

Existe porque "a rota saiu reta" e um sintoma com varias causas, e o usuario
nao tem como saber qual. Este teste roda a mesma cadeia do calculo real e
diz onde quebrou, em portugues.
"""

from qgis.core import (
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject,
    QgsWkbTypes,
)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QFont
from qgis.PyQt.QtWidgets import (
    QDialog, QDialogButtonBox, QLabel, QTextEdit, QVBoxLayout,
)

AZUL = "#0026BD"


class DialogoDiagnostico(QDialog):
    """Testa a camada de estradas e reporta."""

    def __init__(self, via, pontos, campo_classe, campo_piso,
                 tabela_vel=None, fator_terra=0.6, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Teste da camada de estradas")
        self.setMinimumSize(620, 540)

        v = QVBoxLayout(self)
        cab = QLabel("Teste da camada de estradas")
        cab.setStyleSheet(
            f"font-size:15px;font-weight:bold;color:{AZUL};padding:4px 0;")
        v.addWidget(cab)

        self.txt = QTextEdit()
        self.txt.setReadOnly(True)
        self.txt.setFont(QFont("Courier New", 9))
        v.addWidget(self.txt)

        bb = QDialogButtonBox(QDialogButtonBox.Close)
        bb.button(QDialogButtonBox.Close).setText("Fechar")
        bb.rejected.connect(self.reject)
        v.addWidget(bb)

        self._rodar(via, pontos, campo_classe, campo_piso, tabela_vel,
                    fator_terra)

    def _rodar(self, via, pontos, campo_classe, campo_piso, tabela_vel,
               fator_terra):
        L = []

        def p(s=""):
            L.append(str(s))

        p("=" * 62)
        p("TESTE DA CAMADA DE ESTRADAS")
        p("=" * 62)

        if via is None:
            p("")
            p("NENHUMA CAMADA SELECIONADA.")
            p("")
            p("Sem camada de estradas a rota sai reta — sempre.")
            p("")
            p("Como resolver:")
            p("  1. Vetor > QuickOSM > Consulta rapida")
            p("  2. Chave: highway   (deixe o VALOR em branco)")
            p("  3. Enquadre o mapa mostrando TODOS os seus pontos")
            p("  4. Executar")
            p("  5. Volte aqui e selecione a camada")
            self.txt.setPlainText("\n".join(L))
            return

        # -------------------------------------------------- 1. A camada
        p("")
        p(f"Camada: {via.name()}")
        p(f"  trechos ..... {via.featureCount()}")
        p(f"  CRS ......... {via.crs().authid()}")

        if via.featureCount() == 0:
            p("")
            p("*** A CAMADA ESTA VAZIA ***")
            p("Baixe de novo com o QuickOSM, chave 'highway' sem valor.")
            self.txt.setPlainText("\n".join(L))
            return

        # -------------------------------------------------- 2. Campos
        p("")
        p(f"  tipo de via . {campo_classe or 'NAO ENCONTRADO'}")
        p(f"  piso ........ {campo_piso or 'nao informado (opcional)'}")

        if not campo_classe:
            p("")
            p("  ! Sem o tipo de via, todas as estradas correm na mesma")
            p("    velocidade. A rota segue as estradas, mas o horario")
            p("    de chegada perde precisao.")
        else:
            vals = {}
            for ft in via.getFeatures():
                try:
                    x = ft[campo_classe]
                except Exception:
                    x = None
                k = str(x).strip().lower() if x else "(vazio)"
                vals[k] = vals.get(k, 0) + 1
            p("")
            p(f"  Tipos encontrados ({len(vals)}):")
            from ..core.roteador import VELOCIDADE_PADRAO
            tab = dict(VELOCIDADE_PADRAO)
            if tabela_vel:
                tab.update(tabela_vel)
            for k, n in sorted(vals.items(), key=lambda t: -t[1])[:12]:
                vel = tab.get(k)
                marca = f"{vel:.0f} km/h" if vel else "nao reconhecido -> 30"
                p(f"    {k:20s} {n:6d}  {marca}")
            nao_rec = [k for k in vals if k not in tab and k != "(vazio)"]
            if nao_rec:
                p("")
                p(f"  ! {len(nao_rec)} tipo(s) nao reconhecido(s): "
                  f"{', '.join(nao_rec[:5])}")
                p("    Esses usam 30 km/h. Se forem importantes, me avise.")

        # -------------------------------------------------- 3. Cobertura
        p("")
        p("-" * 62)
        p("COBERTURA")
        p("-" * 62)

        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        ext = via.extent()
        if via.crs() != wgs:
            try:
                tr = QgsCoordinateTransform(via.crs(), wgs,
                                            QgsProject.instance())
                ext = tr.transformBoundingBox(ext)
            except Exception:
                pass

        fora = [i for i, (x, y) in enumerate(pontos)
                if not ext.contains(x, y)]
        p("")
        if fora:
            p(f"  *** {len(fora)} de {len(pontos)} pontos estao FORA da area")
            p(f"      coberta pela camada. ***")
            p("")
            p("  Esses trechos vao sair retos.")
            p("")
            p("  Como resolver:")
            p("    Baixe o OSM de novo com o mapa enquadrado mostrando")
            p("    TODOS os pontos. O QuickOSM so traz o que esta na tela.")
        else:
            p(f"  Todos os {len(pontos)} pontos estao dentro da area coberta.")

        # -------------------------------------------------- 4. Grafo
        p("")
        p("-" * 62)
        p("REDE DE ESTRADAS")
        p("-" * 62)

        try:
            from ..core.roteador import Roteador
            rot = Roteador(via, campo_classe=campo_classe,
                           campo_piso=campo_piso,
                           tabela_velocidade=tabela_vel,
                           fator_terra=fator_terra)
            rot.preparar(pontos)
            s = rot.resumo()

            p("")
            p(f"  cruzamentos ....... {s.get('nos', 0)}")
            p(f"  trechos ........... {s.get('arestas', 0)}")
            p(f"  CRS de calculo .... {s.get('crs_metrico', '?')}")

            comp = rot.componentes()
            if comp:
                tot = sum(comp)
                p("")
                if len(comp) == 1:
                    p(f"  Rede inteira conectada ({comp[0]} cruzamentos). OK.")
                else:
                    pct = 100.0 * comp[0] / tot
                    p(f"  *** REDE EM {len(comp)} PEDACOS SEPARADOS ***")
                    p(f"      maior pedaco: {comp[0]} de {tot} "
                      f"cruzamentos ({pct:.0f}%)")
                    p(f"      outros: {comp[1:6]}")
                    if pct < 70:
                        p("")
                        p("      A camada esta fragmentada. Trechos entre")
                        p("      pedacos diferentes vao sair retos.")
                        p("      Normalmente falta baixar area maior.")

            # acessos
            fin = [a for a in rot._acesso_m if a != float("inf")]
            if fin:
                p("")
                p(f"  Distancia dos seus pontos ate a estrada:")
                for i, a in enumerate(rot._acesso_m):
                    nome = "carregamento" if i == 0 else f"local {i}"
                    if a == float("inf"):
                        p(f"    {nome:16s} SEM ESTRADA POR PERTO")
                    else:
                        flag = "  <-- longe" if a > 1000 else ""
                        p(f"    {nome:16s} {a:8.0f} m{flag}")

            # -------------------------------------------- 5. Teste real
            p("")
            p("-" * 62)
            p("TESTE DE ROTA")
            p("-" * 62)
            p("")

            n_ok = n_reta = 0
            motivos = {}
            exemplos = []
            for i in range(len(pontos)):
                for j in range(len(pontos)):
                    if i == j:
                        continue
                    t = rot.trecho(i, j)
                    if t.aproximado:
                        n_reta += 1
                        motivos[t.motivo] = motivos.get(t.motivo, 0) + 1
                    else:
                        n_ok += 1
                        if len(exemplos) < 3:
                            exemplos.append((i, j, t))

            tot = n_ok + n_reta
            p(f"  Testados {tot} trechos entre seus pontos:")
            p(f"    seguem a estrada .. {n_ok}")
            p(f"    saem retos ........ {n_reta}")

            if exemplos:
                p("")
                p("  Exemplos de rota pela estrada:")
                for i, j, t in exemplos:
                    ni = "base" if i == 0 else f"local {i}"
                    nj = "base" if j == 0 else f"local {j}"
                    p(f"    {ni} -> {nj}: {t.dist_km:.1f} km, "
                      f"{t.tempo_min:.0f} min, "
                      f"{len(t.geometria)} pontos no tracado")
                    p(f"        {t.km_pav:.1f} km asfalto + "
                      f"{t.km_terra:.1f} km terra, "
                      f"{t.velocidade_efetiva:.0f} km/h efetivos")

            if motivos:
                p("")
                p("  Motivos dos que sairam retos:")
                for m, n in sorted(motivos.items(), key=lambda x: -x[1]):
                    p(f"    {n}x — {m}")

            # ------------------------------------------- 6. Veredito
            p("")
            p("=" * 62)
            if n_reta == 0:
                p("RESULTADO: TUDO CERTO")
                p("A rota vai seguir as estradas.")
            elif n_ok == 0:
                p("RESULTADO: NAO ESTA FUNCIONANDO")
                p("")
                p("Nenhum trecho seguiu a estrada. Provavel causa:")
                if fora:
                    p("  -> os pontos estao fora da area da camada.")
                elif len(comp) > 1:
                    p("  -> a rede de estradas esta partida.")
                else:
                    p("  -> veja os motivos acima.")
            else:
                p(f"RESULTADO: PARCIAL — {n_ok} de {tot} trechos na estrada")
                p("")
                p("Os que saem retos aparecem em vermelho no mapa.")
            p("=" * 62)

        except Exception as e:
            import traceback
            p("")
            p("*** ERRO AO TESTAR ***")
            p(str(e))
            p("")
            p(traceback.format_exc())

        self.txt.setPlainText("\n".join(L))
