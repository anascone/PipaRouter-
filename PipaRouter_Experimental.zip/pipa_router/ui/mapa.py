# -*- coding: utf-8 -*-
#
# PipaRouter — roteirização de caminhões-pipa no QGIS
# Copyright (C) 2025  Antonio A. Coelho Neto
#
# Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
# sob os termos da GNU General Public License versão 2 ou posterior.
# Veja o arquivo LICENSE, ou <https://www.gnu.org/licenses/gpl-2.0.html>.
#
"""
Ferramentas de clique no mapa.

O usuario marca os pontos clicando, nao digitando coordenada. Cada clique
abre uma caixa perguntando so o essencial: o nome do lugar e quanta agua
precisa.
"""

from qgis.core import QgsPointXY, QgsWkbTypes
from qgis.gui import QgsMapTool, QgsRubberBand, QgsVertexMarker
from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtGui import QColor


class FerramentaRetangulo(QgsMapTool):
    """
    Arrastar no mapa para escolher a area de download.

    NAO USA pyqtSignal. QgsMapTool e uma classe C++ do QGIS; sinais
    declarados em subclasses Python dela nem sempre disparam — dependem de
    como o QGIS instancia o objeto. Foi por isso que o arrasto nao fazia
    nada. Callback direto sempre funciona.

    Mostra o tamanho em km enquanto voce arrasta: sem isso o usuario nao
    sabe se esta pedindo 20 km ou 600.
    """

    def __init__(self, canvas, ao_escolher=None, ao_cancelar=None,
                 iface=None):
        super().__init__(canvas)
        self.canvas = canvas
        self.ao_escolher = ao_escolher
        self.ao_cancelar = ao_cancelar
        self.iface = iface
        self.setCursor(Qt.CrossCursor)
        self._ini = None
        self._rb = QgsRubberBand(canvas, QgsWkbTypes.PolygonGeometry)
        self._rb.setColor(QColor(0, 38, 189, 50))
        self._rb.setStrokeColor(QColor("#0026BD"))
        self._rb.setWidth(2)

    def canvasPressEvent(self, e):
        if e.button() == Qt.RightButton:
            self._fim()
            if self.ao_cancelar:
                self.ao_cancelar()
            return
        self._ini = self.toMapCoordinates(e.pos())

    def canvasMoveEvent(self, e):
        if self._ini is None:
            return
        atual = self.toMapCoordinates(e.pos())
        self._desenhar(self._ini, atual)
        if self.iface:
            s, w, n, ee = self._para_wgs84(self._ini, atual)
            larg, alt = self._km(s, w, n, ee)
            self.iface.statusBarIface().showMessage(
                f"Área: {larg:.0f} x {alt:.0f} km "
                f"({larg*alt:,.0f} km²) — solte para confirmar")

    def canvasReleaseEvent(self, e):
        if e.button() != Qt.LeftButton or self._ini is None:
            return
        fim = self.toMapCoordinates(e.pos())
        ini = self._ini
        self._ini = None
        self._limpar()

        # Clique sem arrastar
        if abs(fim.x() - ini.x()) < 1e-9 and abs(fim.y() - ini.y()) < 1e-9:
            if self.iface:
                self.iface.statusBarIface().showMessage(
                    "Arraste (segure o botão e mova), não só clique.", 4000)
            return

        s, w, n, ee = self._para_wgs84(ini, fim)
        self._fim()
        if self.ao_escolher:
            self.ao_escolher(s, w, n, ee)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self._fim()
            if self.ao_cancelar:
                self.ao_cancelar()

    @staticmethod
    def _km(s, w, n, e):
        import math
        alt = (n - s) * 110.6
        larg = (e - w) * 111.3 * max(math.cos(math.radians((s + n) / 2)), 0.1)
        return abs(larg), abs(alt)

    def _desenhar(self, a, b):
        from qgis.core import QgsRectangle
        r = QgsRectangle(a, b)
        self._rb.reset(QgsWkbTypes.PolygonGeometry)
        for p in (QgsPointXY(r.xMinimum(), r.yMinimum()),
                  QgsPointXY(r.xMinimum(), r.yMaximum()),
                  QgsPointXY(r.xMaximum(), r.yMaximum()),
                  QgsPointXY(r.xMaximum(), r.yMinimum())):
            self._rb.addPoint(p, False)
        self._rb.closePoints()
        self._rb.show()

    def _limpar(self):
        self._rb.reset(QgsWkbTypes.PolygonGeometry)

    def _fim(self):
        self._ini = None
        self._limpar()
        if self.iface:
            self.iface.statusBarIface().clearMessage()

    def _para_wgs84(self, a, b):
        from qgis.core import (
            QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject,
            QgsRectangle,
        )
        crs = self.canvas.mapSettings().destinationCrs()
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        r = QgsRectangle(a, b)
        if crs != wgs:
            tr = QgsCoordinateTransform(crs, wgs, QgsProject.instance())
            r = tr.transformBoundingBox(r)
        return (r.yMinimum(), r.xMinimum(), r.yMaximum(), r.xMaximum())

    def deactivate(self):
        self._limpar()
        super().deactivate()


class FerramentaClique(QgsMapTool):
    """Clique no mapa -> emite a coordenada em EPSG:4326."""

    ponto_clicado = pyqtSignal(float, float)
    cancelado = pyqtSignal()

    def __init__(self, canvas, cor=QColor("#0026BD")):
        super().__init__(canvas)
        self.canvas = canvas
        self.cor = cor
        self.setCursor(Qt.CrossCursor)

    def canvasReleaseEvent(self, e):
        if e.button() == Qt.RightButton:
            self.cancelado.emit()
            return
        p = self.toMapCoordinates(e.pos())
        p4326 = self._para_wgs84(p)
        self.ponto_clicado.emit(p4326.x(), p4326.y())

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self.cancelado.emit()

    def _para_wgs84(self, p: QgsPointXY) -> QgsPointXY:
        from qgis.core import (
            QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject,
        )
        crs_mapa = self.canvas.mapSettings().destinationCrs()
        crs_wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        if crs_mapa == crs_wgs:
            return p
        tr = QgsCoordinateTransform(crs_mapa, crs_wgs, QgsProject.instance())
        return tr.transform(p)


class MarcadoresMapa:
    """
    Gerencia os marcadores visuais no canvas: base, pontos de entrega,
    e o destaque do ponto selecionado.
    """

    def __init__(self, canvas):
        self.canvas = canvas
        self._base = []
        self._pontos = {}      # id -> QgsVertexMarker
        self._destaque = None
        self._rotas = []       # QgsRubberBand

    # -- conversao --------------------------------------------------------

    def _do_wgs84(self, x, y) -> QgsPointXY:
        from qgis.core import (
            QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsProject,
        )
        crs_mapa = self.canvas.mapSettings().destinationCrs()
        crs_wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        p = QgsPointXY(x, y)
        if crs_mapa == crs_wgs:
            return p
        tr = QgsCoordinateTransform(crs_wgs, crs_mapa, QgsProject.instance())
        return tr.transform(p)

    # -- base -------------------------------------------------------------

    def marcar_base(self, x, y):
        self.limpar_base()
        m = QgsVertexMarker(self.canvas)
        m.setCenter(self._do_wgs84(x, y))
        m.setIconType(QgsVertexMarker.ICON_DOUBLE_TRIANGLE)
        m.setColor(QColor("#0026BD"))
        m.setFillColor(QColor("#17E3CB"))
        m.setIconSize(18)
        m.setPenWidth(4)
        self._base.append(m)

    def limpar_base(self):
        for m in self._base:
            self.canvas.scene().removeItem(m)
        self._base = []

    # -- pontos de entrega ------------------------------------------------

    def marcar_ponto(self, pid, x, y, prioridade=1, atendido=None):
        """
        atendido: None = ainda nao rodou | True = na rota | False = ficou de fora
        """
        self.remover_ponto(pid)
        m = QgsVertexMarker(self.canvas)
        m.setCenter(self._do_wgs84(x, y))
        m.setIconType(QgsVertexMarker.ICON_CIRCLE)

        if atendido is False:
            cor = QColor("#D32F2F")      # vermelho: sem agua
        elif atendido is True:
            cor = QColor("#2E7D32")      # verde: vai receber
        else:
            cor = {1: QColor("#0026BD"),
                   2: QColor("#F57C00"),
                   3: QColor("#C62828")}.get(prioridade, QColor("#0026BD"))

        m.setColor(cor)
        m.setFillColor(cor)
        m.setIconSize(11 + prioridade * 2)
        m.setPenWidth(3)
        self._pontos[pid] = m

    def remover_ponto(self, pid):
        m = self._pontos.pop(pid, None)
        if m:
            self.canvas.scene().removeItem(m)

    def destacar(self, x, y):
        self.limpar_destaque()
        m = QgsVertexMarker(self.canvas)
        m.setCenter(self._do_wgs84(x, y))
        m.setIconType(QgsVertexMarker.ICON_BOX)
        m.setColor(QColor("#FFD600"))
        m.setIconSize(22)
        m.setPenWidth(4)
        self._destaque = m

    def limpar_destaque(self):
        if self._destaque:
            self.canvas.scene().removeItem(self._destaque)
            self._destaque = None

    # -- rotas ------------------------------------------------------------

    CORES_ROTA = ["#E53935", "#1E88E5", "#43A047", "#FB8C00",
                  "#8E24AA", "#00ACC1", "#F4511E", "#3949AB"]

    def desenhar_rota(self, indice, coords_wgs84):
        rb = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        cor = QColor(self.CORES_ROTA[indice % len(self.CORES_ROTA)])
        rb.setColor(cor)
        rb.setWidth(3)
        for x, y in coords_wgs84:
            rb.addPoint(self._do_wgs84(x, y))
        self._rotas.append(rb)

    def limpar_rotas(self):
        for rb in self._rotas:
            self.canvas.scene().removeItem(rb)
        self._rotas = []

    # -- geral ------------------------------------------------------------

    def limpar_tudo(self):
        self.limpar_base()
        self.limpar_destaque()
        self.limpar_rotas()
        for pid in list(self._pontos):
            self.remover_ponto(pid)
