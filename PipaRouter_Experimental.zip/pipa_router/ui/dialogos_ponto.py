# -*- coding: utf-8 -*-
#
# PipaRouter — roteirização de caminhões-pipa no QGIS
# Copyright (C) 2025  Antonio A. Coelho Neto
#
# Este programa é software livre: você pode redistribuí-lo e/ou modificá-lo
# sob os termos da GNU General Public License versão 2 ou posterior.
# Veja o arquivo LICENSE, ou <https://www.gnu.org/licenses/gpl-2.0.html>.
#
"""Caixa que abre ao clicar no mapa. Pergunta so o essencial."""

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QFont
from qgis.PyQt.QtWidgets import (
    QButtonGroup, QDialog, QDialogButtonBox, QDoubleSpinBox, QFormLayout,
    QHBoxLayout, QLabel, QLineEdit, QRadioButton, QVBoxLayout, QWidget,
)

# Referencia de consumo: a literatura de abastecimento emergencial no semiarido
# trabalha com 20-50 L/hab.dia. Usamos 40 L/hab.dia como padrao — cobre bebida,
# higiene basica e cozinha, sem ser otimista demais.
LITROS_PESSOA_DIA = 40


class DialogoPonto(QDialog):
    """
    Cadastro de um ponto de entrega.

    O usuario pode informar o volume de duas formas:
      - direto em m3 (se souber o tamanho da caixa d'agua)
      - por numero de pessoas + dias (o plugin calcula)

    A segunda forma existe porque o encarregado sabe "sao 12 familias",
    nao "sao 8,4 m3".
    """

    def __init__(self, x, y, nome_sugerido="", parent=None):
        super().__init__(parent)
        self.x, self.y = x, y
        self.setWindowTitle("Novo ponto de entrega")
        self.setMinimumWidth(420)
        self._montar(nome_sugerido)

    def _montar(self, nome_sugerido):
        v = QVBoxLayout(self)

        cab = QLabel("Quem vai receber água aqui?")
        cab.setStyleSheet(
            "font-size:15px;font-weight:bold;color:#0026BD;padding:4px 0;")
        v.addWidget(cab)

        loc = QLabel(f"Local marcado: {self.y:.5f}, {self.x:.5f}")
        loc.setStyleSheet("color:#666;font-size:11px;")
        v.addWidget(loc)

        f = QFormLayout()
        f.setSpacing(10)

        self.ed_nome = QLineEdit(nome_sugerido)
        self.ed_nome.setPlaceholderText("Ex.: Povoado Baixa Grande")
        f.addRow("Nome do lugar:", self.ed_nome)
        v.addLayout(f)

        # --- Quanta agua ---
        q = QLabel("Quanta água precisa?")
        q.setStyleSheet("font-weight:bold;padding-top:8px;")
        v.addWidget(q)

        self.rb_m3 = QRadioButton("Sei o volume (m³)")
        self.rb_pessoas = QRadioButton("Sei quantas pessoas")
        self.rb_pessoas.setChecked(True)
        grupo = QButtonGroup(self)
        grupo.addButton(self.rb_m3)
        grupo.addButton(self.rb_pessoas)

        v.addWidget(self.rb_pessoas)
        fp = QFormLayout()
        fp.setContentsMargins(24, 0, 0, 0)
        self.sp_pessoas = QDoubleSpinBox()
        self.sp_pessoas.setRange(1, 5000)
        self.sp_pessoas.setValue(50)
        self.sp_pessoas.setDecimals(0)
        self.sp_pessoas.setSuffix(" pessoas")
        self.sp_dias = QDoubleSpinBox()
        self.sp_dias.setRange(1, 60)
        self.sp_dias.setValue(7)
        self.sp_dias.setDecimals(0)
        self.sp_dias.setSuffix(" dias")
        fp.addRow("Quantas pessoas:", self.sp_pessoas)
        fp.addRow("Para quantos dias:", self.sp_dias)
        v.addLayout(fp)

        v.addWidget(self.rb_m3)
        fm = QFormLayout()
        fm.setContentsMargins(24, 0, 0, 0)
        self.sp_vol = QDoubleSpinBox()
        self.sp_vol.setRange(0.5, 200)
        self.sp_vol.setValue(10)
        self.sp_vol.setSuffix(" m³")
        self.sp_vol.setSingleStep(0.5)
        fm.addRow("Volume:", self.sp_vol)
        v.addLayout(fm)

        self.lbl_calc = QLabel()
        self.lbl_calc.setStyleSheet(
            "background:#E8F5E9;border-left:3px solid #2E7D32;"
            "padding:8px;color:#1B5E20;font-size:12px;")
        self.lbl_calc.setWordWrap(True)
        v.addWidget(self.lbl_calc)

        # --- Urgencia ---
        u = QLabel("É urgente?")
        u.setStyleSheet("font-weight:bold;padding-top:8px;")
        v.addWidget(u)

        self.rb_p1 = QRadioButton("Normal — pode esperar")
        self.rb_p2 = QRadioButton("Urgente — atender hoje se der")
        self.rb_p3 = QRadioButton("Crítico — sem água, tem que ir")
        self.rb_p1.setChecked(True)
        for rb, cor in ((self.rb_p1, "#0026BD"), (self.rb_p2, "#F57C00"),
                        (self.rb_p3, "#C62828")):
            rb.setStyleSheet(f"color:{cor};padding:2px;")
            v.addWidget(rb)

        # --- Botoes ---
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("Adicionar ponto")
        bb.button(QDialogButtonBox.Ok).setStyleSheet(
            "background:#0026BD;color:white;font-weight:bold;padding:7px 18px;")
        bb.button(QDialogButtonBox.Cancel).setText("Cancelar")
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        v.addWidget(bb)

        for w in (self.sp_pessoas, self.sp_dias, self.sp_vol):
            w.valueChanged.connect(self._atualizar)
        for rb in (self.rb_m3, self.rb_pessoas):
            rb.toggled.connect(self._atualizar)
        self._atualizar()

        self.ed_nome.setFocus()

    def _atualizar(self):
        modo_p = self.rb_pessoas.isChecked()
        self.sp_pessoas.setEnabled(modo_p)
        self.sp_dias.setEnabled(modo_p)
        self.sp_vol.setEnabled(not modo_p)

        if modo_p:
            v = self.volume()
            self.lbl_calc.setText(
                f"{self.sp_pessoas.value():.0f} pessoas × "
                f"{LITROS_PESSOA_DIA} L/dia × {self.sp_dias.value():.0f} dias "
                f"= <b>{v:.1f} m³</b><br>"
                f"<span style='color:#555;font-size:11px;'>"
                f"Referência de consumo mínimo para bebida, higiene e cozinha. "
                f"Se a comunidade tem outra fonte parcial, informe o volume "
                f"direto em m³.</span>")
        else:
            v = self.sp_vol.value()
            pes = (v * 1000) / (LITROS_PESSOA_DIA * 7)
            self.lbl_calc.setText(
                f"<b>{v:.1f} m³</b> — atende cerca de {pes:.0f} pessoas "
                f"por 7 dias, no consumo mínimo.")

    # -- resultado --------------------------------------------------------

    def volume(self) -> float:
        if self.rb_pessoas.isChecked():
            litros = (self.sp_pessoas.value() * LITROS_PESSOA_DIA
                      * self.sp_dias.value())
            return round(litros / 1000.0, 2)
        return self.sp_vol.value()

    def nome(self) -> str:
        return self.ed_nome.text().strip() or "Ponto sem nome"

    def prioridade(self) -> int:
        if self.rb_p3.isChecked():
            return 3
        if self.rb_p2.isChecked():
            return 2
        return 1

    def pessoas(self) -> int:
        """Quantas pessoas dependem deste ponto (0 se informado em m3)."""
        if self.rb_pessoas.isChecked():
            return int(self.sp_pessoas.value())
        return int((self.volume() * 1000) / (LITROS_PESSOA_DIA * 7))


class DialogoBase(QDialog):
    """Cadastro do ponto de carregamento."""

    def __init__(self, x, y, parent=None):
        super().__init__(parent)
        self.x, self.y = x, y
        self.setWindowTitle("Ponto de carregamento")
        self.setMinimumWidth(400)

        v = QVBoxLayout(self)
        cab = QLabel("Onde o caminhão enche?")
        cab.setStyleSheet(
            "font-size:15px;font-weight:bold;color:#0026BD;padding:4px 0;")
        v.addWidget(cab)

        loc = QLabel(f"Local marcado: {y:.5f}, {x:.5f}")
        loc.setStyleSheet("color:#666;font-size:11px;")
        v.addWidget(loc)

        f = QFormLayout()
        f.setSpacing(10)
        self.ed_nome = QLineEdit("ETA")
        self.ed_nome.setPlaceholderText("Ex.: ETA Sede, Poço do Distrito")

        self.sp_vazao = QDoubleSpinBox()
        self.sp_vazao.setRange(1, 500)
        self.sp_vazao.setValue(50)
        self.sp_vazao.setSuffix(" m³/h")
        self.sp_vazao.setToolTip(
            "Se não souber: cronometre o enchimento de um caminhão.\n"
            "Ex.: 10 m³ em 12 minutos = 50 m³/h.")

        f.addRow("Nome:", self.ed_nome)
        f.addRow("Velocidade de enchimento:", self.sp_vazao)
        v.addLayout(f)

        self.lbl = QLabel()
        self.lbl.setStyleSheet(
            "background:#E3F2FD;border-left:3px solid #0026BD;"
            "padding:8px;font-size:12px;")
        self.lbl.setWordWrap(True)
        v.addWidget(self.lbl)
        self.sp_vazao.valueChanged.connect(self._atualizar)
        self._atualizar()

        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.button(QDialogButtonBox.Ok).setText("Confirmar")
        bb.button(QDialogButtonBox.Ok).setStyleSheet(
            "background:#0026BD;color:white;font-weight:bold;padding:7px 18px;")
        bb.button(QDialogButtonBox.Cancel).setText("Cancelar")
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        v.addWidget(bb)

    def _atualizar(self):
        vz = self.sp_vazao.value()
        t10 = (10 / vz) * 60
        self.lbl.setText(
            f"Um caminhão de 10 m³ enche em <b>{t10:.0f} minutos</b>.<br>"
            f"<span style='color:#555;font-size:11px;'>Confira com o motorista. "
            f"Se estiver muito diferente do real, o horário previsto de cada "
            f"entrega vai sair errado.</span>")

    def nome(self):
        return self.ed_nome.text().strip() or "Base"

    def vazao(self):
        return self.sp_vazao.value()
